-- ==============================================================================
-- ATIVAR AUTOMATICAMENTE NOVOS COLABORADORES
-- ==============================================================================

-- Altera o valor padrão da coluna 'status' de 'pendente' para 'ativo'
-- Isso garante que todos os NOVOS cadastros já nasçam ativos.

ALTER TABLE colaboradores 
ALTER COLUMN status SET DEFAULT 'ativo';

-- Verifica se a alteração foi aplicada (pode ver na aba 'Definition' da tabela depois)
SELECT column_name, column_default 
FROM information_schema.columns 
WHERE table_name = 'colaboradores' AND column_name = 'status';
