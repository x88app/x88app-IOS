-- ==============================================================
-- REVERSÃO: Desfazer Carteira Global Compartilhada
-- ==============================================================

-- Passo 1: Remover Políticas RLS da Carteira Global
DROP POLICY IF EXISTS "Gestores veem carteira global" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores atualizam carteira global" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores inserem carteira pessoal" ON carteira_gestor;

-- Passo 2: Restaurar Políticas RLS Originais (Individuais)

-- Apenas gestores podem ver a carteira
CREATE POLICY "Gestores veem própria carteira"
    ON carteira_gestor FOR SELECT
    USING (
        gestor_id = auth.uid()
        OR
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario = 'admin'
        )
    );

-- Gestores podem atualizar própria carteira
CREATE POLICY "Gestores atualizam própria carteira"
    ON carteira_gestor FOR UPDATE
    USING (gestor_id = auth.uid())
    WITH CHECK (gestor_id = auth.uid());

-- Gestores podem inserir carteira
CREATE POLICY "Gestores podem inserir carteira"
    ON carteira_gestor FOR INSERT
    WITH CHECK (gestor_id = auth.uid());

-- Passo 3: Remover coluna is_global
ALTER TABLE carteira_gestor DROP COLUMN IF EXISTS is_global;

-- Mensagem de confirmação
DO $$
BEGIN
    RAISE NOTICE 'Reversão da Carteira Global concluída com sucesso! O sistema voltou ao modo de carteiras individuais.';
END $$;
