-- Adiciona coluna para guardar a inscrição do Web Push (JSON completo)
ALTER TABLE usuarios
ADD COLUMN IF NOT EXISTS web_push_subscription JSONB;

-- Index para melhorar performance se precisar buscar
CREATE INDEX IF NOT EXISTS idx_usuarios_web_push ON usuarios USING gin(web_push_subscription);
