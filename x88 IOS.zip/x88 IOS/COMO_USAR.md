# 🚀 Como Usar o Sistema X88 com Supabase

## ✅ O QUE JÁ FOI FEITO

- ✅ **Banco de dados** criado no Supabase (10 tabelas)
- ✅ **Políticas RLS** configuradas para segurança
- ✅ **Dependências** instaladas em ambos os apps
- ✅ **Credenciais** configuradas nos arquivos `.env`
- ✅ **Todos os Contexts** atualizados para usar Supabase:
  - AuthContext (Login/Registro)
  - RequestsContext (Solicitações)
  - NotificationsContext (Notificações)
  - ColaboradoresContext (Gestor)
  - RequestsGestorContext (Gestor)
  - WalletContext (Gestor)

---

## 🎯 PRÓXIMOS PASSOS

### **1. Criar Primeiro Usuário Gestor**

Você TEM que criar pelo menos 1 gestor para acessar o app gestor.

**Opção A: Via Supabase Dashboard (RECOMENDADO)**

1. Acesse o Supabase → **Authentication** → **Users**
2. Clique em **Add user** → **Create new user**
3. Preencha:
   - Email: `gestor@x88.pt` (ou seu email)
   - Password: `SuaSenhaForte@123`
   - ✅ Marque **"Auto Confirm User"**
4. Copie o **UUID** que aparece
5. Execute no **SQL Editor**:

```sql
-- SUBSTITUA 'UUID-DO-USUARIO-CRIADO' pelo UUID real!
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo)
VALUES (
    'UUID-DO-USUARIO-CRIADO',
    'Gestor Administrador',
    'gestor@x88.pt',
    '+351 910 000 000',
    '100000000',
    'gerenciado-pelo-supabase',
    'gestor',
    true
);

-- Criar carteira para o gestor
INSERT INTO carteira_gestor (gestor_id, saldo_eur, saldo_sats)
VALUES (
    'UUID-DO-USUARIO-CRIADO',
    5000.00,
    1000000
);
```

**Opção B: Via App Gestor (Depois de criar o primeiro)**

Depois que você tiver um gestor, pode criar outros via código.

---

### **2. Testar App Colaborador**

1. Inicie o app:
```bash
npm run dev
```

2. Acesse: `http://localhost:3001`

3. Clique em **"Criar Conta"**

4. Preencha:
   - Nome: João Silva
   - Email: joao.silva@x88.pt
   - Telefone: +351 912 345 678
   - NIF: 123456789
   - Senha: Joao@123

5. O sistema irá:
   - ✅ Criar usuário no Auth
   - ✅ Criar registro na tabela `usuarios`
   - ✅ Criar registro na tabela `colaboradores`
   - ✅ Fazer login automaticamente

6. Teste criar uma solicitação!

---

### **3. Testar App Gestor**

1. Inicie o app gestor:
```bash
cd x88gestor
npm run dev
```

2. Acesse: `http://localhost:3002`

3. Faça login com:
   - Email: `gestor@x88.pt`
   - Senha: (a que você criou)

4. Você verá:
   - ✅ Lista de colaboradores
   - ✅ Solicitações pendentes
   - ✅ Saldo da carteira

5. Teste:
   - Aprovar uma solicitação
   - Adicionar saldo EUR/SATS
   - Pagar uma solicitação aprovada

---

## 🔍 Verificar se Está Funcionando

### **No App Colaborador:**

Abra o **DevTools** (F12) → **Console**

Você NÃO deve ver mais:
- ❌ `📊 Criando solicitações fictícias...`
- ❌ `✅ Dados fictícios salvos no localStorage!`

Deve ver:
- ✅ Requisições para o Supabase
- ✅ Dados carregados do banco

### **No App Gestor:**

Mesma coisa! Não deve ter dados fictícios, apenas do Supabase.

---

## 🐛 Problemas Comuns

### **Erro: "Credenciais do Supabase não encontradas"**

**Solução:** Verifique se você criou os arquivos `.env`:

```bash
# Raiz do colaborador
/c:/Users/silvi/Documents/colaborador/.env

# Raiz do gestor
/c:/Users/silvi/Documents/colaborador/x88gestor/.env
```

Conteúdo:
```env
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-aqui
```

### **Erro: "Row Level Security"**

**Solução:** Execute o arquivo `supabase_rls_policies.sql` no Supabase SQL Editor.

### **Login não funciona**

**Solução:** 
1. Verifique se o usuário existe em **Authentication** → **Users**
2. Verifique se o usuário existe na tabela `usuarios`
3. O `id` deve ser o MESMO em ambos!

### **Colaborador não consegue criar solicitação**

**Solução:** Verifique se existe um registro na tabela `colaboradores` com o `usuario_id` correto.

---

## 📊 Estrutura de Dados

### **Para Login:**
```
auth.users (Supabase Auth)
    ↓
usuarios (tabela)
    ↓
colaboradores (se for colaborador)
```

### **Para Solicitações:**
```
colaboradores
    ↓
solicitacoes
    ↓
notificacoes (automático)
```

### **Para Pagamentos (Gestor):**
```
solicitacoes (status: aprovado)
    ↓
carteira_gestor (deduz saldo)
    ↓
transacoes_carteira (registra)
    ↓
solicitacoes (status: pago)
```

---

## 🎉 Pronto!

Agora você tem:
- ✅ Sistema 100% integrado com Supabase
- ✅ Autenticação real
- ✅ Dados persistentes no banco
- ✅ Tempo real (mudanças refletem automaticamente)
- ✅ Sem dados fictícios!

**Próximo passo:** Criar o primeiro gestor e testar! 🚀
