-- Função para permitir que o usuário exclua sua própria conta e todos os dados relacionados
-- Esta função deve ser executada no SQL Editor do Supabase para ter permissões adequadas

CREATE OR REPLACE FUNCTION delete_own_account()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    current_user_id UUID;
BEGIN
    -- Obter o ID do usuário atual
    current_user_id := auth.uid();

    -- Verificar se o usuário está autenticado
    IF current_user_id IS NULL THEN
        RAISE EXCEPTION 'Não autenticado';
    END IF;

    -- Deletar logs de auditoria explicitamente (para garantir "apagar tudo" mesmo com SET NULL)
    DELETE FROM public.auditoria WHERE usuario_id = current_user_id;

    -- Deletar o registro da tabela de usuários (pública)
    -- Isso deve acionar ON DELETE CASCADE para:
    -- - colaboradores (e por consequência solicitacoes)
    -- - notificacoes
    -- - carteira_gestor
    DELETE FROM public.usuarios WHERE id = current_user_id;

    -- Deletar o usuário da tabela de autenticação do Supabase (auth.users)
    -- Requer privilégios de admin/superuser (garantidos por SECURITY DEFINER)
    DELETE FROM auth.users WHERE id = current_user_id;
END;
$$;
