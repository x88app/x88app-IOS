-- Adicionar coluna 'descontado' na tabela solicitacoes
-- Esta coluna indica se o valor já foi descontado do salário do colaborador

ALTER TABLE solicitacoes 
ADD COLUMN IF NOT EXISTS descontado BOOLEAN DEFAULT FALSE;

-- Adicionar coluna para armazenar a data do desconto
ALTER TABLE solicitacoes 
ADD COLUMN IF NOT EXISTS data_desconto TIMESTAMP WITH TIME ZONE;

-- Atualizar as políticas RLS para permitir atualização do campo descontado
-- (Apenas gestores podem marcar como descontado)
