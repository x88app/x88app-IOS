import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { create } from "https://deno.land/x/djwt@v2.8/mod.ts"

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
const GROQ_API_KEY = Deno.env.get('GROQ_API_KEY')

// Firebase credentials
const FIREBASE_PROJECT_ID = Deno.env.get('FIREBASE_PROJECT_ID')
const FIREBASE_CLIENT_EMAIL = Deno.env.get('FIREBASE_CLIENT_EMAIL')
const FIREBASE_PRIVATE_KEY = Deno.env.get('FIREBASE_PRIVATE_KEY')?.replace(/\\n/g, '\n')

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Generate Firebase OAuth2 access token
async function getFirebaseAccessToken(): Promise<string> {
  const now = Math.floor(Date.now() / 1000)
  
  const payload = {
    iss: FIREBASE_CLIENT_EMAIL,
    sub: FIREBASE_CLIENT_EMAIL,
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
    scope: "https://www.googleapis.com/auth/firebase.messaging"
  }

  const pemHeader = "-----BEGIN PRIVATE KEY-----"
  const pemFooter = "-----END PRIVATE KEY-----"
  const pemContents = FIREBASE_PRIVATE_KEY!
    .replace(pemHeader, '')
    .replace(pemFooter, '')
    .replace(/\s/g, '')
  
  const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0))
  
  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    binaryDer,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  )

  const jwt = await create(
    { alg: "RS256", typ: "JWT" },
    payload,
    cryptoKey
  )

  const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  })

  const tokenData = await tokenResponse.json()
  return tokenData.access_token
}

// Generate motivational message using Groq AI
async function generateMotivationalMessage(prompt: string): Promise<string> {
  const systemPrompt = `Você é um assistente que gera mensagens motivacionais curtas e inspiradoras.
Baseado no tema fornecido, gere UMA ÚNICA mensagem motivacional.
A mensagem deve ser:
- Curta (máximo 2 frases)
- Inspiradora e positiva
- Adequada para notificação push
- Sem emojis excessivos (máximo 1 emoji no final, opcional)

Tema solicitado: ${prompt}

Responda APENAS com a mensagem, sem explicações adicionais.`

  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${GROQ_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'llama-3.1-8b-instant',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: 'Gere uma mensagem motivacional agora.' }
      ],
      temperature: 0.9,
      max_tokens: 150,
    }),
  })

  const data = await response.json()
  return data.choices?.[0]?.message?.content || 'Tenha um ótimo dia! 💪'
}

// Send push notification to a single device
async function sendPushToDevice(accessToken: string, fcmToken: string, title: string, body: string) {
  const fcmPayload = {
    message: {
      token: fcmToken,
      notification: { title, body },
      android: {
        priority: "high",
        notification: {
          sound: "kernel",
          channel_id: "x88_notifications"
        }
      },
      apns: {
        payload: {
          aps: {
            sound: "default",
            badge: 1
          }
        }
      }
    }
  }

  try {
    await fetch(
      `https://fcm.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/messages:send`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(fcmPayload),
      }
    )
  } catch (error) {
    console.error('Error sending push to device:', error)
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('Starting daily motivation job...')

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error('Supabase credentials not configured')
    }

    if (!GROQ_API_KEY) {
      throw new Error('GROQ_API_KEY not configured')
    }

    if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY) {
      throw new Error('Firebase credentials not configured')
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

    // 1. Check if daily motivation is enabled
    const { data: config } = await supabase
      .from('configuracoes_globais')
      .select('motivacao_diaria_ativa, motivacao_diaria_prompt')
      .limit(1)
      .maybeSingle()

    if (!config?.motivacao_diaria_ativa) {
      console.log('Daily motivation is disabled')
      return new Response(
        JSON.stringify({ success: true, message: 'Daily motivation is disabled' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const prompt = config.motivacao_diaria_prompt || 'Frases motivacionais para começar bem o dia'

    // 2. Generate motivational message using AI
    console.log('Generating motivational message...')
    const motivationalMessage = await generateMotivationalMessage(prompt)
    console.log('Generated message:', motivationalMessage)

    // 3. Get all collaborators with FCM tokens and push enabled
    const { data: colaboradores } = await supabase
      .from('colaboradores')
      .select('id, fcm_token, usuario_id')
      .not('fcm_token', 'is', null)

    if (!colaboradores || colaboradores.length === 0) {
      console.log('No collaborators with FCM tokens found')
      return new Response(
        JSON.stringify({ success: true, message: 'No collaborators to notify' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // 4. Filter collaborators who have push notifications enabled
    const usuarioIds = colaboradores.map(c => c.usuario_id)
    const { data: usuarios } = await supabase
      .from('usuarios')
      .select('id, preferencias')
      .in('id', usuarioIds)

    const usuariosComPushAtivo = new Set(
      (usuarios || [])
        .filter(u => u.preferencias?.notifications?.push !== false)
        .map(u => u.id)
    )

    const colaboradoresParaNotificar = colaboradores.filter(
      c => usuariosComPushAtivo.has(c.usuario_id)
    )

    if (colaboradoresParaNotificar.length === 0) {
      console.log('All collaborators have push disabled')
      return new Response(
        JSON.stringify({ success: true, message: 'All collaborators have push disabled' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // 5. Get Firebase access token
    const accessToken = await getFirebaseAccessToken()

    // 6. Send push notifications
    console.log(`Sending to ${colaboradoresParaNotificar.length} collaborators...`)
    
    const title = '✨ Mensagem do Dia'
    
    for (const colab of colaboradoresParaNotificar) {
      await sendPushToDevice(accessToken, colab.fcm_token, title, motivationalMessage)
    }

    // 7. Also create in-app notifications
    const notificacoes = colaboradoresParaNotificar.map(c => ({
      usuario_id: c.usuario_id,
      titulo: title,
      mensagem: motivationalMessage,
      tipo: 'info',
      lida: false
    }))

    await supabase.from('notificacoes').insert(notificacoes)

    console.log('Daily motivation sent successfully!')

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Sent to ${colaboradoresParaNotificar.length} collaborators`,
        motivationalMessage 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error.message)
    return new Response(
      JSON.stringify({ error: error.message, success: false }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
