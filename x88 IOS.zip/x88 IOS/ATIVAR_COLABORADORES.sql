-- ==============================================================================
-- ATIVAR TODOS OS COLABORADORES PARA APARECEREM NO DASHBOARD
-- ==============================================================================

-- O Dashboard do Gestor filtra e mostra apenas colaboradores com status 'ativo'.
-- Se os colaboradores estiverem como 'pendente' ou 'inativo', eles não contam no número do card.

-- 1. Atualizar todos os colaboradores para 'ativo'
UPDATE colaboradores 
SET status = 'ativo';

-- 2. Verificar se funcionou
SELECT nome, email, status 
FROM vw_colaboradores_completos;
