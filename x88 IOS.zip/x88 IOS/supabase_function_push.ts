import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"
import webpush from "https://esm.sh/web-push@3.6.3"

const VAPID_PUBLIC_KEY = "BFltCIRi-zRJJBRhmm-ZeVNmXAL_n724JUclU9b8OMbxmWU8DiMfq5ftEUj75OjNSyyP9kJID1PW5QTGIjOf0RA"
const VAPID_PRIVATE_KEY = "X1obAUPDTjpd6BRop1fYksTlkF5eXc4qPzcdxVoA3eg"
const VAPID_SUBJECT = "mailto:suporte@x88.com"

webpush.setVapidDetails(
  VAPID_SUBJECT,
  VAPID_PUBLIC_KEY,
  VAPID_PRIVATE_KEY
)

serve(async (req) => {
  try {
    const { record } = await req.json()
    
    if (!record || !record.usuario_id) {
      return new Response("No user ID", { status: 400 })
    }

    // Init Supabase
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? ''
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    const supabase = createClient(supabaseUrl, supabaseKey)
    
    // Get Subscription
    const { data: user, error } = await supabase
      .from('usuarios')
      .select('web_push_subscription')
      .eq('id', record.usuario_id)
      .single()
      
    if (error || !user || !user.web_push_subscription) {
      console.log("No subscription found for user")
      return new Response("No subscription", { status: 200 })
    }

    // Payload
    const payload = JSON.stringify({
      title: record.titulo,
      body: record.mensagem,
      url: "https://appx88.netlify.app" // Change to your production URL
    })

    // Send
    await webpush.sendNotification(
      user.web_push_subscription,
      payload
    )
    
    return new Response(JSON.stringify({ success: true }), { 
      headers: { "Content-Type": "application/json" } 
    })
    
  } catch (error) {
    console.error("Push Error:", error)
    return new Response(JSON.stringify({ error: error.message }), { status: 500 })
  }
})
