-- ==============================================================================
-- HABILITAR REALTIME PARA BANNERS E ANÚNCIOS
-- ==============================================================================

-- Adicionar a tabela 'banners' à publicação do Supabase Realtime
-- Isso fará com que novos anúncios apareçam instantaneamente no app
alter publication supabase_realtime add table banners;
