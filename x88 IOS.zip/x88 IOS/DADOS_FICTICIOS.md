# 🎭 Dados Fictícios - X88 Colaborador

## ⚠️ IMPORTANTE: Limpar Cache

Se os dados fictícios não aparecerem, faça o seguinte:

### Opção 1: Limpar pelo navegador
1. Abra o DevTools (F12)
2. Vá em "Application" ou "Armazenamento"
3. Clique em "Local Storage"
4. Clique com botão direito e "Clear"
5. Atualize a página (F5)

### Opção 2: Pelo console
1. Abra o DevTools (F12)
2. Vá em "Console"
3. Digite: `localStorage.clear()`
4. Pressione Enter
5. Atualize a página (F5)

### Opção 3: Acesse /reset.html
1. Acesse: `http://localhost:3001/reset.html`
2. Clique no botão "Resetar Dados"
3. Aguarde redirecionamento

## 📊 Dados Fictícios Incluídos

### 👤 Usuário Demo
- **Nome:** João Silva Demo
- **Email:** demo@x88.pt
- **Telefone:** +351 912 345 678
- **NIF:** 123456789

### 💳 Dados Bancários
- **IBAN:** PT50 0000 0000 1234 5678 9012 3
- **Titular:** João Silva Demo
- **SWIFT/BIC:** CGDIPTPL
- **MBWAY:** +351 912 345 678
- **Lightning:** usuario@getalby.com

### 📈 Solicitações (8 total)

#### Em EUR (5)
1. €200 via IBAN - PAGO (há 10 dias)
2. €150 via MBWAY - PAGO (há 8 dias)
3. €100 via IBAN - PAGO (há 4 dias)
4. €125 via MBWAY - APROVADO (há 1 dia)
5. €80 via IBAN - PENDENTE (hoje)

#### Em Satoshi (3)
1. 75.000 sats - PAGO (há 6 dias)
2. 50.000 sats - PAGO (há 3 dias)
3. 30.000 sats - PROCESSANDO (hoje)

## 🔍 Verificar no Console

Ao abrir o app, você deve ver no console:
```
🔄 Nova versão detectada! Limpando dados antigos...
📊 Criando 8 solicitações fictícias...
✅ Dados fictícios salvos no localStorage!
💶 Total EUR: 5
⚡ Total SATS: 3
🔍 Verificando localStorage para requests...
📦 Requests encontrados: 8
✅ Requests carregados com sucesso!
```

## 🚀 Versão Atual

**APP_VERSION: 2.0.0**

A cada nova versão, os dados antigos são limpos automaticamente!
