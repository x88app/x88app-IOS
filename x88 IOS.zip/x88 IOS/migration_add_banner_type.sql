-- Adiciona coluna 'tipo' na tabela banners para distinguir entre carrossel (topo) e popup (anúncio)
-- Valores possíveis: 'carousel' (padrão), 'popup'

ALTER TABLE public.banners 
ADD COLUMN IF NOT EXISTS tipo text DEFAULT 'carousel';

-- Atualiza os registros existentes para serem do tipo 'carousel'
UPDATE public.banners SET tipo = 'carousel' WHERE tipo IS NULL;

-- Cria índice para performance
CREATE INDEX IF NOT EXISTS idx_banners_tipo ON public.banners(tipo);

-- Garante que a coluna 'ativo' existe (já deve existir, mas por segurança)
-- ALTER TABLE public.banners ADD COLUMN IF NOT EXISTS ativo boolean DEFAULT true;

-- Permite null na ordem para popups se não for crítico, ou mantemos a lógica de ordem.
