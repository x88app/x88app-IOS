-- Criação do bucket para banners
INSERT INTO storage.buckets (id, name, public) 
VALUES ('banners', 'banners', true)
ON CONFLICT (id) DO NOTHING;

-- Política de acesso público para leitura
CREATE POLICY "Banners são públicos"
ON storage.objects FOR SELECT
USING ( bucket_id = 'banners' );

-- Política de upload para usuários autenticados (Gestores)
-- Assumindo que apenas gestores devem fazer upload, mas vamos permitir autenticados por enquanto
-- Idealmente checaríamos public.usuarios.tipo_usuario
CREATE POLICY "Gestores podem fazer upload de banners"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'banners' AND
  auth.role() = 'authenticated'
);

-- Política de atualização
CREATE POLICY "Gestores podem atualizar banners"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'banners' AND
  auth.role() = 'authenticated'
);

-- Política de deleção
CREATE POLICY "Gestores podem deletar banners"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'banners' AND
  auth.role() = 'authenticated'
);
