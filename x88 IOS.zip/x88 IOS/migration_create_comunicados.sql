-- =====================================================
-- TABELA: comunicados
-- Descrição: Histórico de notificações em massa enviadas pelo gestor
-- =====================================================

CREATE TABLE IF NOT EXISTS comunicados (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(255) NOT NULL,
    mensagem TEXT NOT NULL,
    total_enviados INTEGER DEFAULT 0,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    gestor_id UUID REFERENCES usuarios(id) ON DELETE SET NULL
);

-- Habilitar RLS
ALTER TABLE comunicados ENABLE ROW LEVEL SECURITY;

-- Políticas para comunicados

-- Gestores podem ver comunicados
CREATE POLICY "Gestores podem ver comunicados"
    ON comunicados FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Gestores podem criar comunicados
CREATE POLICY "Gestores podem criar comunicados"
    ON comunicados FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Gestores podem deletar comunicados
CREATE POLICY "Gestores podem deletar comunicados"
    ON comunicados FOR DELETE
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Indexes
CREATE INDEX idx_comunicados_data_criacao ON comunicados(data_criacao DESC);
CREATE INDEX idx_comunicados_gestor_id ON comunicados(gestor_id);
