-- =====================================================
-- SCHEMA SQL COMPLETO - X88 ADIANTAMENTO SALARIAL
-- Versão: 1.0.0
-- Idioma: Português Brasileiro
-- Database: Supabase (PostgreSQL)
-- =====================================================

-- =====================================================
-- 1. TABELA: usuarios
-- Descrição: Armazena dados básicos de todos os usuários
-- =====================================================
CREATE TABLE IF NOT EXISTS usuarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    nif VARCHAR(20) NOT NULL,
    senha_hash TEXT NOT NULL,
    tipo_usuario VARCHAR(20) NOT NULL CHECK (tipo_usuario IN ('colaborador', 'gestor', 'admin')),
    ativo BOOLEAN DEFAULT TRUE,
    foto_perfil TEXT,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para usuarios
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_tipo ON usuarios(tipo_usuario);
CREATE INDEX idx_usuarios_ativo ON usuarios(ativo);

-- =====================================================
-- 2. TABELA: colaboradores
-- Descrição: Dados profissionais dos colaboradores
-- =====================================================
CREATE TABLE IF NOT EXISTS colaboradores (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID UNIQUE NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    iban VARCHAR(50),
    nome_titular_banco VARCHAR(255),
    swift_bic VARCHAR(20),
    telefone_mbway VARCHAR(20),
    carteira_lightning TEXT,
    metodo_pagamento_preferido VARCHAR(20) CHECK (metodo_pagamento_preferido IN ('iban', 'mbway', 'satoshi')),
    status VARCHAR(20) NOT NULL DEFAULT 'pendente' CHECK (status IN ('ativo', 'inativo', 'pendente')),
    limite_total DECIMAL(10, 2) DEFAULT 1000.00,
    limite_disponivel DECIMAL(10, 2) DEFAULT 1000.00,
    taxa_juros DECIMAL(5, 2) DEFAULT 10.00,
    total_adiantamentos INTEGER DEFAULT 0,
    data_admissao TIMESTAMP WITH TIME ZONE,
    data_registro TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para colaboradores
CREATE INDEX idx_colaboradores_usuario_id ON colaboradores(usuario_id);
CREATE INDEX idx_colaboradores_status ON colaboradores(status);
CREATE INDEX idx_colaboradores_data_admissao ON colaboradores(data_admissao);

-- =====================================================
-- 3. TABELA: solicitacoes
-- Descrição: Todas as solicitações de adiantamento
-- =====================================================
CREATE TABLE IF NOT EXISTS solicitacoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    colaborador_id UUID NOT NULL REFERENCES colaboradores(id) ON DELETE CASCADE,
    valor_solicitado DECIMAL(10, 2) NOT NULL,
    valor_liquido DECIMAL(10, 2) NOT NULL,
    moeda VARCHAR(10) NOT NULL CHECK (moeda IN ('EUR', 'SATS')),
    metodo_pagamento VARCHAR(20) NOT NULL CHECK (metodo_pagamento IN ('iban', 'mbway', 'satoshi')),
    detalhes_conta TEXT,
    iban_pagamento VARCHAR(50),
    mbway_pagamento VARCHAR(20),
    lightning_address TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'processando', 'aprovado', 'pago', 'rejeitado', 'verificando')),
    etapa_progresso INTEGER DEFAULT 0 CHECK (etapa_progresso BETWEEN 0 AND 4),
    taxa_juros_aplicada DECIMAL(5, 2),
    valor_juros DECIMAL(10, 2),
    motivo_rejeicao TEXT,
    comprovante_pagamento TEXT,
    lida BOOLEAN DEFAULT FALSE,
    data_solicitacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_aprovacao TIMESTAMP WITH TIME ZONE,
    data_pagamento TIMESTAMP WITH TIME ZONE,
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para solicitacoes
CREATE INDEX idx_solicitacoes_colaborador_id ON solicitacoes(colaborador_id);
CREATE INDEX idx_solicitacoes_status ON solicitacoes(status);
CREATE INDEX idx_solicitacoes_moeda ON solicitacoes(moeda);
CREATE INDEX idx_solicitacoes_data_solicitacao ON solicitacoes(data_solicitacao DESC);
CREATE INDEX idx_solicitacoes_lida ON solicitacoes(lida);

-- =====================================================
-- 4. TABELA: notificacoes
-- Descrição: Sistema de notificações para colaboradores
-- =====================================================
CREATE TABLE IF NOT EXISTS notificacoes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    solicitacao_id UUID REFERENCES solicitacoes(id) ON DELETE CASCADE,
    titulo VARCHAR(255) NOT NULL,
    mensagem TEXT NOT NULL,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('success', 'info', 'warning', 'error')),
    lida BOOLEAN DEFAULT FALSE,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para notificacoes
CREATE INDEX idx_notificacoes_usuario_id ON notificacoes(usuario_id);
CREATE INDEX idx_notificacoes_lida ON notificacoes(lida);
CREATE INDEX idx_notificacoes_data_criacao ON notificacoes(data_criacao DESC);
CREATE INDEX idx_notificacoes_solicitacao_id ON notificacoes(solicitacao_id);

-- =====================================================
-- 5. TABELA: carteira_gestor
-- Descrição: Saldo disponível do gestor para pagamentos
-- =====================================================
CREATE TABLE IF NOT EXISTS carteira_gestor (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    gestor_id UUID UNIQUE NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    saldo_eur DECIMAL(12, 2) DEFAULT 0.00,
    saldo_sats BIGINT DEFAULT 0,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para carteira_gestor
CREATE INDEX idx_carteira_gestor_id ON carteira_gestor(gestor_id);

-- =====================================================
-- 6. TABELA: transacoes_carteira
-- Descrição: Histórico de movimentações da carteira do gestor
-- =====================================================
CREATE TABLE IF NOT EXISTS transacoes_carteira (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    carteira_id UUID NOT NULL REFERENCES carteira_gestor(id) ON DELETE CASCADE,
    tipo_transacao VARCHAR(20) NOT NULL CHECK (tipo_transacao IN ('deposito', 'pagamento', 'estorno')),
    moeda VARCHAR(10) NOT NULL CHECK (moeda IN ('EUR', 'SATS')),
    valor DECIMAL(12, 2) NOT NULL,
    saldo_anterior DECIMAL(12, 2) NOT NULL,
    saldo_atual DECIMAL(12, 2) NOT NULL,
    solicitacao_id UUID REFERENCES solicitacoes(id) ON DELETE SET NULL,
    descricao TEXT,
    data_transacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para transacoes_carteira
CREATE INDEX idx_transacoes_carteira_id ON transacoes_carteira(carteira_id);
CREATE INDEX idx_transacoes_tipo ON transacoes_carteira(tipo_transacao);
CREATE INDEX idx_transacoes_data ON transacoes_carteira(data_transacao DESC);
CREATE INDEX idx_transacoes_solicitacao_id ON transacoes_carteira(solicitacao_id);

-- =====================================================
-- 7. TABELA: banners
-- Descrição: Banners exibidos no app do colaborador
-- =====================================================
CREATE TABLE IF NOT EXISTS banners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(255) NOT NULL,
    imagem_url TEXT NOT NULL,
    ordem INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para banners
CREATE INDEX idx_banners_ativo ON banners(ativo);
CREATE INDEX idx_banners_ordem ON banners(ordem);

-- =====================================================
-- 8. TABELA: cards_anuncio
-- Descrição: Cards de anúncio/benefícios no app
-- =====================================================
CREATE TABLE IF NOT EXISTS cards_anuncio (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT,
    imagem_url TEXT NOT NULL,
    ordem INTEGER DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para cards_anuncio
CREATE INDEX idx_cards_ativo ON cards_anuncio(ativo);
CREATE INDEX idx_cards_ordem ON cards_anuncio(ordem);

-- =====================================================
-- 9. TABELA: configuracoes_sistema
-- Descrição: Configurações gerais do sistema
-- =====================================================
CREATE TABLE IF NOT EXISTS configuracoes_sistema (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chave VARCHAR(100) UNIQUE NOT NULL,
    valor TEXT NOT NULL,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('texto', 'numero', 'booleano', 'json')),
    descricao TEXT,
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para configuracoes_sistema
CREATE INDEX idx_configuracoes_chave ON configuracoes_sistema(chave);

-- =====================================================
-- 10. TABELA: auditoria
-- Descrição: Log de ações importantes no sistema
-- =====================================================
CREATE TABLE IF NOT EXISTS auditoria (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
    acao VARCHAR(100) NOT NULL,
    tabela VARCHAR(50) NOT NULL,
    registro_id UUID,
    dados_anteriores JSONB,
    dados_novos JSONB,
    endereco_ip VARCHAR(45),
    user_agent TEXT,
    data_acao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes para auditoria
CREATE INDEX idx_auditoria_usuario_id ON auditoria(usuario_id);
CREATE INDEX idx_auditoria_tabela ON auditoria(tabela);
CREATE INDEX idx_auditoria_data ON auditoria(data_acao DESC);
CREATE INDEX idx_auditoria_acao ON auditoria(acao);

-- =====================================================
-- TRIGGERS: Atualização automática de timestamps
-- =====================================================

-- Função para atualizar data_atualizacao
CREATE OR REPLACE FUNCTION atualizar_data_modificacao()
RETURNS TRIGGER AS $$
BEGIN
    NEW.data_atualizacao = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para cada tabela
CREATE TRIGGER trigger_atualizar_usuarios
    BEFORE UPDATE ON usuarios
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

CREATE TRIGGER trigger_atualizar_colaboradores
    BEFORE UPDATE ON colaboradores
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

CREATE TRIGGER trigger_atualizar_solicitacoes
    BEFORE UPDATE ON solicitacoes
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

CREATE TRIGGER trigger_atualizar_carteira_gestor
    BEFORE UPDATE ON carteira_gestor
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

CREATE TRIGGER trigger_atualizar_banners
    BEFORE UPDATE ON banners
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

CREATE TRIGGER trigger_atualizar_cards_anuncio
    BEFORE UPDATE ON cards_anuncio
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

CREATE TRIGGER trigger_atualizar_configuracoes
    BEFORE UPDATE ON configuracoes_sistema
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

-- =====================================================
-- VIEWS: Consultas úteis pré-definidas
-- =====================================================

-- View: Colaboradores com dados completos
CREATE OR REPLACE VIEW vw_colaboradores_completos AS
SELECT 
    c.id,
    c.usuario_id,
    u.nome,
    u.email,
    u.telefone,
    u.nif,
    c.iban,
    c.nome_titular_banco,
    c.telefone_mbway,
    c.carteira_lightning,
    c.status,
    c.limite_total,
    c.limite_disponivel,
    c.taxa_juros,
    c.total_adiantamentos,
    c.data_admissao,
    c.data_registro,
    u.ativo AS usuario_ativo
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- View: Solicitações com dados do colaborador
CREATE OR REPLACE VIEW vw_solicitacoes_completas AS
SELECT 
    s.id,
    s.colaborador_id,
    c.usuario_id,
    u.nome AS colaborador_nome,
    u.email AS colaborador_email,
    s.valor_solicitado,
    s.valor_liquido,
    s.moeda,
    s.metodo_pagamento,
    s.detalhes_conta,
    s.iban_pagamento,
    s.mbway_pagamento,
    s.lightning_address,
    s.status,
    s.etapa_progresso,
    s.taxa_juros_aplicada,
    s.valor_juros,
    s.lida,
    s.data_solicitacao,
    s.data_aprovacao,
    s.data_pagamento,
    s.data_atualizacao
FROM solicitacoes s
INNER JOIN colaboradores c ON s.colaborador_id = c.id
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- View: Estatísticas por colaborador
CREATE OR REPLACE VIEW vw_estatisticas_colaboradores AS
SELECT 
    c.id AS colaborador_id,
    c.usuario_id,
    u.nome,
    c.status,
    c.limite_total,
    c.limite_disponivel,
    COUNT(s.id) AS total_solicitacoes,
    COUNT(CASE WHEN s.status = 'pago' THEN 1 END) AS total_pagas,
    COUNT(CASE WHEN s.status = 'pendente' THEN 1 END) AS total_pendentes,
    SUM(CASE WHEN s.status = 'pago' AND s.moeda = 'EUR' THEN s.valor_solicitado ELSE 0 END) AS total_pago_eur,
    SUM(CASE WHEN s.status = 'pago' AND s.moeda = 'SATS' THEN s.valor_solicitado ELSE 0 END) AS total_pago_sats,
    MAX(s.data_solicitacao) AS data_ultima_solicitacao
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id
LEFT JOIN solicitacoes s ON c.id = s.colaborador_id
GROUP BY c.id, c.usuario_id, u.nome, c.status, c.limite_total, c.limite_disponivel;

-- =====================================================
-- COMENTÁRIOS NAS TABELAS E COLUNAS
-- =====================================================

COMMENT ON TABLE usuarios IS 'Tabela de usuários do sistema (colaboradores e gestores)';
COMMENT ON TABLE colaboradores IS 'Dados profissionais e financeiros dos colaboradores';
COMMENT ON TABLE solicitacoes IS 'Solicitações de adiantamento salarial';
COMMENT ON TABLE notificacoes IS 'Notificações enviadas aos usuários';
COMMENT ON TABLE carteira_gestor IS 'Saldo disponível do gestor para pagamentos';
COMMENT ON TABLE transacoes_carteira IS 'Histórico de movimentações financeiras da carteira';
COMMENT ON TABLE banners IS 'Banners promocionais exibidos no app';
COMMENT ON TABLE cards_anuncio IS 'Cards de anúncios e benefícios';
COMMENT ON TABLE configuracoes_sistema IS 'Configurações gerais do sistema';
COMMENT ON TABLE auditoria IS 'Log de auditoria de ações do sistema';

-- =====================================================
-- FIM DO SCHEMA
-- =====================================================
