# Como Alterar o Remetente "Supabase Auth" para "X88"

Para que o e-mail chegue com o nome **"X88"** (ou qualquer outro) em vez de **"Supabase Auth"**, você precisa configurar um servidor de e-mail próprio (SMTP).

O Supabase usa um servidor genérico por padrão, e por isso não permite mudar o nome do remetente para evitar fraudes (alguém se passando por outro app).

## Solução Recomendada: Usar o Resend (Gratuito e Fácil)

O **Resend** é um serviço parceiro do Supabase que permite enviar até 3.000 e-mails por mês de graça, e permite personalizar o nome do remetente.

### Passo 1: Criar conta no Resend
1. Acesse [resend.com](https://resend.com) e crie uma conta.
2. Você precisará verificar um domínio (ex: `seudominio.com`).
   - *Nota: Se você não tiver um domínio próprio, isso é mais difícil. Serviços profissionais de e-mail exigem um domínio para garantir que você é dono dele.*

### Passo 2: Pegar as Credenciais SMTP no Resend
1. No painel do Resend, vá em **Settings** -> **SMTP**.
2. Copie os dados:
   - **Host:** `smtp.resend.com`
   - **Port:** `465`
   - **Username:** `resend`
   - **Password:** (Gere uma nova API Key se necessário)

### Passo 3: Configurar no Supabase
1. Vá no painel do seu projeto no Supabase.
2. Acesse **Project Settings** (ícone de engrenagem lá embaixo) -> **Authentication**.
3. Role até a seção **SMTP Settings**.
4. Ative a opção **Enable Custom SMTP**.
5. Preencha com os dados do Resend:
   - **Sender Email:** `nao-responda@seudominio.com` (o e-mail que você verificou)
   - **Sender Name:** `Equipe X88` (AQUI é onde você muda o nome!)
   - **Host:** `smtp.resend.com`
   - **Port:** `465`
   - **Username:** `resend`
   - **Password:** `(sua chave API do Resend)`
6. Salve.

## Solução Alternativa: Gmail (Para testes apenas)

Você pode usar uma conta Gmail, mas não é recomendado para produção pois pode ser bloqueado ou cair no spam.

1. Na sua conta Google, ative a "Verificação em duas etapas".
2. Crie uma "Senha de App" (App Password).
3. No Supabase (SMTP Settings):
   - **Sender Email:** `seuemail@gmail.com`
   - **Sender Name:** `Equipe X88`
   - **Host:** `smtp.gmail.com`
   - **Port:** `465`
   - **Username:** `seuemail@gmail.com`
   - **Password:** `(a senha de app gerada)`
   - **Encryption:** `SSL`

---

**Resumo:** Para sumir com o "Supabase Auth", você **obrigatoriamente** precisa preencher essa seção **SMTP Settings** no painel do Supabase.
