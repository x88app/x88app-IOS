-- ==============================================================================
-- FIX FINAL: Resolver loop infinito (Recursão) nas Policies
-- ==============================================================================

-- O problema: A policy da tabela 'usuarios' faz um SELECT na própria tabela 'usuarios'
-- para verificar se o usuário é gestor. Esse SELECT dispara a policy novamente, criando um loop infinito.

-- A SOLUÇÃO: Criar uma função segura (SECURITY DEFINER) para checar permissões
-- sem disparar as policies novamente.

-- 1. Criar função auxiliar que checa se é gestor/admin (Bypassing RLS)
CREATE OR REPLACE FUNCTION public.is_admin_or_gestor()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM public.usuarios
    WHERE id = auth.uid() 
    AND tipo_usuario IN ('gestor', 'admin')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER; -- SECURITY DEFINER é o segredo! Roda como "superuser"

-- 2. Remover policies antigas da tabela USUARIOS
DROP POLICY IF EXISTS "Gestores veem todos usuarios" ON usuarios;
DROP POLICY IF EXISTS "Usuarios veem proprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Usuarios autenticados veem proprio perfil" ON usuarios;

-- 3. Recriar policies da tabela USUARIOS usando a função segura
-- Policy A: O usuário vê a si mesmo (Simples, sem recursão)
CREATE POLICY "Usuarios veem proprio perfil"
    ON usuarios FOR SELECT
    USING (auth.uid() = id);

-- Policy B: Gestores veem todos (Usa a função para evitar o loop)
CREATE POLICY "Gestores veem todos usuarios"
    ON usuarios FOR SELECT
    USING (public.is_admin_or_gestor() = true);


-- 4. Remover e Recriar policies das outras tabelas usando a mesma lógica
-- Isso deixa as queries mais rápidas e limpas também

-- TABELA COLABORADORES
DROP POLICY IF EXISTS "Gestores veem todos colaboradores" ON colaboradores;

CREATE POLICY "Gestores veem todos colaboradores"
    ON colaboradores FOR SELECT
    USING (public.is_admin_or_gestor() = true);

-- TABELA SOLICITACOES
DROP POLICY IF EXISTS "Gestores veem todas solicitacoes" ON solicitacoes;

CREATE POLICY "Gestores veem todas solicitacoes"
    ON solicitacoes FOR SELECT
    USING (public.is_admin_or_gestor() = true);

-- 5. Verificação
SELECT 
    tablename,
    policyname,
    cmd,
    qual
FROM pg_policies
WHERE tablename IN ('usuarios', 'colaboradores', 'solicitacoes')
ORDER BY tablename, policyname;
