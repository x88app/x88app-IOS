-- ==============================================================
-- MIGRAÇÃO: Adicionar campo gestor_id na tabela colaboradores
-- ==============================================================

-- Passo 1: Adicionar campo gestor_id
ALTER TABLE colaboradores 
ADD COLUMN IF NOT EXISTS gestor_id UUID REFERENCES usuarios(id) ON DELETE SET NULL;

-- Passo 2: Criar índice para melhor performance
CREATE INDEX IF NOT EXISTS idx_colaboradores_gestor_id ON colaboradores(gestor_id);

-- Passo 3: Para colaboradores existentes sem gestor, vamos pegar o primeiro gestor disponível
-- (Isso é temporário - idealmente você atribuiria manualmente)
DO $$
DECLARE
    primeiro_gestor_id UUID;
BEGIN
    -- Busca o primeiro gestor ativo
    SELECT id INTO primeiro_gestor_id 
    FROM usuarios 
    WHERE tipo_usuario = 'gestor' 
    AND ativo = TRUE 
    ORDER BY data_criacao ASC 
    LIMIT 1;
    
    -- Atribui o gestor aos colaboradores que não têm gestor
    IF primeiro_gestor_id IS NOT NULL THEN
        UPDATE colaboradores 
        SET gestor_id = primeiro_gestor_id 
        WHERE gestor_id IS NULL;
    END IF;
END $$;

-- Passo 4: Atualizar a view vw_colaboradores_completos para incluir gestor_id
DROP VIEW IF EXISTS vw_colaboradores_completos;

CREATE OR REPLACE VIEW vw_colaboradores_completos AS
SELECT 
    c.id,
    c.usuario_id,
    c.gestor_id,
    u.nome,
    u.email,
    u.telefone,
    u.nif,
    c.iban,
    c.nome_titular_banco,
    c.telefone_mbway,
    c.carteira_lightning,
    c.status,
    c.limite_total,
    c.limite_disponivel,
    c.taxa_juros,
    c.total_adiantamentos,
    c.data_admissao,
    c.data_registro,
    u.ativo AS usuario_ativo
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- Passo 5: Atualizar a view vw_solicitacoes_completas para incluir gestor_id
DROP VIEW IF EXISTS vw_solicitacoes_completas;

CREATE OR REPLACE VIEW vw_solicitacoes_completas AS
SELECT 
    s.id,
    s.colaborador_id,
    c.usuario_id,
    c.gestor_id,
    u.nome AS colaborador_nome,
    u.email AS colaborador_email,
    s.valor_solicitado,
    s.valor_liquido,
    s.moeda,
    s.metodo_pagamento,
    s.detalhes_conta,
    s.iban_pagamento,
    s.mbway_pagamento,
    s.lightning_address,
    s.status,
    s.etapa_progresso,
    s.taxa_juros_aplicada,
    s.valor_juros,
    s.lida,
    s.data_solicitacao,
    s.data_aprovacao,
    s.data_pagamento,
    s.data_atualizacao
FROM solicitacoes s
INNER JOIN colaboradores c ON s.colaborador_id = c.id
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- Passo 6: Atualizar políticas RLS para considerar gestor_id

-- Política para gestor ver apenas seus colaboradores
DROP POLICY IF EXISTS "Gestores podem ver seus colaboradores" ON colaboradores;
CREATE POLICY "Gestores podem ver seus colaboradores"
ON colaboradores FOR SELECT
USING (
    auth.uid() IN (
        SELECT id FROM usuarios WHERE tipo_usuario = 'gestor' AND ativo = TRUE
    )
    AND gestor_id = auth.uid()
);

-- Política para gestor ver apenas solicitações de seus colaboradores
DROP POLICY IF EXISTS "Gestores podem ver solicitações de seus colaboradores" ON solicitacoes;
CREATE POLICY "Gestores podem ver solicitações de seus colaboradores"
ON solicitacoes FOR SELECT
USING (
    colaborador_id IN (
        SELECT id FROM colaboradores WHERE gestor_id = auth.uid()
    )
);

-- Política para gestor atualizar solicitações de seus colaboradores
DROP POLICY IF EXISTS "Gestores podem atualizar solicitações de seus colaboradores" ON solicitacoes;
CREATE POLICY "Gestores podem atualizar solicitações de seus colaboradores"
ON solicitacoes FOR UPDATE
USING (
    colaborador_id IN (
        SELECT id FROM colaboradores WHERE gestor_id = auth.uid()
    )
)
WITH CHECK (
    colaborador_id IN (
        SELECT id FROM colaboradores WHERE gestor_id = auth.uid()
    )
);

-- Política para colaborador ver apenas seus próprios dados
DROP POLICY IF EXISTS "Colaboradores podem ver seus próprios dados" ON colaboradores;
CREATE POLICY "Colaboradores podem ver seus próprios dados"
ON colaboradores FOR SELECT
USING (usuario_id = auth.uid());

-- Mensagem de confirmação
DO $$
BEGIN
    RAISE NOTICE 'Migração concluída com sucesso! Campo gestor_id adicionado à tabela colaboradores.';
END $$;
