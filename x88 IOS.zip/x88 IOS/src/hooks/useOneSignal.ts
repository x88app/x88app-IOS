// Arquivo obsoleto mantido vazio para evitar erro de build no Netlify
// Será removido em limpeza futura
export {};
