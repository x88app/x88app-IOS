import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

let cachedEmail: string | null = null
let isFetching = false
let fetchPromise: Promise<string | null> | null = null

const fetchGestorEmailFromDB = async (): Promise<string | null> => {
  try {
    // Buscar da tabela de configurações globais (compartilhada entre todos os gestores)
    const { data: configData, error } = await supabase
      .from('configuracoes_globais')
      .select('email_suporte')
      .limit(1)
      .maybeSingle()

    if (!error && configData?.email_suporte) {
      return configData.email_suporte
    }

    // Fallback: buscar do primeiro gestor ativo (compatibilidade)
    const { data: adminData } = await supabase
      .from('usuarios')
      .select('email_suporte')
      .eq('tipo_usuario', 'gestor')
      .eq('ativo', true)
      .limit(1)
      .maybeSingle()

    return adminData?.email_suporte || null
  } catch (error) {
    console.error('Erro ao buscar email do gestor:', error)
    return null
  }
}

export const useGestorEmail = () => {
  const [gestorEmail, setGestorEmail] = useState<string | null>(cachedEmail)

  useEffect(() => {
    if (cachedEmail) {
      setGestorEmail(cachedEmail)
      return
    }

    if (isFetching && fetchPromise) {
      fetchPromise.then(email => {
        setGestorEmail(email)
      })
      return
    }

    isFetching = true
    fetchPromise = fetchGestorEmailFromDB()
    
    fetchPromise.then(email => {
      cachedEmail = email
      isFetching = false
      setGestorEmail(email)
    })
  }, [])

  const handleContactEmail = () => {
    if (gestorEmail) {
      window.open(`mailto:${gestorEmail}`, '_blank')
    }
  }

  return { gestorEmail, handleContactEmail }
}
