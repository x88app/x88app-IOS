import { useNavigate, useSearchParams } from 'react-router-dom'

export function useBackNavigation(defaultPath: string = '/') {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()

  const goBack = () => {
    const fromChat = searchParams.get('from') === 'chat'
    const fromChatPopup = searchParams.get('from') === 'chatpopup'
    
    if (fromChat) {
      navigate('/chat')
    } else if (fromChatPopup) {
      // Sinalizar para reabrir o ChatPopup na Home
      sessionStorage.setItem('x88_chat_return', 'true')
      navigate('/')
    } else {
      navigate(defaultPath)
    }
  }

  return { goBack }
}
