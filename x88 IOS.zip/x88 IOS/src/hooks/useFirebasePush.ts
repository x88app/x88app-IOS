import { useEffect, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { FirebaseMessaging } from '@capacitor-firebase/messaging'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'

export const useFirebasePush = () => {
  const [token, setToken] = useState<string | null>(null)
  const [permissionGranted, setPermissionGranted] = useState(false)
  const { user } = useAuth()

  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      initFirebaseMessaging()
    }
  }, [])

  useEffect(() => {
    if (token && user?.id) {
      saveTokenToDatabase(token)
    }
  }, [token, user?.id])

  const initFirebaseMessaging = async () => {
    try {
      const permStatus = await FirebaseMessaging.checkPermissions()
      
      if (permStatus.receive === 'prompt') {
        const result = await FirebaseMessaging.requestPermissions()
        if (result.receive !== 'granted') {
          console.log('Permissão de notificações negada')
          return
        }
      }
      
      if (permStatus.receive !== 'granted') {
        const result = await FirebaseMessaging.requestPermissions()
        if (result.receive !== 'granted') {
          console.log('Permissão de notificações não concedida')
          return
        }
      }

      setPermissionGranted(true)

      const { token: fcmToken } = await FirebaseMessaging.getToken()
      if (fcmToken) {
        console.log('FCM Token:', fcmToken)
        setToken(fcmToken)
      }

      FirebaseMessaging.addListener('tokenReceived', (event) => {
        console.log('Token received:', event.token)
        setToken(event.token)
      })

      FirebaseMessaging.addListener('notificationReceived', (event) => {
        console.log('Notification received:', event.notification)
      })

      FirebaseMessaging.addListener('notificationActionPerformed', (event) => {
        console.log('Notification action performed:', event)
        const data = event.notification.data
        if (data?.url) {
          window.location.href = data.url as string
        }
      })

    } catch (error) {
      console.error('Erro ao inicializar Firebase Messaging:', error)
    }
  }

  const saveTokenToDatabase = async (fcmToken: string) => {
    if (!user?.id) return
    
    try {
      const platform = Capacitor.getPlatform()
      const updateData: Record<string, any> = {
        fcm_token: fcmToken,
        fcm_token_updated_at: new Date().toISOString(),
        device_platform: platform
      }

      const { error } = await supabase
        .from('colaboradores')
        .update(updateData)
        .eq('usuario_id', user.id)

      if (error) {
        console.error('Erro ao salvar FCM token:', error)
      } else {
        console.log('FCM Token salvo com sucesso!')
      }
    } catch (error) {
      console.error('Erro ao salvar token:', error)
    }
  }

  const requestPermission = async () => {
    const result = await FirebaseMessaging.requestPermissions()
    const granted = result.receive === 'granted'
    setPermissionGranted(granted)
    
    if (granted) {
      const { token: fcmToken } = await FirebaseMessaging.getToken()
      if (fcmToken) {
        setToken(fcmToken)
      }
    }
    
    return granted
  }

  const getToken = async () => {
    const { token: fcmToken } = await FirebaseMessaging.getToken()
    if (fcmToken) {
      setToken(fcmToken)
    }
    return fcmToken
  }

  return {
    token,
    permissionGranted,
    requestPermission,
    getToken,
    isNative: Capacitor.isNativePlatform()
  }
}
