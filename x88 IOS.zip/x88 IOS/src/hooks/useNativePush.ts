import { useEffect, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { PushNotifications, Token, PushNotificationSchema, ActionPerformed } from '@capacitor/push-notifications'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'

export const useNativePush = () => {
  const [token, setToken] = useState<string | null>(null)
  const [permissionGranted, setPermissionGranted] = useState(false)
  const { user } = useAuth()

  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      initPushNotifications()
    }
  }, [])

  useEffect(() => {
    if (token && user?.id) {
      saveTokenToDatabase(token)
    }
  }, [token, user?.id])

  const initPushNotifications = async () => {
    try {
      const permStatus = await PushNotifications.checkPermissions()
      
      if (permStatus.receive === 'prompt') {
        const result = await PushNotifications.requestPermissions()
        if (result.receive !== 'granted') {
          console.log('Permissão de notificações negada')
          return
        }
      }
      
      if (permStatus.receive !== 'granted') {
        console.log('Permissão de notificações não concedida')
        return
      }

      setPermissionGranted(true)
      await PushNotifications.register()

      PushNotifications.addListener('registration', (token: Token) => {
        console.log('Push registration success, token:', token.value)
        setToken(token.value)
      })

      PushNotifications.addListener('registrationError', (error: any) => {
        console.error('Push registration error:', error.error)
      })

      PushNotifications.addListener('pushNotificationReceived', (notification: PushNotificationSchema) => {
        console.log('Push notification received:', notification)
      })

      PushNotifications.addListener('pushNotificationActionPerformed', (action: ActionPerformed) => {
        console.log('Push notification action performed:', action)
        const data = action.notification.data
        if (data?.url) {
          window.location.href = data.url
        }
      })

    } catch (error) {
      console.error('Erro ao inicializar push notifications:', error)
    }
  }

  const saveTokenToDatabase = async (pushToken: string) => {
    if (!user?.id) return
    
    try {
      const { error } = await supabase
        .from('colaboradores')
        .update({ 
          push_token_ios: pushToken,
          push_token_updated_at: new Date().toISOString()
        })
        .eq('usuario_id', user.id)

      if (error) {
        console.error('Erro ao salvar token push:', error)
      } else {
        console.log('Token push salvo com sucesso!')
      }
    } catch (error) {
      console.error('Erro ao salvar token:', error)
    }
  }

  const requestPermission = async () => {
    if (!Capacitor.isNativePlatform()) {
      console.log('Push notifications só funcionam em dispositivos nativos')
      return false
    }

    const result = await PushNotifications.requestPermissions()
    const granted = result.receive === 'granted'
    setPermissionGranted(granted)
    
    if (granted) {
      await PushNotifications.register()
    }
    
    return granted
  }

  return {
    token,
    permissionGranted,
    requestPermission,
    isNative: Capacitor.isNativePlatform()
  }
}
