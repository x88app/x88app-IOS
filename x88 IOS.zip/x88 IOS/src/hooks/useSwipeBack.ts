import { useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'

interface SwipeBackOptions {
  threshold?: number
  enabled?: boolean
}

export function useSwipeBack(options: SwipeBackOptions = {}) {
  const { threshold = 80, enabled = true } = options
  const navigate = useNavigate()
  const touchStartX = useRef<number>(0)
  const touchStartY = useRef<number>(0)
  const touchEndX = useRef<number>(0)

  useEffect(() => {
    if (!enabled) return

    const handleTouchStart = (e: TouchEvent) => {
      touchStartX.current = e.touches[0].clientX
      touchStartY.current = e.touches[0].clientY
    }

    const handleTouchMove = (e: TouchEvent) => {
      touchEndX.current = e.touches[0].clientX
    }

    const handleTouchEnd = () => {
      const deltaX = touchEndX.current - touchStartX.current
      const deltaY = Math.abs(touchEndX.current - touchStartY.current)
      
      // Só volta se:
      // 1. O swipe começou perto da borda esquerda (primeiros 50px)
      // 2. O movimento horizontal foi maior que o threshold
      // 3. O movimento foi mais horizontal que vertical
      if (
        touchStartX.current < 50 &&
        deltaX > threshold &&
        deltaX > deltaY
      ) {
        navigate(-1)
      }

      // Reset
      touchStartX.current = 0
      touchStartY.current = 0
      touchEndX.current = 0
    }

    document.addEventListener('touchstart', handleTouchStart, { passive: true })
    document.addEventListener('touchmove', handleTouchMove, { passive: true })
    document.addEventListener('touchend', handleTouchEnd, { passive: true })

    return () => {
      document.removeEventListener('touchstart', handleTouchStart)
      document.removeEventListener('touchmove', handleTouchMove)
      document.removeEventListener('touchend', handleTouchEnd)
    }
  }, [navigate, threshold, enabled])
}
