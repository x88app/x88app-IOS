import { useEffect } from 'react'
import { Capacitor } from '@capacitor/core'
import { StatusBar, Style } from '@capacitor/status-bar'

export const useStatusBar = () => {
  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      configureStatusBar()
    }
  }, [])

  const configureStatusBar = async () => {
    try {
      await StatusBar.show()
      await StatusBar.setOverlaysWebView({ overlay: false })
      await StatusBar.setStyle({ style: Style.Dark })
      if (Capacitor.getPlatform() === 'android') {
        await StatusBar.setBackgroundColor({ color: '#FFFFFF' })
      }
    } catch (error) {
      console.error('Erro ao configurar StatusBar:', error)
    }
  }

  const setDarkStatusBar = async () => {
    if (!Capacitor.isNativePlatform()) return
    try {
      await StatusBar.setStyle({ style: Style.Light })
      await StatusBar.setBackgroundColor({ color: '#000000' })
    } catch (error) {
      console.error('Erro ao configurar StatusBar:', error)
    }
  }

  const setLightStatusBar = async () => {
    if (!Capacitor.isNativePlatform()) return
    try {
      await StatusBar.setStyle({ style: Style.Dark })
      await StatusBar.setBackgroundColor({ color: '#FFFFFF' })
    } catch (error) {
      console.error('Erro ao configurar StatusBar:', error)
    }
  }

  return {
    setDarkStatusBar,
    setLightStatusBar
  }
}
