import { useEffect, useState } from 'react'
import { ArrowDownLeft, Euro, Calendar } from 'lucide-react'
import { useRequests } from '../../contexts/RequestsContext'
import { FormattedDate } from '../../components/FormattedDate'
import { useLanguage } from '../../contexts/LanguageContext'
import { formatNextMondayDate } from '../../lib/dateUtils'

const Wallet = () => {
  const { requests } = useRequests()
  const { formatCurrency, currencySymbol, language } = useLanguage()
  const isBR = language === 'pt-BR'
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    setIsAnimating(true)
  }, [])

  const paidPayments = requests.filter((r) => r.status === 'paid')
  const totalReceived = paidPayments.reduce((sum, payment) => sum + payment.amount, 0) // Agora soma o valor recebido (amount)

  return (
    <div className={`p-4 pb-20 space-y-6 transition-all duration-700 ${
      isAnimating ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
    }`}>
      <div>
        <h2 className="text-2xl font-bold text-black dark:text-white">Meu Histórico</h2>
        <p className="text-neutral-600 dark:text-neutral-400 mt-1">
          Histórico de pagamentos recebidos
        </p>
      </div>

      <div className="card bg-gradient-to-br from-brand-600 to-brand-700 text-white">
        <div className="flex items-center gap-2 mb-2">
          {isBR ? (
            <span className="text-lg font-bold text-white/90">{currencySymbol}</span>
          ) : (
            <Euro className="w-5 h-5" />
          )}
          <span className="text-sm font-medium opacity-90">Total Recebido</span>
        </div>
        <p className="text-4xl font-bold">{formatCurrency(totalReceived)}</p>
        <p className="text-sm opacity-75 mt-2">Todos os tempos</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="card">
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-1">Pagamentos</p>
          <p className="text-2xl font-bold text-black dark:text-white">{paidPayments.length}</p>
        </div>
        <div className="card">
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-1">Média</p>
          <p className="text-2xl font-bold text-black dark:text-white">
            {paidPayments.length > 0 ? formatCurrency(totalReceived / paidPayments.length) : formatCurrency(0)}
          </p>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-bold text-black dark:text-white mb-4">
          Histórico de Pagamentos
        </h3>

        {paidPayments.length === 0 ? (
          <div className="card text-center py-8">
            {isBR ? (
              <span className="text-4xl font-bold text-neutral-300 dark:text-neutral-700 mx-auto mb-3 block">{currencySymbol}</span>
            ) : (
              <Euro className="w-12 h-12 text-neutral-300 dark:text-neutral-700 mx-auto mb-3" />
            )}
            <p className="text-neutral-600 dark:text-neutral-400">
              Você ainda não recebeu nenhum pagamento.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {paidPayments
              .sort((a, b) => b.createdAt - a.createdAt)
              .map((payment) => {
                const interestFee = payment.netAmount - payment.amount // Taxa de serviço
                return (
                  <div key={payment.id} className="card">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-950 flex items-center justify-center">
                          <ArrowDownLeft className="w-5 h-5 text-brand-600" />
                        </div>
                        <div>
                          <h4 className="font-bold text-black dark:text-white">
                            Pedido via {payment.paymentMethod === 'mbway' ? (isBR ? 'PIX' : 'MB Way') : (isBR ? 'Conta Bancária' : 'IBAN')}
                          </h4>
                          <p className="text-sm text-neutral-600 dark:text-neutral-400">
                            {payment.accountDetails || 'Sem detalhes'}
                          </p>
                        </div>
                      </div>
                      <span className="status-success text-xs">Recebido</span>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-neutral-200 dark:border-neutral-800">
                      <div>
                        <p className="text-xs text-neutral-600 dark:text-neutral-400">Valor recebido na sua conta bancária</p>
                        <p className="text-xl font-bold text-brand-600">{formatCurrency(payment.amount)}</p>
                        <p className="text-xs text-neutral-500 dark:text-neutral-500">
                          Valor pendente: {formatCurrency(payment.netAmount)} (taxa de serviço +{formatCurrency(interestFee)})
                        </p>
                        <p className="text-xs text-neutral-400 dark:text-neutral-500">
                          em {formatNextMondayDate(payment.paymentDate ? new Date(payment.paymentDate) : new Date(payment.createdAt))}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-1 text-neutral-600 dark:text-neutral-400">
                          <Calendar className="w-3 h-3" />
                          <p className="text-xs">
                            <FormattedDate date={payment.createdAt} options={{
                              day: '2-digit',
                              month: 'short',
                            }} />
                          </p>
                        </div>
                        <p className="text-xs text-neutral-500 dark:text-neutral-500">
                          <FormattedDate date={payment.createdAt} options={{
                            hour: '2-digit',
                            minute: '2-digit',
                          }} />
                        </p>
                      </div>
                    </div>
                  </div>
                )
              })}
          </div>
        )}
      </div>
    </div>
  )
}

export default Wallet
