import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, Clock, CheckCircle, XCircle, Calendar, Euro, FileText, Check, CreditCard, TrendingUp, ArrowLeftRight, User, Phone, DollarSign } from 'lucide-react'
import { useRequests } from '../../contexts/RequestsContext'
import { FormattedDate } from '../../components/FormattedDate'
import { useLanguage } from '../../contexts/LanguageContext'
import { formatNextMondayDate } from '../../lib/dateUtils'
import { useConfiguracoesGlobais } from '../../hooks/useConfiguracoesGlobais'

const RequestDetails = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { getRequestById } = useRequests()
  const { formatCurrency, language } = useLanguage()
  const isBR = language === 'pt-BR'
  const [isAnimating, setIsAnimating] = useState(false)
  const { config, handleContactWhatsapp } = useConfiguracoesGlobais()

  const request = getRequestById(id || '')

  useEffect(() => {
    setIsAnimating(true)
  }, [])

  if (!request) {
    return (
      <div className="p-4">
        <div className="flex items-center gap-3 mb-6">
          <button
            onClick={() => navigate(-1)}
            className="p-4 -m-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 active:bg-neutral-200 dark:active:bg-neutral-700"
          >
            <ArrowLeft className="w-6 h-6 text-neutral-600 dark:text-neutral-400" />
          </button>
          <h2 className="text-2xl font-bold text-black dark:text-white">Solicitação não encontrada</h2>
        </div>
        <div className="card text-center">
          <p className="text-neutral-600 dark:text-neutral-400">
            A solicitação que você está procurando não existe.
          </p>
        </div>
      </div>
    )
  }

  const serviceFee = request.netAmount - request.amount // Taxa de serviço (netAmount agora é o valor a descontar)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400 rounded-full text-sm font-medium">
            <Clock className="w-4 h-4" />
            Pendente
          </div>
        )
      case 'processing':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 rounded-full text-sm font-medium">
            <Clock className="w-4 h-4" />
            Em Análise
          </div>
        )
      case 'approved':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#00d749]/10 text-[#00d749] rounded-full text-sm font-medium">
            <CheckCircle className="w-4 h-4" />
            Aprovada
          </div>
        )
      case 'rejected':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 rounded-full text-sm font-medium">
            <XCircle className="w-4 h-4" />
            Rejeitada
          </div>
        )
      case 'paid':
        return (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#00d749]/10 text-[#00d749] rounded-full text-sm font-medium">
            <CheckCircle className="w-4 h-4" />
            Paga
          </div>
        )
      default:
        return null
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Pendente'
      case 'processing':
        return 'Em Análise'
      case 'approved':
        return 'Aprovada'
      case 'rejected':
        return 'Rejeitada'
      case 'paid':
        return 'Paga'
      default:
        return status
    }
  }

  return (
    <div className={`p-4 pb-20 space-y-6 transition-all duration-700 ${
      isAnimating ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
    }`}>
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate(-1)}
          className="p-4 -m-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 active:bg-neutral-200 dark:active:bg-neutral-700"
        >
          <ArrowLeft className="w-6 h-6 text-neutral-600 dark:text-neutral-400" />
        </button>
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-black dark:text-white">Detalhes</h2>
        </div>
        {getStatusBadge(request.status)}
      </div>

      <div className={`card text-center ${request.currency === 'SATS' ? 'bg-[#E69F39]/10 border-[#E69F39]' : 'bg-[#00d749]/10 border-[#00d749]'}`}>
        <p className="text-neutral-600 dark:text-neutral-400 mb-2">{request.status === 'paid' ? 'Você Recebeu' : 'Você Receberá'}</p>
        <p className={`text-5xl font-bold mb-4 ${request.currency === 'SATS' ? 'text-[#E69F39]' : 'text-[#00d749]'}`}>
          {request.currency === 'SATS' ? `${request.amount} sats` : formatCurrency(request.amount)}
        </p>
        <div className="flex items-center justify-center gap-4 text-sm">
          <div>
            <p className="text-neutral-600 dark:text-neutral-400">Taxa de Serviço</p>
            <p className="font-semibold text-orange-500">
              {request.currency === 'SATS' ? `+${serviceFee} sats` : `+${formatCurrency(serviceFee)}`}
            </p>
          </div>
          <div className="w-px h-8 bg-neutral-300 dark:bg-neutral-700"></div>
          <div>
            <p className="text-neutral-600 dark:text-neutral-400">
              {request.descontado ? 'Processado' : 'Valor Pendente'}
            </p>
            <p className={`font-semibold ${request.descontado ? 'text-green-600 dark:text-green-400' : 'text-red-600'}`}>
              {request.currency === 'SATS' ? `${Math.round(request.netAmount)} sats` : formatCurrency(request.netAmount)}
            </p>
          </div>
        </div>
        {request.status !== 'paid' && request.status !== 'rejected' && (
          <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-700">
            <Calendar className="w-4 h-4 text-red-500" />
            <span className="text-sm text-red-500 font-medium">
              Processamento em: {formatNextMondayDate()}
            </span>
          </div>
        )}
        {request.descontado && (
          <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-950/30 -mx-4 -mb-4 px-4 py-3 rounded-b-xl">
            <div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center">
              <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <span className="text-sm text-green-700 dark:text-green-400 font-semibold">
              Valor processado
            </span>
          </div>
        )}
      </div>

      <div className="card space-y-4">
        <h3 className="font-bold text-black dark:text-white text-lg mb-2">Dados da Solicitação</h3>
        
        <div className="flex items-start gap-3">
          <User className="w-5 h-5 text-[#00d749] mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-neutral-600 dark:text-neutral-400">Nome Completo</p>
            <p className="font-semibold text-black dark:text-white">João Silva</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Phone className="w-5 h-5 text-[#00d749] mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-neutral-600 dark:text-neutral-400">Telefone</p>
            <p className="font-semibold text-black dark:text-white">+351 912 345 678</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          {isBR ? <DollarSign className="w-5 h-5 text-[#00d749] mt-0.5" /> : <Euro className="w-5 h-5 text-[#00d749] mt-0.5" />}
          <div className="flex-1">
            <p className="text-sm text-neutral-600 dark:text-neutral-400">Método de Recebimento</p>
            <p className="font-semibold text-black dark:text-white">
              {request.paymentMethod === 'mbway' ? (isBR ? 'PIX' : 'MB Way') : (isBR ? 'Conta Bancária' : 'IBAN')}
            </p>
            <p className="text-sm font-mono text-neutral-600 dark:text-neutral-400 mt-1 bg-neutral-100 dark:bg-neutral-800 px-3 py-2 rounded-lg">
              {request.paymentMethod === 'mbway' ? '+351 912 345 678' : (request.accountDetails || 'Não informado')}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Calendar className="w-5 h-5 text-[#00d749] mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-neutral-600 dark:text-neutral-400">Data da Solicitação</p>
            <p className="font-semibold text-black dark:text-white">
              <FormattedDate date={request.createdAt} options={{
                day: '2-digit',
                month: 'long',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              }} />
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <FileText className="w-5 h-5 text-[#00d749] mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-neutral-600 dark:text-neutral-400">Status</p>
            <p className="font-semibold text-black dark:text-white">{getStatusLabel(request.status)}</p>
          </div>
        </div>
      </div>

      <div className="card">
        <h3 className="font-bold text-black dark:text-white mb-4">Linha do Tempo</h3>
        <div className="space-y-4">
          {/* 1. Solicitação Enviada */}
          <div className="flex gap-3">
            <div className="flex flex-col items-center flex-shrink-0">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                request.progressStep >= 0 ? 'bg-[#00d749]' : 'bg-neutral-200 dark:bg-neutral-800'
              }`}>
                <Clock className={`w-5 h-5 flex-shrink-0 ${
                  request.progressStep >= 0 ? 'text-white' : 'text-neutral-400'
                }`} />
              </div>
              {request.progressStep > 0 && request.status !== 'rejected' && (
                <div className="w-0.5 h-full bg-[#00d749] mt-2"></div>
              )}
            </div>
            <div className="flex-1 pb-4">
              <p className={`font-semibold ${
                request.progressStep >= 0 ? 'text-[#00d749]' : 'text-neutral-400'
              }`}>
                Solicitação Enviada
              </p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                <FormattedDate date={request.createdAt} options={{
                  day: '2-digit',
                  month: 'long',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                }} />
              </p>
            </div>
          </div>

          {/* 2. Em Análise */}
          <div className="flex gap-3">
            <div className="flex flex-col items-center flex-shrink-0">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                request.progressStep >= 1 ? 'bg-[#00d749]' : 'bg-neutral-200 dark:bg-neutral-800'
              }`}>
                <TrendingUp className={`w-5 h-5 flex-shrink-0 ${
                  request.progressStep >= 1 ? 'text-white' : 'text-neutral-400'
                }`} />
              </div>
              {request.progressStep > 1 && request.status !== 'rejected' && (
                <div className="w-0.5 h-full bg-[#00d749] mt-2"></div>
              )}
            </div>
            <div className="flex-1 pb-4">
              <p className={`font-semibold ${
                request.progressStep >= 1 ? 'text-[#00d749]' : 'text-neutral-400'
              }`}>
                Em Análise
              </p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Sua solicitação está sendo analisada
              </p>
            </div>
          </div>

          {/* 3. Processando */}
          <div className="flex gap-3">
            <div className="flex flex-col items-center flex-shrink-0">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                request.progressStep >= 2 ? 'bg-[#00d749]' : 'bg-neutral-200 dark:bg-neutral-800'
              }`}>
                <CreditCard className={`w-5 h-5 flex-shrink-0 ${
                  request.progressStep >= 2 ? 'text-white' : 'text-neutral-400'
                }`} />
              </div>
              {request.progressStep > 2 && request.status !== 'rejected' && (
                <div className="w-0.5 h-full bg-[#00d749] mt-2"></div>
              )}
            </div>
            <div className="flex-1 pb-4">
              <p className={`font-semibold ${
                request.progressStep >= 2 ? 'text-[#00d749]' : 'text-neutral-400'
              }`}>
                Processando
              </p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Preparando aprovação da solicitação
              </p>
            </div>
          </div>

          {/* 4. Aprovado/Rejeitado */}
          {request.status === 'rejected' ? (
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="flex flex-col items-center flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center flex-shrink-0">
                    <XCircle className="w-5 h-5 text-white flex-shrink-0" />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-red-600">Negado</p>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Sua solicitação não foi aprovada desta vez
                  </p>
                </div>
              </div>
              
              <div className="p-4 bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 rounded-xl">
                <p className="text-sm text-red-700 dark:text-red-500">
                  <strong>Motivo:</strong> Sua solicitação foi analisada e não atendeu aos critérios necessários para aprovação. 
                  Entre em contato com o suporte para mais informações.
                </p>
              </div>

              {config.whatsapp_suporte && (
                <button
                  onClick={handleContactWhatsapp}
                  className="w-full py-3 bg-[#25D366] text-white font-semibold rounded-xl hover:bg-[#20BD5A] transition-colors flex items-center justify-center gap-2"
                >
                  <img 
                    src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
                    alt="WhatsApp" 
                    className="w-5 h-5"
                  />
                  Falar com Suporte
                </button>
              )}
            </div>
          ) : (
            <div className="flex gap-3">
              <div className="flex flex-col items-center flex-shrink-0">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                  request.progressStep >= 3 ? 'bg-[#00d749]' : 'bg-neutral-200 dark:bg-neutral-800'
                }`}>
                  <Check className={`w-5 h-5 flex-shrink-0 ${
                    request.progressStep >= 3 ? 'text-white' : 'text-neutral-400'
                  }`} />
                </div>
                {request.progressStep > 3 && (
                  <div className="w-0.5 h-full bg-[#00d749] mt-2"></div>
                )}
              </div>
              <div className="flex-1 pb-4">
                <p className={`font-semibold ${
                  request.progressStep >= 3 ? 'text-[#00d749]' : 'text-neutral-400'
                }`}>
                  Aprovado
                </p>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  Solicitação aprovada, aguardando pagamento
                </p>
              </div>
            </div>
          )}

          {/* 5. Transferido */}
          {request.status !== 'rejected' && (
            <div className="flex gap-3">
              <div className="flex flex-col items-center flex-shrink-0">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                  request.progressStep >= 4 ? 'bg-[#00d749]' : 'bg-neutral-200 dark:bg-neutral-800'
                }`}>
                  <ArrowLeftRight className={`w-6 h-6 flex-shrink-0 ${
                    request.progressStep >= 4 ? 'text-white' : 'text-neutral-400'
                  }`} />
                </div>
              </div>
              <div className="flex-1">
                <p className={`font-semibold ${
                  request.progressStep >= 4 ? 'text-[#00d749]' : 'text-neutral-400'
                }`}>
                  Transferido
                </p>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  O pagamento foi transferido para sua conta
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {request.status === 'approved' && (
        <div className="card bg-[#00d749]/10 border-[#00d749]">
          <h3 className="text-lg font-bold text-black dark:text-white mb-2">
            Aguardando Pagamento
          </h3>
          <p className="text-neutral-700 dark:text-neutral-300">
            Sua solicitação foi aprovada! O pagamento será processado em breve e você receberá uma notificação.
          </p>
        </div>
      )}
    </div>
  )
}

export default RequestDetails
