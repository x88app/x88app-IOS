import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, Euro, CreditCard, Smartphone, Zap, DollarSign, Calendar } from 'lucide-react'
import { useRequests } from '../../contexts/RequestsContext'
import { useAuth } from '../../contexts/AuthContext'
import { useLanguage } from '../../contexts/LanguageContext'
import { formatNextMondayDate } from '../../lib/dateUtils'

const NewRequest = () => {
  const navigate = useNavigate()
  const { addRequest } = useRequests()
  const { user } = useAuth()
  const { formatCurrency, currencySymbol, language } = useLanguage()
  const isBR = language === 'pt-BR'
  
  const interestRate = user?.interestRate || 10
  const interestRateDecimal = interestRate / 100
  const discountMultiplier = 1 + interestRateDecimal // Nova lógica: valor + taxa para desconto

  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    amount: '',
    payoutMethod: 'mbway',
  })

  useEffect(() => {
    if (user?.bankDetails?.preferredMethod) {
      setFormData(prev => ({
        ...prev,
        payoutMethod: user.bankDetails.preferredMethod
      }))
    }
  }, [user])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (step < 2) {
      setStep(step + 1)
    } else {
      const amount = parseFloat(formData.amount)
      const discountAmount = amount * discountMultiplier // Valor a descontar do salário
      
      addRequest({
        amount,
        paymentMethod: formData.payoutMethod.toLowerCase() as 'mbway' | 'iban' | 'satoshi',
        status: 'pending',
        date: new Date().toISOString(),
        netAmount: discountAmount, // Valor a descontar
        accountDetails: formData.payoutMethod,
      })
      
      navigate('/')
    }
  }

  const canProceed = () => {
    return formData.amount && parseFloat(formData.amount) > 0
  }

  return (
    <div className="p-4 space-y-6">
      <div className="flex items-center gap-3">
        <button
          onClick={() => (step > 1 ? setStep(step - 1) : navigate(-1))}
          className="p-4 -m-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 active:bg-neutral-200 dark:active:bg-neutral-700"
        >
          <ArrowLeft className="w-6 h-6 text-neutral-600 dark:text-neutral-400" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-black dark:text-white">
            Nova Solicitação
          </h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            Passo {step} de 2
          </p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="flex gap-2">
        {[1, 2].map((s) => (
          <div
            key={s}
            className={`h-1 flex-1 rounded-full ${
              s <= step ? 'bg-[#00d749]' : 'bg-neutral-200 dark:bg-neutral-800'
            }`}
          />
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {step === 1 && (
          <div className="space-y-6">
            <div className="card">
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                {language === 'pt-BR' ? <DollarSign className="w-4 h-4 inline mr-2" /> : <Euro className="w-4 h-4 inline mr-2" />}
                Valor do Adiantamento
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-neutral-400">
                  {currencySymbol}
                </span>
                <input
                  type="number"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="input w-full pl-12 text-2xl font-bold"
                  placeholder="0"
                  step="0.01"
                  min="0"
                  required
                />
              </div>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
                Valor total com taxa ({interestRate}% de taxa de serviço): 
                {' '}{formData.amount ? formatCurrency(parseFloat(formData.amount) * discountMultiplier) : formatCurrency(0)}
              </p>
            </div>

            <div className="card">
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-3">
                Método de Recebimento
              </label>
              <div className="space-y-3">
                {/* MB Way */}
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, payoutMethod: 'mbway' })}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                    formData.payoutMethod === 'mbway'
                      ? 'border-[#00d749] bg-[#00d749]/10'
                      : 'border-neutral-200 dark:border-neutral-800'
                  }`}
                >
                  <Smartphone className="w-6 h-6 text-[#00d749]" />
                  <div className="text-left">
                    <p className="font-medium text-black dark:text-white">{isBR ? 'PIX' : 'MB Way'}</p>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">
                      {user?.bankDetails?.mbwayPhone || 'Não configurado'}
                    </p>
                  </div>
                </button>

                {/* IBAN */}
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, payoutMethod: 'iban' })}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                    formData.payoutMethod === 'iban'
                      ? 'border-[#00d749] bg-[#00d749]/10'
                      : 'border-neutral-200 dark:border-neutral-800'
                  }`}
                >
                  <CreditCard className="w-6 h-6 text-[#00d749]" />
                  <div className="text-left">
                    <p className="font-medium text-black dark:text-white">{isBR ? 'Conta Bancária' : 'IBAN'}</p>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400 font-mono truncate max-w-[200px]">
                      {user?.bankDetails?.iban || 'Não configurado'}
                    </p>
                  </div>
                </button>
                
                {/* SATOSHI */}
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, payoutMethod: 'satoshi' })}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                    formData.payoutMethod === 'satoshi'
                      ? 'border-[#f7931a] bg-[#f7931a]/10'
                      : 'border-neutral-200 dark:border-neutral-800'
                  }`}
                >
                  <Zap className="w-6 h-6 text-[#f7931a]" />
                  <div className="text-left">
                    <p className="font-medium text-black dark:text-white">Lightning Network (Sats)</p>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">
                      {user?.bankDetails?.wallet ? 'Carteira configurada' : 'Não configurada'}
                    </p>
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="card bg-[#00d749]/10 border-[#00d749]">
              <h3 className="text-lg font-bold text-black dark:text-white mb-4">
                Confirme os Dados
              </h3>

              <div className="space-y-3">
                <div className="flex justify-between py-2 border-b border-neutral-200 dark:border-neutral-800">
                  <span className="text-neutral-600 dark:text-neutral-400">Valor solicitado</span>
                  <span className="font-bold text-black dark:text-white">{formatCurrency(parseFloat(formData.amount))}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-neutral-200 dark:border-neutral-800">
                  <span className="text-neutral-600 dark:text-neutral-400">Você receberá</span>
                  <span className="text-2xl font-bold text-[#00d749]">
                    {formatCurrency(parseFloat(formData.amount))}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-neutral-200 dark:border-neutral-800">
                  <span className="text-neutral-600 dark:text-neutral-400">Taxa de Serviço ({interestRate}%)</span>
                  <span className="font-bold text-orange-500">
                    +{formatCurrency(parseFloat(formData.amount) * interestRateDecimal)}
                  </span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-neutral-600 dark:text-neutral-400">Valor pendente</span>
                  <span className="text-xl font-bold text-red-600">
                    {formatCurrency(parseFloat(formData.amount) * discountMultiplier)}
                  </span>
                </div>
                <div className="flex items-center justify-center gap-2 mt-3 pt-3 border-t border-neutral-200 dark:border-neutral-800">
                  <Calendar className="w-4 h-4 text-red-500" />
                  <span className="text-sm text-red-500 font-medium">
                    Processamento em: {formatNextMondayDate()}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-800">
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  <strong>Recebimento via:</strong> {
                    formData.payoutMethod === 'mbway' ? (isBR ? 'PIX' : 'MB Way') : 
                    formData.payoutMethod === 'iban' ? (isBR ? 'Conta Bancária' : 'IBAN') : 'Lightning Network (Sats)'
                  }
                </p>
              </div>
            </div>

            <div className="card">
              <label className="flex items-start gap-3">
                <input type="checkbox" className="mt-1" required />
                <span className="text-sm text-neutral-600 dark:text-neutral-400">
                  Confirmo que as informações estão corretas e aceito os{' '}
                  <a href="#" className="text-[#00d749] font-medium">
                    termos e condições
                  </a>
                </span>
              </label>
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={!canProceed()}
          className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {step === 2 ? 'Enviar Solicitação' : 'Continuar'}
        </button>
      </form>
    </div>
  )
}

export default NewRequest
