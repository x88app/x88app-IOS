import { ArrowUpRight, Euro, X, Bell, Moon, Sun, Rss } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { useRequests } from '../../contexts/RequestsContext'
import { RequestProgress } from '../../components/RequestProgress'
import { RequestModal } from '../../components/RequestModal'
import { NewRequestModal } from '../../components/NewRequestModal'
import { ActiveRequestCard } from '../../components/ActiveRequestCard'
import SatoshiModal from '../../components/SatoshiModal'
import { PendingSatoshiCard } from '../../components/PendingSatoshiCard'
import { BenefitsCarousel } from '../../components/BenefitsCarousel'
import { ImageCarousel } from '../../components/ImageCarousel'
import { WeeklySummaryCard } from '../../components/WeeklySummaryCard'
import { AdsPopup } from '../../components/AdsPopup'
import ConfirmCancelModal from '../../components/ConfirmCancelModal'
import { useState, useEffect, useRef } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import { getStatusBadge, getStatusIcon } from '../../utils/helpers'
import { FormattedDate } from '../../components/FormattedDate'
import { useLanguage } from '../../contexts/LanguageContext'
import { formatNextMondayDate } from '../../lib/dateUtils'
import { useNotifications } from '../../contexts/NotificationsContext'
import { NotificationsPanel } from '../../components/NotificationsPanel'
import { FeedPanel } from '../../components/FeedPanel'
import { ChatPopup } from '../../components/ChatPopup'

const Home = () => {
  const navigate = useNavigate()
  const { requests, getPendingRequests, getApprovedRequests, updateRequest } = useRequests()
  const { user } = useAuth()
  const { t, formatCurrency, language } = useLanguage()
  const isBR = language === 'pt-BR'
  const [selectedRequest, setSelectedRequest] = useState<typeof requests[0] | null>(null)
  const [isNewRequestModalOpen, setIsNewRequestModalOpen] = useState(false)
  const [isSatoshiModalOpen, setIsSatoshiModalOpen] = useState(false)
  const [hasBanners, setHasBanners] = useState(() => localStorage.getItem('x88_has_banners') === 'true')
  const [cancelModalOpen, setCancelModalOpen] = useState(false)
  const [requestToCancel, setRequestToCancel] = useState<string | null>(null)
  
  // Header icons state
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('darkMode')
    if (saved !== null) {
      return saved === 'true'
    }
    return document.documentElement.classList.contains('dark')
  })
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [feedOpen, setFeedOpen] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const [bellShake, setBellShake] = useState(false)
  const [bellPosition, setBellPosition] = useState({ x: 0, y: 0 })
  const [feedPosition, setFeedPosition] = useState({ x: 0, y: 0 })
  const bellButtonRef = useRef<HTMLButtonElement>(null)
  const feedButtonRef = useRef<HTMLButtonElement>(null)
  const { unreadCount, markAllAsRead } = useNotifications()
  
  const toggleDarkMode = () => {
    const newDarkMode = !darkMode
    setDarkMode(newDarkMode)
    localStorage.setItem('darkMode', String(newDarkMode))
    if (newDarkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }
  
  // Verificar se deve reabrir o chat ao voltar de outra página
  useEffect(() => {
    const shouldReopen = sessionStorage.getItem('x88_chat_return') === 'true'
    if (shouldReopen) {
      sessionStorage.removeItem('x88_chat_return')
      setChatOpen(true)
    }
  }, [])
  
  useEffect(() => {
    if (bellButtonRef.current) {
      const rect = bellButtonRef.current.getBoundingClientRect()
      setBellPosition({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      })
    }
    if (feedButtonRef.current) {
      const rect = feedButtonRef.current.getBoundingClientRect()
      setFeedPosition({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      })
    }
  }, [])
  
  useEffect(() => {
    setBellShake(true)
    const shakeTimeout = setTimeout(() => setBellShake(false), 500)
    
    let readTimeout: ReturnType<typeof setTimeout>

    if (notificationsOpen) {
      if (bellButtonRef.current) {
        const rect = bellButtonRef.current.getBoundingClientRect()
        setBellPosition({
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2
        })
      }
      if (unreadCount > 0) {
        readTimeout = setTimeout(() => markAllAsRead(), 800)
      }
    }

    return () => {
      clearTimeout(shakeTimeout)
      if (readTimeout) clearTimeout(readTimeout)
    }
  }, [notificationsOpen, unreadCount, markAllAsRead])
  
  // Função para gerenciar a atualização de banners e forçar reload se necessário
  const handleHasBanners = (hasBannersNow: boolean) => {
    setHasBanners(hasBannersNow)
    
    // Verifica o que estava salvo antes
    const storedValue = localStorage.getItem('x88_has_banners') === 'true'
    
    // Se o estado mudou em relação ao que estava salvo (ex: removeu banner),
    // salvamos o novo estado e recarregamos a página para o index.html aplicar a cor certa.
    if (hasBannersNow !== storedValue) {
      localStorage.setItem('x88_has_banners', String(hasBannersNow))
      window.location.reload()
    }
  }
  
  const [, setTick] = useState(0) // Used to force re-render for timers
  
  useEffect(() => {
    const metaThemeColor = document.querySelector('meta[name="theme-color"]')
    const metaAppleStatus = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]')

    if (hasBanners) {
      document.body.classList.remove('header-icons-dark')
      document.body.style.backgroundColor = '#000000'
      if (metaThemeColor) metaThemeColor.setAttribute('content', '#000000')
      // black-translucent permite que o fundo preto (body/banner) apareça atrás da barra
      if (metaAppleStatus) metaAppleStatus.setAttribute('content', 'black-translucent')
    } else {
      document.body.classList.add('header-icons-dark')
      document.body.style.backgroundColor = '#4dff7a'
      if (metaThemeColor) metaThemeColor.setAttribute('content', '#4dff7a')
      if (metaAppleStatus) metaAppleStatus.setAttribute('content', '#4dff7a')
    }
    return () => {
      document.body.classList.remove('header-icons-dark')
      document.body.style.backgroundColor = ''
      if (metaThemeColor) metaThemeColor.setAttribute('content', '#000000')
      if (metaAppleStatus) metaAppleStatus.setAttribute('content', 'black')
    }
  }, [hasBanners])

  useEffect(() => {
    let lastScrollTop = 0
    
    const handleScroll = () => {
      const rootElement = document.getElementById('root')
      const scrollTop = rootElement ? rootElement.scrollTop : window.pageYOffset || document.documentElement.scrollTop
      
      console.log('HOME SCROLL:', scrollTop)
      
      if (scrollTop > 10) {
        document.body.classList.add('hide-header-icons')
      } else {
        document.body.classList.remove('hide-header-icons')
      }
      
      lastScrollTop = scrollTop
    }
    
    const rootElement = document.getElementById('root')
    
    if (rootElement) {
      rootElement.addEventListener('scroll', handleScroll, { passive: true })
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    
    handleScroll()
    
    return () => {
      if (rootElement) {
        rootElement.removeEventListener('scroll', handleScroll)
      }
      window.removeEventListener('scroll', handleScroll)
      document.body.classList.remove('hide-header-icons')
    }
  }, [])

  // Effect to keep updating the UI when there are recently paid requests (to handle the 15s timeout)
  useEffect(() => {
    const hasRecentPaidRequests = requests.some(req => {
      if (req.status !== 'paid' || !req.paymentDate) return false
      const paymentTime = new Date(req.paymentDate).getTime()
      return (Date.now() - paymentTime) < 16000
    })

    if (hasRecentPaidRequests) {
      const interval = setInterval(() => setTick(t => t + 1), 1000)
      return () => clearInterval(interval)
    }
  }, [requests])
  
  const activeRequests = requests.filter(req => {
    // Status is pending, processing
    if (['pending', 'processing'].includes(req.status)) return true
    
    // Status is approved (keep visible until paid)
    if (req.status === 'approved') return true
    
    // Status is paid (keep visible if recent - < 15s)
    if (req.status === 'paid') {
      // Never show confirmed Satoshi payments in active card
      if (req.paymentMethod === 'satoshi') return false
      
      if (!req.paymentDate) return false
      const paymentTime = new Date(req.paymentDate).getTime()
      const now = new Date().getTime()
      return (now - paymentTime) < 15000 
    }
    
    return false
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  const approvedRequests = getApprovedRequests()
  
  const handleCancelRequest = (requestId: string) => {
    setRequestToCancel(requestId)
    setCancelModalOpen(true)
  }
  
  const confirmCancelRequest = async () => {
    if (requestToCancel && user) {
      const requestData = requests.find(r => r.id === requestToCancel)
      await updateRequest(requestToCancel, { status: 'canceled' })
      
      // Notificar o gestor sobre o cancelamento
      try {
        // Buscar dados do colaborador e gestor
        const { data: colaboradorData } = await supabase
          .from('colaboradores')
          .select('id, gestor_id, usuarios!inner(nome)')
          .eq('usuario_id', user.id)
          .single()
        
        if (colaboradorData?.gestor_id) {
          const nomeColaborador = (colaboradorData.usuarios as any)?.nome || 'Colaborador'
          const valorFormatado = requestData ? formatCurrency(requestData.amount) : ''
          
          // Criar notificação para o gestor
          await supabase
            .from('notificacoes')
            .insert({
              usuario_id: colaboradorData.gestor_id,
              titulo: 'Solicitação Cancelada',
              mensagem: `${nomeColaborador} cancelou a solicitação de ${valorFormatado}`,
              tipo: 'warning',
              solicitacao_id: requestToCancel,
              lida: false,
              data_criacao: new Date().toISOString()
            })
        }
      } catch (error) {
        console.error('Erro ao notificar gestor:', error)
      }
      
      setCancelModalOpen(false)
      setRequestToCancel(null)
    }
  }
  
  const stats = {
    pending: activeRequests.length,
    approved: approvedRequests.length,
  }

  const getPendingTotal = () => {
    // Filtra apenas solicitações PAGAS e que ainda NÃO foram descontadas
    const pendingRequests = requests.filter(req => req.status === 'paid' && !req.descontado)
    
    const euroRequests = pendingRequests.filter(req => req.currency === 'EUR')
    const euroTotal = euroRequests.reduce((sum, req) => sum + req.amount, 0)
    const euroNetTotal = euroRequests.reduce((sum, req) => sum + req.netAmount, 0)
    
    const satsRequests = pendingRequests.filter(req => req.currency === 'SATS')
    const satsTotal = satsRequests.reduce((sum, req) => sum + req.amount, 0)
    const satsNetTotal = satsRequests.reduce((sum, req) => sum + req.netAmount, 0)
    
    return { 
      euroTotal, 
      satsTotal, 
      euroNetTotal,
      satsNetTotal,
      euroCount: euroRequests.length,
      satsCount: satsRequests.length,
      euroAllDeducted: false,
      satsAllDeducted: false
    }
  }

  const pendingTotal = getPendingTotal()

  return (
    <div className={`min-h-screen ${hasBanners ? 'bg-[#15ff5d]' : 'bg-[#4dff7a] dark:bg-[#4dff7a]'}`}>
      {/* Área com imagens de fundo - incluindo status bar e header */}
      <div className={`relative overflow-hidden ${hasBanners ? 'h-[65vh] min-h-[400px] max-h-[700px] bg-black' : 'h-[180px]'}`}>
        <ImageCarousel onHasBanners={handleHasBanners} />
        {/* Vinheta superior (sombra) para status bar */}
        {hasBanners && (
          <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-black/100 to-transparent z-10 pointer-events-none" />
        )}
        {!hasBanners && (
             <div className="h-full w-full bg-[#4dff7a] dark:bg-[#4dff7a] flex items-start justify-between px-6 pt-12 lg:hidden rounded-b-[32px] absolute top-0 left-0 z-0">
                <img src="/logos/x88.png" alt="X88" className="h-10 -ml-3 mt-1" />
             </div>
        )}
        {/* Header icons - inline so they scroll with content */}
        <div className={`absolute top-0 right-0 z-20 ${hasBanners ? 'pt-0 pr-4' : 'pt-3 pr-6'}`}>
          <div className="flex items-center gap-2">
            <button
              ref={feedButtonRef}
              onClick={() => setFeedOpen(!feedOpen)}
              className={hasBanners ? 'p-2 rounded-lg hover:bg-white/20 transition-colors' : 'w-9 h-9 rounded-full bg-black/10 dark:bg-black/20 flex items-center justify-center hover:bg-black/20 dark:hover:bg-black/30 transition-colors'}
              aria-label="Feed"
            >
              <Rss className={`w-5 h-5 ${hasBanners ? 'text-white' : 'text-black dark:text-black'}`} />
            </button>
            <button
              onClick={toggleDarkMode}
              className={hasBanners ? 'p-2 rounded-lg hover:bg-white/20 transition-colors' : 'w-9 h-9 rounded-full bg-black/10 dark:bg-black/20 flex items-center justify-center hover:bg-black/20 dark:hover:bg-black/30 transition-colors'}
              aria-label="Toggle dark mode"
            >
              {darkMode ? (
                <Sun className={`w-5 h-5 ${hasBanners ? 'text-white' : 'text-black dark:text-black'}`} />
              ) : (
                <Moon className={`w-5 h-5 ${hasBanners ? 'text-white' : 'text-black dark:text-black'}`} />
              )}
            </button>
            <button
              ref={bellButtonRef}
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className={`${hasBanners ? 'p-2 rounded-lg hover:bg-white/20 transition-colors' : 'w-9 h-9 rounded-full bg-black/10 dark:bg-black/20 flex items-center justify-center hover:bg-black/20 dark:hover:bg-black/30 transition-colors'} relative`}
              aria-label="Notificações"
            >
              <Bell 
                className={`w-5 h-5 transition-all ${hasBanners ? 'text-white' : 'text-black dark:text-black'} ${
                  bellShake ? 'animate-bell-ring' : ''
                } ${unreadCount > 0 && hasBanners ? 'fill-white' : ''} ${unreadCount > 0 && !hasBanners ? 'fill-black dark:fill-black' : ''}`}
              />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[20px] h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center px-1.5 animate-pulse">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className={`px-3 space-y-5 pb-32 min-h-screen relative z-10 bg-white dark:bg-black ${hasBanners ? 'pt-6 rounded-t-3xl' : '-mt-16 rounded-t-3xl pt-6'}`} style={hasBanners ? { marginTop: 'max(-35vh, -320px)' } : undefined}>
      
      {/* Chat com IA */}
      <button 
        onClick={() => setChatOpen(true)}
        className="w-full bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-3 flex items-center gap-3 hover:shadow-lg transition-all"
      >
        <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0">
          <img src="/logos/logoAi.png" alt="IA" className="w-full h-full object-cover" />
        </div>
        <span className="text-neutral-400 dark:text-neutral-500 text-left flex-1 text-sm">Pergunte algo à IA...</span>
      </button>

      {/* Ações rápidas */}
      <div className="space-y-4">
        <WeeklySummaryCard
          euroTotal={pendingTotal.euroTotal}
          satsTotal={pendingTotal.satsTotal}
          euroNetTotal={pendingTotal.euroNetTotal}
          satsNetTotal={pendingTotal.satsNetTotal}
          euroCount={pendingTotal.euroCount}
          satsCount={pendingTotal.satsCount}
        />
        
        {/* Solicitações em Andamento */}
        {activeRequests.length > 0 && (
          <div className="space-y-4">
            {activeRequests.filter(req => req.status !== 'rejected').map((request) => (
              <ActiveRequestCard 
                key={request.id} 
                request={request} 
                onCancel={handleCancelRequest}
              />
            ))}
          </div>
        )}
        
        {/* Nova Solicitação */}
        <button onClick={() => setIsNewRequestModalOpen(true)} className="block w-full">
          <div className="card bg-[#00d749] dark:bg-[#00b83d] p-6 hover:shadow-xl transition-shadow cursor-pointer">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-white">{t('home.novo_adiantamento')}</h3>
                <p className="text-white/80 text-sm mt-1 -ml-3">{t('home.solicite_rapido')}</p>
              </div>
              {isBR ? (
                <span className="text-2xl font-bold text-white mr-2">R$</span>
              ) : (
                <Euro className="w-8 h-8 text-white mr-2" />
              )}
            </div>
          </div>
        </button>

        {/* Receber Satoshi */}
        <button onClick={() => setIsSatoshiModalOpen(true)} className="block w-full">
          <div className="card bg-[#E69F39] dark:bg-[#cc8a2e] p-6 hover:shadow-xl transition-shadow cursor-pointer">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-white">{t('home.receber_satoshi')}</h3>
                <p className="text-white/80 text-sm mt-1">{t('home.qr_code')}</p>
              </div>
              <img 
                src="/logos/BITCOIN.png" 
                alt="Bitcoin"
                className="w-12 h-12"
              />
            </div>
          </div>
        </button>

        {/* Carrossel de Benefícios */}
        <BenefitsCarousel />
      </div>

      {/* Card de Confirmação de Satoshi Pendente */}
      <PendingSatoshiCard />



      {/* Solicitações recentes */}
      {requests.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-black dark:text-white">{t('home.ultimas_solicitacoes')}</h3>
            <Link to="/requests" className="text-[#00d749] text-sm font-medium">
              {t('home.ver_todas')}
            </Link>
          </div>

          <div className="space-y-5">
            {requests.slice(0, 5).map((request) => (
              <div 
                key={request.id} 
                onClick={() => setSelectedRequest(request)}
                className="cursor-pointer"
              >
                <div className="card p-4 hover:shadow-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(request.status.toUpperCase())}
                      <span className="font-semibold text-black dark:text-white">
                        {(() => {
                          const method = request.paymentMethod.toUpperCase();
                          if (method === 'MBWAY') return isBR ? 'PIX' : 'MB Way';
                          if (method === 'IBAN') return isBR ? 'Conta Bancária' : 'IBAN';
                          return method;
                        })()}
                      </span>
                    </div>
                    {getStatusBadge(request.status.toUpperCase())}
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      {request.status.toUpperCase() === 'PAID' ? (
                        <>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">Valor Recebido</p>
                          <p className={`text-2xl font-bold ${request.currency === 'SATS' ? 'text-[#E69F39]' : 'text-[#00d749]'}`}>
                            {request.currency === 'SATS' ? `${Math.round(request.amount)} sats` : formatCurrency(request.amount)}
                          </p>
                          {request.descontado ? (
                            <p className="text-[10px] text-green-600 dark:text-green-400 mt-1 font-medium">
                              ✓ Valor {request.currency === 'SATS' ? `${Math.round(request.netAmount)} sats` : formatCurrency(request.netAmount)} descontado do salário
                            </p>
                          ) : (
                            <>
                              <p className="text-[10px] text-red-500 dark:text-red-400 mt-1">
                                A descontar do salário: {request.currency === 'SATS' ? `${Math.round(request.netAmount)} sats` : formatCurrency(request.netAmount)}
                              </p>
                              <p className="text-[10px] text-red-500 dark:text-red-400">
                                em {formatNextMondayDate(request.paymentDate ? new Date(request.paymentDate) : new Date())}
                              </p>
                            </>
                          )}
                        </>
                      ) : (
                        <>
                          <p className="text-xs text-neutral-500 dark:text-neutral-400">Valor Solicitado</p>
                          <p className={`text-2xl font-bold ${request.currency === 'SATS' ? 'text-[#E69F39]' : 'text-[#00d749]'}`}>
                            {request.currency === 'SATS' ? `${Math.round(request.amount)} sats` : formatCurrency(request.amount)}
                          </p>
                        </>
                      )}
                    </div>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">
                      <FormattedDate date={request.date} />
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Mensagem quando não há solicitações */}
      {requests.length === 0 && (
        <div className="card text-center py-12">
          {isBR ? (
            <span className="text-6xl font-bold text-neutral-300 dark:text-neutral-700 mx-auto mb-4 block">R$</span>
          ) : (
            <Euro className="w-16 h-16 text-neutral-300 dark:text-neutral-700 mx-auto mb-4" />
          )}
          <h3 className="text-lg font-bold text-black dark:text-white mb-2">
            Nenhuma solicitação ainda
          </h3>
          <p className="text-neutral-600 dark:text-neutral-400 mb-6">
            Faça sua primeira solicitação de adiantamento
          </p>
          <button onClick={() => setIsNewRequestModalOpen(true)} className="btn-primary">
            Solicitar Adiantamento
          </button>
        </div>
      )}

      </div>

      {selectedRequest && (
        <RequestModal 
          request={selectedRequest} 
          onClose={() => setSelectedRequest(null)} 
        />
      )}

      <NewRequestModal 
        isOpen={isNewRequestModalOpen} 
        onClose={() => setIsNewRequestModalOpen(false)} 
      />

      <SatoshiModal 
        isOpen={isSatoshiModalOpen} 
        onClose={() => setIsSatoshiModalOpen(false)} 
      />

      <AdsPopup />

      <ConfirmCancelModal
        isOpen={cancelModalOpen}
        onClose={() => {
          setCancelModalOpen(false)
          setRequestToCancel(null)
        }}
        onConfirm={confirmCancelRequest}
      />

      <NotificationsPanel 
        isOpen={notificationsOpen} 
        onClose={() => setNotificationsOpen(false)}
        bellPosition={bellPosition}
      />

      <FeedPanel
        isOpen={feedOpen}
        onClose={() => setFeedOpen(false)}
        buttonPosition={feedPosition}
      />

      <ChatPopup
        isOpen={chatOpen}
        onClose={() => setChatOpen(false)}
      />

      </div>
  )
}

export default Home
