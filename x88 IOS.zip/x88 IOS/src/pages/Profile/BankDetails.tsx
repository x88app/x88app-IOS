import { useState, useEffect } from 'react'
import { ArrowLeft, CreditCard, Smartphone, CheckCircle, AlertCircle, Zap } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import { useNotifications } from '../../contexts/NotificationsContext'
import { useLanguage } from '../../contexts/LanguageContext'
import { useBackNavigation } from '../../hooks/useBackNavigation'

const BankDetails = () => {
  const { goBack } = useBackNavigation('/profile')
  const { user, updateBankDetails } = useAuth()
  const { addNotification } = useNotifications()
  const { language } = useLanguage()
  const isBR = language === 'pt-BR'
  
  const [activeTab, setActiveTab] = useState<'iban' | 'mbway' | 'satoshi'>('mbway')
  const [formData, setFormData] = useState({
    iban: '',
    bankHolderName: '',
    swiftBic: '',
    mbwayPhone: '',
    preferredMethod: 'mbway',
    wallet: ''
  })

  const [isEditing, setIsEditing] = useState(false)
  const [agencia, setAgencia] = useState('')
  const [conta, setConta] = useState('')

  useEffect(() => {
    if (!isEditing && isBR) {
      const current = formData.iban || ''
      const parts = current.match(/Agência: (.*) Conta: (.*)/)
      if (parts) {
        setAgencia(parts[1])
        setConta(parts[2])
      } else if (!current.includes('Agência:')) {
        setConta(current)
        setAgencia('')
      }
    }
  }, [formData.iban, isEditing, isBR])

  useEffect(() => {
    if (user?.bankDetails) {
      setFormData({
        iban: user.bankDetails.iban,
        bankHolderName: user.bankDetails.bankHolderName,
        swiftBic: user.bankDetails.swiftBic,
        mbwayPhone: user.bankDetails.mbwayPhone,
        preferredMethod: user.bankDetails.preferredMethod,
        wallet: user.bankDetails.wallet
      })
    }
  }, [user])

  const handleSave = async () => {
    const { success, error } = await updateBankDetails({
      iban: formData.iban,
      bankHolderName: formData.bankHolderName,
      swiftBic: formData.swiftBic,
      mbwayPhone: formData.mbwayPhone,
      preferredMethod: formData.preferredMethod,
      wallet: formData.wallet
    })

    if (success) {
      addNotification({
        title: 'Sucesso',
        message: 'Dados bancários atualizados com sucesso!',
        type: 'success'
      })
      setIsEditing(false)
    } else {
      addNotification({
        title: 'Erro',
        message: 'Erro ao atualizar dados bancários: ' + error,
        type: 'error'
      })
    }
  }

  const formatIBAN = (value: string) => {
    const cleaned = value.replace(/\s/g, '')
    const matches = cleaned.match(/.{1,4}/g)
    return matches ? matches.join(' ') : cleaned
  }



  return (
    <div className="p-4 pt-4 space-y-6 pb-40">
      <div className="flex items-center gap-3 mb-2">
        <button
          type="button"
          onClick={goBack}
          className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-black dark:text-white" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-black dark:text-white">Dados Bancários</h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            Gerencie suas formas de recebimento
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-neutral-100 dark:bg-neutral-900 rounded-xl">
        <button
          onClick={() => setActiveTab('mbway')}
          className={`flex-1 py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
            activeTab === 'mbway'
              ? 'bg-white dark:bg-black shadow-md text-[#00d749]'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          <Smartphone className="w-5 h-5" />
          {isBR ? 'PIX' : 'MB Way'}
        </button>
        <button
          onClick={() => setActiveTab('iban')}
          className={`flex-1 py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
            activeTab === 'iban'
              ? 'bg-white dark:bg-black shadow-md text-[#00d749]'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          <CreditCard className="w-5 h-5" />
          {isBR ? 'Conta Bancária' : 'IBAN'}
        </button>
        <button
          onClick={() => setActiveTab('satoshi')}
          className={`flex-1 py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
            activeTab === 'satoshi'
              ? 'bg-white dark:bg-black shadow-md text-[#f7931a]'
              : 'text-neutral-600 dark:text-neutral-400'
          }`}
        >
          <Zap className="w-5 h-5" />
          Sats
        </button>
      </div>

      {/* Status de verificação */}
      <div className="card bg-[#00d749]/10 border-[#00d749]">
        <div className="flex items-start gap-3">
          <CheckCircle className="w-6 h-6 text-[#00d749] flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-bold text-black dark:text-white mb-1">
              Dados Verificados
            </h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Seus dados bancários foram verificados pelo gestor em 15/10/2025
            </p>
          </div>
        </div>
      </div>

      {/* Botão Editar */}
      {!isEditing && (
        <button onClick={() => setIsEditing(true)} className="btn-primary w-full">
          Editar Dados
        </button>
      )}

      {/* MB Way / PIX Form */}
      {activeTab === 'mbway' && (
        <div className="space-y-4">
          <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
            <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              {isBR ? 'Chave PIX (Telefone/CPF/Email)' : 'Número de Telefone MB Way'}
            </label>
            <div className="relative">
              <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input
                type="text"
                value={formData.mbwayPhone}
                onChange={(e) =>
                  setFormData({ ...formData, mbwayPhone: e.target.value }) // Removing formatPhone for generic input flexibility or specifically formatting based on region if needed
                }
                disabled={!isEditing}
                className="input w-full pl-11"
                placeholder={isBR ? "Chave PIX" : "+351 999 888 777"}
              />
            </div>
            <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
              {isBR ? 'Certifique-se de que esta chave PIX está correta' : 'Certifique-se de que este número está registrado no MB Way'}
            </p>
          </div>

          <div className="card bg-blue-50 dark:bg-blue-950/30">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-black dark:text-white mb-1">
                  {isBR ? 'Sobre o PIX' : 'Sobre o MB Way'}
                </h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  {isBR 
                    ? 'Os pagamentos via PIX são processados instantaneamente, 24/7.' 
                    : 'Os pagamentos via MB Way são processados instantaneamente. Certifique-se de que o número está ativo e tem limite disponível.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* IBAN / Conta Bancária Form */}
      {activeTab === 'iban' && (
        <div className="space-y-4">
          <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
            <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              {isBR ? 'Conta Bancária (Agência/Conta)' : 'IBAN'}
            </label>
            
            {isBR ? (
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <input
                    type="text"
                    value={agencia}
                    onChange={(e) => {
                      const newAgencia = e.target.value
                      setAgencia(newAgencia)
                      setFormData(prev => ({
                        ...prev,
                        iban: `Agência: ${newAgencia} Conta: ${conta}`
                      }))
                    }}
                    disabled={!isEditing}
                    className="input w-full"
                    placeholder="Agência"
                  />
                  <span className="text-xs text-neutral-500 mt-1 ml-1">Agência</span>
                </div>
                <div className="col-span-2">
                  <input
                    type="text"
                    value={conta}
                    onChange={(e) => {
                      const newConta = e.target.value
                      setConta(newConta)
                      setFormData(prev => ({
                        ...prev,
                        iban: `Agência: ${agencia} Conta: ${newConta}`
                      }))
                    }}
                    disabled={!isEditing}
                    className="input w-full"
                    placeholder="Conta com dígito"
                  />
                  <span className="text-xs text-neutral-500 mt-1 ml-1">Conta</span>
                </div>
              </div>
            ) : (
              <input
                type="text"
                value={formData.iban}
                onChange={(e) =>
                  setFormData({ ...formData, iban: isBR ? e.target.value : formatIBAN(e.target.value.toUpperCase()) })
                }
                disabled={!isEditing}
                className="input w-full font-mono"
                placeholder={isBR ? "Agência e Conta" : "PT50 0000 0000 0000 0000 0000 0"}
                maxLength={isBR ? 50 : 29}
              />
            )}
          </div>

          <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
            <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              Nome do Titular
            </label>
            <input
              type="text"
              value={formData.bankHolderName}
              onChange={(e) => setFormData({ ...formData, bankHolderName: e.target.value })}
              disabled={!isEditing}
              className="input w-full"
              placeholder="João Silva"
            />
          </div>

          <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
            <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              SWIFT/BIC (Opcional)
            </label>
            <input
              type="text"
              value={formData.swiftBic}
              onChange={(e) =>
                setFormData({ ...formData, swiftBic: e.target.value.toUpperCase() })
              }
              disabled={!isEditing}
              className="input w-full"
              placeholder="CGDIPTPL"
              maxLength={11}
            />
          </div>

          <div className="card bg-blue-50 dark:bg-blue-950/30">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-black dark:text-white mb-1">{isBR ? 'Sobre Conta Bancária' : 'Sobre o IBAN'}</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  {isBR 
                    ? 'Transferências bancárias (TED/DOC) podem levar até 1 dia útil.' 
                    : 'Transferências via IBAN podem levar até 1 dia útil para serem processadas. Certifique-se de que os dados estão corretos.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

        {/* Lightning Wallet Form */}
      {activeTab === 'satoshi' && (
        <div className="space-y-4">
          <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
            <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              Endereço Lightning / LNURL
            </label>
            <input
              type="text"
              value={formData.wallet}
              onChange={(e) => setFormData({ ...formData, wallet: e.target.value })}
              disabled={!isEditing}
              className="input w-full font-mono text-sm"
              placeholder="nome@carteira.com ou lnurl..."
            />
             <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
              Endereço Lightning para recebimento instantâneo de Satoshis
            </p>
          </div>

           <div className="card bg-orange-50 dark:bg-orange-950/30 border-orange-200 dark:border-orange-800">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-black dark:text-white mb-1">Sobre Lightning Network</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  Pagamentos via Lightning são processados em segundos com taxas mínimas.
                  Certifique-se de que sua carteira suporta o recebimento.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Método preferido */}
      <div className="card">
        <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-3">
          Método Preferido de Recebimento
        </label>
        <div className="space-y-2">
          <label className="flex items-center gap-3 p-3 rounded-lg border-2 border-neutral-200 dark:border-neutral-800 cursor-pointer hover:border-[#00d749] transition-colors">
            <input
              type="radio"
              name="preferredMethod"
              value="mbway"
              checked={formData.preferredMethod === 'mbway'}
              onChange={(e) => setFormData({ ...formData, preferredMethod: e.target.value })}
              disabled={!isEditing}
              className="w-4 h-4 text-[#00d749]"
            />
            <Smartphone className="w-5 h-5 text-[#00d749]" />
            <span className="font-medium text-black dark:text-white">{isBR ? 'PIX' : 'MB Way'}</span>
          </label>
          <label className="flex items-center gap-3 p-3 rounded-lg border-2 border-neutral-200 dark:border-neutral-800 cursor-pointer hover:border-[#00d749] transition-colors">
            <input
              type="radio"
              name="preferredMethod"
              value="iban"
              checked={formData.preferredMethod === 'iban'}
              onChange={(e) => setFormData({ ...formData, preferredMethod: e.target.value })}
              disabled={!isEditing}
              className="w-4 h-4 text-[#00d749]"
            />
            <CreditCard className="w-5 h-5 text-[#00d749]" />
            <span className="font-medium text-black dark:text-white">{isBR ? 'Conta Bancária' : 'IBAN'}</span>
          </label>
          <label className="flex items-center gap-3 p-3 rounded-lg border-2 border-neutral-200 dark:border-neutral-800 cursor-pointer hover:border-[#f7931a] transition-colors">
            <input
              type="radio"
              name="preferredMethod"
              value="satoshi"
              checked={formData.preferredMethod === 'satoshi'}
              onChange={(e) => setFormData({ ...formData, preferredMethod: e.target.value })}
              disabled={!isEditing}
              className="w-4 h-4 text-[#f7931a]"
            />
            <Zap className="w-5 h-5 text-[#f7931a]" />
            <span className="font-medium text-black dark:text-white">Lightning (Sats)</span>
          </label>
        </div>
      </div>

      {/* Botões de Cancelar/Salvar */}
      {isEditing && (
        <div className="flex gap-3">
          <button
            onClick={() => setIsEditing(false)}
            className="btn-secondary flex-1"
          >
            Cancelar
          </button>
          <button onClick={handleSave} className="btn-primary flex-1">
            Salvar Alterações
          </button>
        </div>
      )}
    </div>
  )
}

export default BankDetails
