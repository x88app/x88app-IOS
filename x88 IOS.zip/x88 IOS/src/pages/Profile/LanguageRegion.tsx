import { ArrowLeft, Globe, Clock } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useBackNavigation } from '../../hooks/useBackNavigation';

const LanguageRegion = () => {
  const { goBack } = useBackNavigation('/profile');
  const { language, setLanguage, timezone } = useLanguage();

  return (
    <div className="p-4 pt-4 space-y-6 pb-40">
      <div className="flex items-center gap-3 mb-2">
        <button
          type="button"
          onClick={goBack}
          className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-black dark:text-white" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-black dark:text-white">Idioma e Região</h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            Configure suas preferências regionais
          </p>
        </div>
      </div>

      <div className="card">
        <div className="space-y-6">
          {/* Idioma */}
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <Globe className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-black dark:text-white">Idioma</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  Selecione o idioma do aplicativo
                </p>
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="flex items-center justify-between p-3 rounded-lg border border-neutral-200 dark:border-neutral-700 cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🇧🇷</span>
                  <span className="font-medium text-black dark:text-white">Português (Brasil)</span>
                </div>
                <input
                  type="radio"
                  name="language"
                  checked={language === 'pt-BR'}
                  onChange={() => setLanguage('pt-BR')}
                  className="w-5 h-5 text-blue-600 accent-[#00d749]"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-lg border border-neutral-200 dark:border-neutral-700 cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">🇵🇹</span>
                  <span className="font-medium text-black dark:text-white">Português (Portugal)</span>
                </div>
                <input
                  type="radio"
                  name="language"
                  checked={language === 'pt-PT'}
                  onChange={() => setLanguage('pt-PT')}
                  className="w-5 h-5 text-blue-600 accent-[#00d749]"
                />
              </label>
            </div>
          </div>

          <div className="h-px bg-neutral-200 dark:bg-neutral-700" />

          {/* Fuso Horário */}
          <div>
            <div className="flex items-center gap-3 mb-3">
               <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
                <Clock className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-black dark:text-white">Fuso Horário</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  Definido automaticamente pelo idioma
                </p>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-neutral-50 dark:bg-neutral-800 text-center border border-neutral-200 dark:border-neutral-700">
              <p className="text-lg font-medium text-black dark:text-white">
                {timezone === 'America/Sao_Paulo' ? 'São Paulo (UTC-3)' : 'Lisboa (UTC+0 / UTC+1)'}
              </p>
              <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1">
                {timezone}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LanguageRegion;
