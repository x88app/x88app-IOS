import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react'
import X88Logo from '../../components/ui/X88Logo'
import { supabase } from '../../lib/supabase'

const ForgotPassword = () => {
  const [email, setEmail] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [errorMessage, setErrorMessage] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setErrorMessage('')
    
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + '/auth/update-password',
      })

      if (error) throw error

      setIsSuccess(true)
    } catch (error: any) {
      console.error('Erro ao enviar email de recuperação:', error)
      setErrorMessage(error.message || 'Ocorreu um erro ao enviar o email. Tente novamente.')
    } finally {
      setIsLoading(false)
    }
  }

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#00d749] to-[#00dc43] dark:from-black dark:to-neutral-900 flex flex-col">
        <div className="pt-12 pb-8 px-6 flex justify-center">
          <X88Logo width={120} height={120} variant="auto" />
        </div>

        <div className="flex-1 bg-white dark:bg-neutral-950 rounded-t-3xl p-6 shadow-2xl">
          <div className="max-w-md mx-auto text-center py-12">
            <div className="w-20 h-20 bg-[#00d749]/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-[#00d749]" />
            </div>
            
            <h1 className="text-3xl font-bold text-black dark:text-white mb-3">
              E-mail enviado!
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400 mb-8 px-4">
              Enviamos um link de recuperação para <span className="font-semibold text-black dark:text-white">{email}</span>. 
              Verifique sua caixa de entrada e spam.
            </p>

            <Link
              to="/auth/login"
              className="inline-flex items-center gap-2 text-[#00d749] font-semibold hover:text-[#00dc43] transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              Voltar para o login
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00d749] to-[#00dc43] dark:from-black dark:to-neutral-900 flex flex-col">
      {/* Header com Logo */}
      <div className="pt-12 pb-8 px-6 flex justify-center">
        <X88Logo width={120} height={120} variant="auto" />
      </div>

      {/* Card de Recuperação */}
      <div className="flex-1 bg-white dark:bg-neutral-950 rounded-t-3xl p-6 shadow-2xl">
        <div className="max-w-md mx-auto">
          {/* Link Voltar */}
          <Link
            to="/auth/login"
            className="p-4 -m-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 active:bg-neutral-200 dark:active:bg-neutral-700 inline-flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-black dark:hover:text-white transition-colors mb-8"
          >
            <ArrowLeft className="w-5 h-5" />
            Voltar
          </Link>

          <h1 className="text-3xl font-bold text-black dark:text-white mb-2">
            Recuperar senha
          </h1>
          <p className="text-neutral-600 dark:text-neutral-400 mb-8">
            Digite seu e-mail e enviaremos um link para redefinir sua senha
          </p>

          {errorMessage && (
            <div className="p-4 mb-6 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm">
              {errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                E-mail
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
              </div>
            </div>

            {/* Botão de Enviar */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#00d749] to-[#00dc43] text-white py-4 rounded-2xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                'Enviar link de recuperação'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default ForgotPassword
