import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Lock, Eye, EyeOff, CheckCircle } from 'lucide-react'
import { supabase } from '../../lib/supabase'
import X88Logo from '../../components/ui/X88Logo'
import { useToast } from '../../contexts/ToastContext'

const UpdatePassword = () => {
  const navigate = useNavigate()
  const { showToast } = useToast()
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  useEffect(() => {
    let timeout: NodeJS.Timeout
    let subscription: { unsubscribe: () => void } | null = null

    const checkSession = async () => {
      // Verifica sessão inicial
      const { data: { session } } = await supabase.auth.getSession()
      
      if (session) {
        return // Tem sessão, tudo ok
      }

      // Se não tem sessão, aguarda evento de mudança de estado (recuperação de senha)
      const { data } = supabase.auth.onAuthStateChange((event, session) => {
        if (event === 'PASSWORD_RECOVERY' || session) {
          if (timeout) clearTimeout(timeout)
        }
      })
      subscription = data.subscription

      // Timeout de segurança para redirecionar se não houver sessão
      timeout = setTimeout(async () => {
        const { data: { session } } = await supabase.auth.getSession()
        if (!session) {
           navigate('/auth/login')
           showToast('Sessão inválida ou expirada. Por favor, solicite uma nova recuperação de senha.', 'error')
        }
      }, 2000)
    }

    checkSession()

    return () => {
      if (subscription) subscription.unsubscribe()
      if (timeout) clearTimeout(timeout)
    }
  }, [navigate, showToast])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (password !== confirmPassword) {
      showToast('As senhas não coincidem', 'error')
      return
    }

    if (password.length < 6) {
      showToast('A senha deve ter pelo menos 6 caracteres', 'error')
      return
    }

    setIsLoading(true)

    try {
      const { error } = await supabase.auth.updateUser({
        password: password
      })

      if (error) throw error

      setIsSuccess(true)
      showToast('Senha atualizada com sucesso!', 'success')
      
      setTimeout(() => {
        navigate('/auth/login')
      }, 2000)

    } catch (error: any) {
      console.error('Erro ao atualizar senha:', error)
      showToast(error.message || 'Erro ao atualizar senha', 'error')
    } finally {
      setIsLoading(false)
    }
  }

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#00d749] to-[#00dc43] dark:from-black dark:to-neutral-900 flex flex-col">
        <div className="pt-12 pb-8 px-6 flex justify-center">
          <X88Logo width={120} height={120} variant="auto" />
        </div>

        <div className="flex-1 bg-white dark:bg-neutral-950 rounded-t-3xl p-6 shadow-2xl">
          <div className="max-w-md mx-auto text-center py-12">
            <div className="w-20 h-20 bg-[#00d749]/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-[#00d749]" />
            </div>
            
            <h1 className="text-3xl font-bold text-black dark:text-white mb-3">
              Senha Atualizada!
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400 mb-8 px-4">
              Sua senha foi redefinida com sucesso. Você será redirecionado para o login.
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00d749] to-[#00dc43] dark:from-black dark:to-neutral-900 flex flex-col">
      <div className="pt-12 pb-8 px-6 flex justify-center">
        <X88Logo width={120} height={120} variant="auto" />
      </div>

      <div className="flex-1 bg-white dark:bg-neutral-950 rounded-t-3xl p-6 shadow-2xl">
        <div className="max-w-md mx-auto">
          <h1 className="text-3xl font-bold text-black dark:text-white mb-2">
            Nova Senha
          </h1>
          <p className="text-neutral-600 dark:text-neutral-400 mb-8">
            Digite sua nova senha abaixo
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Nova Senha
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  required
                  className="w-full pl-12 pr-12 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Confirmar Senha
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repita a nova senha"
                  required
                  className="w-full pl-12 pr-12 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                >
                  {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#00d749] to-[#00dc43] text-white py-4 rounded-2xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                'Redefinir Senha'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default UpdatePassword
