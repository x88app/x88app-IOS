import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff, User, Phone, ArrowRight, ArrowLeft, X } from 'lucide-react'
import { createPortal } from 'react-dom'
import X88Logo from '../../components/ui/X88Logo'
import { useAuth } from '../../contexts/AuthContext'

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [acceptTerms, setAcceptTerms] = useState(false)
  const [error, setError] = useState('')
  const [countryCode, setCountryCode] = useState('+351')
  const [showTermsModal, setShowTermsModal] = useState(false)
  const [showPrivacyModal, setShowPrivacyModal] = useState(false)
  const navigate = useNavigate()
  const { register } = useAuth()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
    setError('')
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '')
    setFormData({ ...formData, phone: value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (formData.password !== formData.confirmPassword) {
      setError('As senhas não coincidem')
      return
    }

    if (!acceptTerms) {
      setError('Você precisa aceitar os termos de uso')
      return
    }

    if (countryCode === '+351' && formData.phone.length !== 9) {
      setError('Para Portugal, o telefone deve ter 9 dígitos')
      return
    }
    if (countryCode === '+55' && formData.phone.length !== 11) {
      setError('Para o Brasil, o telefone deve ter 11 dígitos (DDD + Número)')
      return
    }

    const fullPhone = `${countryCode}${formData.phone}`

    setIsLoading(true)
    
    const result = await register(formData.name, formData.email, fullPhone, '000000000', formData.password)
    
    setIsLoading(false)
    
    if (result.success) {
      navigate('/')
    } else {
      setError(result.error || 'Erro ao criar conta. Tente novamente.')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00d749] to-[#00dc43] dark:from-black dark:to-neutral-900 flex flex-col">
      {/* Header com Logo */}
      <div className="pt-12 pb-8 px-6 flex justify-center">
        <X88Logo width={120} height={120} variant="auto" />
      </div>

      {/* Card de Cadastro */}
      <div className="flex-1 bg-white dark:bg-neutral-950 rounded-t-3xl p-6 shadow-2xl overflow-y-auto">
        <div className="max-w-md mx-auto pb-8">
          {/* Link Voltar */}
          <Link
            to="/auth/login"
            className="p-4 -m-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 active:bg-neutral-200 dark:active:bg-neutral-700 inline-flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-black dark:hover:text-white transition-colors mb-6"
          >
            <ArrowLeft className="w-5 h-5" />
            Voltar
          </Link>

          <h1 className="text-3xl font-bold text-black dark:text-white mb-2">
            Criar conta
          </h1>
          <p className="text-neutral-600 dark:text-neutral-400 mb-8">
            Preencha seus dados para começar
          </p>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 px-4 py-3 rounded-xl mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Nome Completo */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Nome completo
              </label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Seu nome completo"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                E-mail
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="seu@email.com"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
              </div>
            </div>

            {/* Telefone */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Telefone
              </label>
              <div className="flex gap-2">
                <div className="relative w-24">
                   <select
                    value={countryCode}
                    onChange={(e) => setCountryCode(e.target.value)}
                    className="w-full pl-2 pr-1 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white appearance-none text-center font-medium"
                   >
                     <option value="+351">🇵🇹 +351</option>
                     <option value="+55">🇧🇷 +55</option>
                   </select>
                </div>
                <div className="relative flex-1">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handlePhoneChange}
                    placeholder={countryCode === '+351' ? "9xx xxx xxx" : "(DD) 9xxxx-xxxx"}
                    required
                    className="w-full pl-12 pr-4 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Senha */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Senha
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                  minLength={8}
                  className="w-full pl-12 pr-12 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <p className="text-xs text-neutral-500 mt-1 ml-1">Mínimo 8 caracteres</p>
            </div>

            {/* Confirmar Senha */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Confirmar senha
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="••••••••"
                  required
                  minLength={8}
                  className="w-full pl-12 pr-12 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors"
                >
                  {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Termos de Uso */}
            <div className="flex items-start gap-3 pt-2">
              <input
                type="checkbox"
                id="terms"
                checked={acceptTerms}
                onChange={(e) => setAcceptTerms(e.target.checked)}
                className="mt-1 w-5 h-5 text-[#00d749] border-neutral-300 rounded focus:ring-[#00d749] focus:ring-2"
              />
              <label htmlFor="terms" className="text-sm text-neutral-600 dark:text-neutral-400">
                Li e aceito os{' '}
                <button
                  type="button"
                  onClick={() => setShowTermsModal(true)}
                  className="text-[#00d749] hover:text-[#00dc43] font-medium hover:underline"
                >
                  termos de uso
                </button>
                {' '}e a{' '}
                <button
                  type="button"
                  onClick={() => setShowPrivacyModal(true)}
                  className="text-[#00d749] hover:text-[#00dc43] font-medium hover:underline"
                >
                  política de privacidade
                </button>
              </label>
            </div>

            {/* Botão de Cadastro */}
            <button
              type="submit"
              disabled={isLoading || !acceptTerms}
              className="w-full bg-gradient-to-r from-[#00d749] to-[#00dc43] text-white py-4 rounded-2xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
                  Criando...
                </>
              ) : (
                <>
                  Criar conta
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          {/* Link para Login */}
          <div className="text-center mt-6">
            <p className="text-neutral-600 dark:text-neutral-400">
              Já tem uma conta?{' '}
              <Link
                to="/auth/login"
                className="font-semibold text-[#00d749] hover:text-[#00dc43] transition-colors"
              >
                Fazer login
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* Modal Termos de Uso */}
      {showTermsModal && createPortal(
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[9999]"
          onClick={() => setShowTermsModal(false)}
        >
          <div 
            className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-lg max-h-[85vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
              <h3 className="text-xl font-bold text-black dark:text-white">Termos de Uso</h3>
              <button
                type="button"
                onClick={() => setShowTermsModal(false)}
                className="w-8 h-8 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700"
              >
                <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm text-neutral-700 dark:text-neutral-300">
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">1. Aceitação dos Termos</h4>
                <p>Ao aceder ou utilizar a aplicação X88 Colaborador, você concorda em ficar vinculado a estes Termos de Uso. Se não concordar com qualquer parte destes Termos, não deve utilizar a Aplicação.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">2. Descrição do Serviço</h4>
                <p>A Aplicação X88 Colaborador permite aos colaboradores registados solicitar adiantamentos salariais, acompanhar o estado das solicitações e receber pagamentos através de MB Way, PIX, IBAN ou Lightning Network.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">3. Taxa de Serviço</h4>
                <p>Uma taxa de serviço será aplicada sobre cada adiantamento solicitado. Esta taxa será claramente apresentada antes da confirmação e será acrescida ao valor a ser descontado do seu salário. Você receberá o valor integral solicitado.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">4. Dados Bancários</h4>
                <p>O colaborador é responsável por fornecer dados bancários corretos e atualizados. A X88 não se responsabiliza por pagamentos realizados para dados incorretos.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">5. Elegibilidade</h4>
                <p>Para utilizar a Aplicação, você deve ter pelo menos 18 anos e ser colaborador ativo da empresa X88 ou parceiro autorizado.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">6. Propriedade Intelectual</h4>
                <p>Todos os direitos de propriedade intelectual relativos à Aplicação são propriedade exclusiva da X88.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">7. Limitação de Responsabilidade</h4>
                <p>A X88 não será responsável por danos indiretos, incidentais ou consequenciais, perda de dados ou lucros, ou interrupções temporárias do serviço.</p>
              </section>

              <section className="border-t border-neutral-200 dark:border-neutral-800 pt-4">
                <p className="text-xs text-neutral-500">
                  Para a versão completa dos Termos de Uso, acesse a secção "Termos de Uso" na aplicação após o registo.
                </p>
              </section>
            </div>
            
            <div className="p-4 border-t border-neutral-200 dark:border-neutral-800">
              <button
                type="button"
                onClick={() => setShowTermsModal(false)}
                className="w-full bg-gradient-to-r from-[#00d749] to-[#00dc43] text-white py-3 rounded-xl font-semibold"
              >
                Entendi
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Modal Política de Privacidade */}
      {showPrivacyModal && createPortal(
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[9999]"
          onClick={() => setShowPrivacyModal(false)}
        >
          <div 
            className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-lg max-h-[85vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
              <h3 className="text-xl font-bold text-black dark:text-white">Política de Privacidade</h3>
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="w-8 h-8 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700"
              >
                <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm text-neutral-700 dark:text-neutral-300">
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">1. Informações que Recolhemos</h4>
                <p>Recolhemos dados de identificação (nome, email, telefone), dados de autenticação, dados bancários (IBAN, MB Way/PIX, endereço Lightning) e dados de utilização.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">2. Como Utilizamos</h4>
                <p>Utilizamos as informações para processar solicitações, efetuar pagamentos, comunicar sobre o estado das solicitações e melhorar a experiência na Aplicação.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">3. Partilha de Informações</h4>
                <p>Podemos partilhar informações com gestores (para aprovação), prestadores de serviços (processamento de pagamentos) e autoridades (quando exigido por lei). <strong>Não vendemos</strong> as suas informações a terceiros.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">4. Segurança dos Dados</h4>
                <p>Implementamos encriptação de dados, autenticação segura, controlo de acesso baseado em funções e monitorização contínua de segurança.</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">5. Os Seus Direitos (RGPD/LGPD)</h4>
                <p>Você tem direito a acesso, retificação, eliminação, portabilidade, oposição e limitação do processamento dos seus dados. Pode exercer estes direitos através da funcionalidade "Excluir Minha Conta".</p>
              </section>
              
              <section>
                <h4 className="font-bold text-black dark:text-white mb-2">6. Contacto</h4>
                <p>Para questões sobre privacidade: x88app@gmail.com</p>
              </section>

              <section className="border-t border-neutral-200 dark:border-neutral-800 pt-4">
                <p className="text-xs text-neutral-500">
                  Esta política está em conformidade com o RGPD (UE) e a LGPD (Brasil). Para a versão completa, acesse a secção "Política de Privacidade" na aplicação após o registo.
                </p>
              </section>
            </div>
            
            <div className="p-4 border-t border-neutral-200 dark:border-neutral-800">
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="w-full bg-gradient-to-r from-[#00d749] to-[#00dc43] text-white py-3 rounded-xl font-semibold"
              >
                Entendi
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  )
}

export default Register
