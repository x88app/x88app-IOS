import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff, ArrowRight, AlertTriangle, UserX, Sun, Moon } from 'lucide-react'
import X88Logo from '../../components/ui/X88Logo'
import { useAuth } from '../../contexts/AuthContext'

const Login = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [isDarkMode, setIsDarkMode] = useState(false)
  const navigate = useNavigate()
  const { login, user } = useAuth()

  useEffect(() => {
    setIsDarkMode(document.documentElement.classList.contains('dark'))
  }, [])

  const toggleDarkMode = () => {
    const newMode = !isDarkMode
    setIsDarkMode(newMode)
    if (newMode) {
      document.documentElement.classList.add('dark')
      localStorage.setItem('darkMode', 'true')
    } else {
      document.documentElement.classList.remove('dark')
      localStorage.setItem('darkMode', 'false')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')
    
    const result = await login(email, password)
    
    setIsLoading(false)
    
    if (result.success) {
      navigate('/')
    } else {
      setError(result.error || 'E-mail ou senha incorretos')
    }
  }

  // Se o erro for de conta inativa, mostramos o card específico
  if (error.includes('Conta inativa')) {
    const whatsappMatch = error.match(/\|WHATSAPP:(.+)/)
    const whatsappNumber = whatsappMatch ? whatsappMatch[1] : null
    
    // Se tiver número, cria link do WhatsApp, senão mailto padrão
    const contactLink = whatsappNumber 
      ? `https://wa.me/${whatsappNumber.replace(/\D/g, '')}` 
      : "mailto:suporte@x88.com"
      
    const contactText = whatsappNumber 
      ? "Falar com seu Gestor via WhatsApp" 
      : "Entrar em contato com suporte"

    return (
      <div className="min-h-screen bg-[#4dff7a] dark:bg-black flex flex-col items-center justify-center p-6">
         <div className="w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl p-8 shadow-2xl text-center animate-in fade-in zoom-in duration-300">
            <div className="w-20 h-20 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <UserX className="w-10 h-10 text-red-600 dark:text-red-500" />
            </div>
            
            <h2 className="text-2xl font-bold text-black dark:text-white mb-3">
              Conta Desativada
            </h2>
            
            <p className="text-neutral-600 dark:text-neutral-400 mb-8 leading-relaxed">
              Sua conta foi desativada pelo administrador. Entre em contato com seu gestor para mais informações.
            </p>
            
            <div className="space-y-3">
              <button
                onClick={() => window.location.reload()}
                className="w-full bg-neutral-100 dark:bg-neutral-800 text-black dark:text-white py-4 rounded-2xl font-semibold hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
              >
                Tentar com outra conta
              </button>
              
              <a 
                href={contactLink}
                target={whatsappNumber ? "_blank" : undefined}
                rel={whatsappNumber ? "noopener noreferrer" : undefined}
                className="block w-full text-[#00d749] font-medium py-2 hover:underline flex items-center justify-center gap-2"
              >
                {contactText}
              </a>
            </div>
         </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#4dff7a] dark:bg-black flex flex-col relative">
      {/* Botão Dark Mode */}
      <button
        onClick={toggleDarkMode}
        className="absolute top-8 right-4 z-50 p-3 rounded-full bg-white/20 dark:bg-white/10 backdrop-blur-sm hover:bg-white/30 dark:hover:bg-white/20 transition-colors"
        aria-label="Alternar modo escuro"
      >
        {isDarkMode ? (
          <Sun className="w-5 h-5 text-white" />
        ) : (
          <Moon className="w-5 h-5 text-black" />
        )}
      </button>

      {/* Header com Logo */}
      <div className="pt-0 pb-0 px-6 flex justify-center -mt-16 -mb-4">
        <X88Logo className="object-contain" width={380} height={380} variant="auto" />
      </div>

      {/* Card de Login */}
      <div className="flex-1 bg-white dark:bg-neutral-950 rounded-t-3xl p-6 shadow-2xl -mt-16 relative z-10">
        <div className="max-w-md mx-auto">
          <h1 className="text-3xl font-bold text-black dark:text-white mb-2">
            Bem-vindo de volta
          </h1>
          <p className="text-neutral-600 dark:text-neutral-400 mb-8">
            Entre com suas credenciais para continuar
          </p>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 px-4 py-3 rounded-xl mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                E-mail
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
              </div>
            </div>

            {/* Senha */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Senha
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full pl-12 pr-12 py-4 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Recuperar Senha */}
            <div className="text-right">
              <Link
                to="/auth/forgot-password"
                className="text-sm font-medium text-[#00d749] hover:text-[#00dc43] transition-colors"
              >
                Esqueceu a senha?
              </Link>
            </div>

            {/* Botão de Login */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#00d749] to-[#00dc43] text-white py-4 rounded-2xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
                  Entrando...
                </>
              ) : (
                <>
                  Entrar
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-neutral-200 dark:border-neutral-800"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-white dark:bg-neutral-950 text-neutral-500">
                ou
              </span>
            </div>
          </div>

          {/* Link para Criar Conta */}
          <div className="text-center">
            <p className="text-neutral-600 dark:text-neutral-400">
              Ainda não tem uma conta?{' '}
              <Link
                to="/auth/register"
                className="font-semibold text-[#00d749] hover:text-[#00dc43] transition-colors"
              >
                Criar conta
              </Link>
            </p>
          </div>

          {/* Safe Area Bottom */}
          <div className="pb-16"></div>
        </div>
      </div>
    </div>
  )
}

export default Login
