import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom'
import { useEffect, useRef } from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import { RequestsProvider, useRequests } from './contexts/RequestsContext'
import { NotificationsProvider } from './contexts/NotificationsContext'
import { ToastProvider } from './contexts/ToastContext'
import { LanguageProvider } from './contexts/LanguageContext'
import { UIProvider, useUI } from './contexts/UIContext'
import Header from './components/layout/Header'
import BottomNav from './components/layout/BottomNav'
import ToastContainer from './components/layout/ToastContainer'
import PrivateRoute from './components/auth/PrivateRoute'

import Home from './pages/Home/Home'
import RequestsList from './pages/Requests/RequestsList'
import NewRequest from './pages/Requests/NewRequest'
import RequestDetails from './pages/Requests/RequestDetails'
import Reports from './pages/Reports/Reports'
import Profile from './pages/Profile/Profile'
import Chat from './pages/Chat/Chat'
import BankDetails from './pages/Profile/BankDetails'
import PersonalData from './pages/Profile/PersonalData'
import NotificationSettings from './pages/Profile/NotificationSettings'
import PrivacySecurity from './pages/Profile/PrivacySecurity'
import LanguageRegion from './pages/Profile/LanguageRegion'
import Help from './pages/Profile/Help'

import Login from './pages/Auth/Login'
import Register from './pages/Auth/Register'
import ForgotPassword from './pages/Auth/ForgotPassword'
import UpdatePassword from './pages/Auth/UpdatePassword'
import InitialSetup from './pages/Setup/InitialSetup'
import PrivacyPolicy from './pages/Legal/PrivacyPolicy'
import TermsOfUse from './pages/Legal/TermsOfUse'
import { LoadingScreen } from './components/LoadingScreen'

import { useWebPush } from './hooks/useWebPush'
import { useFirebasePush } from './hooks/useFirebasePush'
import { useStatusBar } from './hooks/useStatusBar'
import { useSwipeBack } from './hooks/useSwipeBack'

const queryClient = new QueryClient()

function AppContent() {
  useWebPush()
  useFirebasePush()
  useStatusBar()
  useSwipeBack()
  
  // Aplicar dark mode ao iniciar - detecta preferência do sistema na primeira vez
  useEffect(() => {
    const savedDarkMode = localStorage.getItem('darkMode')
    
    if (savedDarkMode === null) {
      // Primeira instalação: detecta preferência do sistema
      const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
      if (systemPrefersDark) {
        document.documentElement.classList.add('dark')
        localStorage.setItem('darkMode', 'true')
      } else {
        document.documentElement.classList.remove('dark')
        localStorage.setItem('darkMode', 'false')
      }
    } else if (savedDarkMode === 'true') {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [])
  const location = useLocation()
  const isAuthPage = location.pathname.startsWith('/auth') || location.pathname === '/setup'
  const isChatPage = location.pathname === '/chat'
  const { isLoading: isAuthLoading, isAuthenticated } = useAuth()
  const { isLoadingRequests } = useRequests()
  const { hideBottomNav } = useUI()

  // Store scroll positions per route
  const scrollPositions = useRef<Record<string, number>>({})
  const previousPathname = useRef<string>(location.pathname)

  // Save scroll position when leaving a route, restore when entering
  useEffect(() => {
    const mainScroll = document.getElementById('main-scroll')
    if (!mainScroll) return

    // Save scroll position of previous route
    if (previousPathname.current !== location.pathname) {
      scrollPositions.current[previousPathname.current] = mainScroll.scrollTop
      previousPathname.current = location.pathname
    }

    // Restore scroll position for current route (or scroll to top if not visited)
    const savedPosition = scrollPositions.current[location.pathname] ?? 0
    mainScroll.scrollTop = savedPosition
  }, [location.pathname])

  if (isAuthLoading || (isAuthenticated && isLoadingRequests && !isAuthPage)) {
    return <LoadingScreen />
  }

  return (
    <div className="flex flex-col h-screen bg-white dark:bg-black">
      <main id="main-scroll" className={`flex-1 overflow-y-auto ${!isAuthPage && !isChatPage ? 'pb-20' : ''}`}>
        {!isAuthPage && location.pathname !== '/' && <Header />}
        <Routes>
          <Route path="/auth/login" element={<Login />} />
          <Route path="/auth/register" element={<Register />} />
          <Route path="/auth/forgot-password" element={<ForgotPassword />} />
          <Route path="/auth/update-password" element={<UpdatePassword />} />
          <Route path="/setup" element={<InitialSetup />} />
          
          <Route path="/" element={<PrivateRoute><Home /></PrivateRoute>} />
          <Route path="/requests" element={<PrivateRoute><RequestsList /></PrivateRoute>} />
          <Route path="/requests/new" element={<PrivateRoute><NewRequest /></PrivateRoute>} />
          <Route path="/requests/:id" element={<PrivateRoute><RequestDetails /></PrivateRoute>} />
          <Route path="/reports" element={<PrivateRoute><Reports /></PrivateRoute>} />
          <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />
          <Route path="/profile/personal" element={<PrivateRoute><PersonalData /></PrivateRoute>} />
          <Route path="/profile/bank" element={<PrivateRoute><BankDetails /></PrivateRoute>} />
          <Route path="/profile/notifications" element={<PrivateRoute><NotificationSettings /></PrivateRoute>} />
          <Route path="/profile/security" element={<PrivateRoute><PrivacySecurity /></PrivateRoute>} />
          <Route path="/profile/language" element={<PrivateRoute><LanguageRegion /></PrivateRoute>} />
          <Route path="/profile/help" element={<PrivateRoute><Help /></PrivateRoute>} />
          <Route path="/chat" element={<PrivateRoute><Chat /></PrivateRoute>} />
          
          {/* Legal Pages - accessible without auth for App Store review */}
          <Route path="/legal/privacy" element={<PrivacyPolicy />} />
          <Route path="/legal/terms" element={<TermsOfUse />} />
        </Routes>
      </main>

      {!isAuthPage && !isChatPage && !hideBottomNav && <BottomNav />}
      <ToastContainer />
    </div>
  )
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <AuthProvider>
          <LanguageProvider>
            <ToastProvider>
              <UIProvider>
                <NotificationsProvider>
                  <RequestsProvider>
                    <AppContent />
                  </RequestsProvider>
                </NotificationsProvider>
              </UIProvider>
            </ToastProvider>
          </LanguageProvider>
        </AuthProvider>
      </Router>
    </QueryClientProvider>
  )
}

export default App
