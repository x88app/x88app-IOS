import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { translations, TranslationKey } from '../i18n/translations';

type Language = 'pt-BR' | 'pt-PT';
type Timezone = 'America/Sao_Paulo' | 'Europe/Lisbon';

interface LanguageContextType {
  language: Language;
  timezone: Timezone;
  setLanguage: (lang: Language) => void;
  formatDate: (date: Date | string | number, options?: Intl.DateTimeFormatOptions) => string;
  formatTime: (date: Date | string | number) => string;
  formatDateTime: (date: Date | string | number) => string;
  formatCurrency: (value: number) => string;
  formatMessage: (message: string) => string;
  currencySymbol: string;
  t: (key: TranslationKey) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage deve ser usado dentro de LanguageProvider');
  }
  return context;
};

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguageState] = useState<Language>('pt-PT');
  const [timezone, setTimezone] = useState<Timezone>('Europe/Lisbon');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('app_language') as Language;
    if (savedLanguage && (savedLanguage === 'pt-BR' || savedLanguage === 'pt-PT')) {
      setLanguage(savedLanguage);
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('app_language', lang);
    
    // Definir fuso horário baseado no idioma
    if (lang === 'pt-BR') {
      setTimezone('America/Sao_Paulo');
    } else if (lang === 'pt-PT') {
      setTimezone('Europe/Lisbon');
    }
  };

  const t = (key: TranslationKey): string => {
    return translations[language][key] || key;
  };

  const formatDate = (date: Date | string | number, options?: Intl.DateTimeFormatOptions) => {
    const dateObj = new Date(date);
    
    const defaultOptions: Intl.DateTimeFormatOptions = {
      timeZone: timezone,
      ...options
    };

    return new Intl.DateTimeFormat(language, defaultOptions).format(dateObj);
  };

  const formatTime = (date: Date | string | number) => {
    return formatDate(date, {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDateTime = (date: Date | string | number) => {
    return formatDate(date, {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const currencySymbol = language === 'pt-BR' ? 'R$' : '€';

  const formatCurrency = (value: number) => {
    // Ensure value is a number
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(numValue)) return `${currencySymbol}0${language === 'pt-BR' ? ',' : '.'}00`;
    
    if (language === 'pt-BR') {
      // Portuguese (Brazil): Real, comma for decimal, dot for thousands
      // Example: R$ 1.000,00
      const formattedValue = numValue.toLocaleString('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
      return `R$ ${formattedValue}`;
    } else {
      // Portuguese (Portugal): Euro, dot for decimal (as requested by user)
      // Example: € 1,000.00 or € 500.00
      // Using en-US locale for number formatting to get dot decimal
      const formattedValue = numValue.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
      return `€${formattedValue}`;
    }
  };

  const formatMessage = (message: string) => {
    if (language !== 'pt-BR') return message

    let formatted = message

    // Replace Currency (Euro to Real)
    // Matches €10.00, € 10.00, etc.
    formatted = formatted.replace(/€\s?(\d+[.,]?\d*)/g, (match, value) => {
      // value could be "35.35" or "1000"
      const num = parseFloat(value.replace(',', '.')) // Ensure dot decimal for parsing
      if (isNaN(num)) return match
      return `R$ ${num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
    })

    // Replace Payment Methods
    formatted = formatted.replace(/MB\s?Way/gi, 'PIX')
    formatted = formatted.replace(/IBAN/g, 'Conta Bancária')

    return formatted
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        timezone,
        setLanguage,
        formatDate,
        formatTime,
        formatDateTime,
        formatCurrency,
        formatMessage,
        currencySymbol,
        t
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};
