import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './AuthContext'
import { useToast } from './ToastContext'

export interface Notification {
  id: string
  title: string
  message: string
  type: 'success' | 'info' | 'warning' | 'error'
  read: boolean
  timestamp: string
  requestId?: string
}

interface NotificationsContextType {
  notifications: Notification[]
  unreadCount: number
  addNotification: (notification: Omit<Notification, 'id' | 'read' | 'timestamp'>) => void
  markAsRead: (id: string) => void
  markAllAsRead: () => void
  clearAll: () => void
}

const NotificationsContext = createContext<NotificationsContextType | undefined>(undefined)

export const NotificationsProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth()
  const { showToast } = useToast()
  const [notifications, setNotifications] = useState<Notification[]>([])

  useEffect(() => {
    if (user) {
      loadNotifications()
      
      const channel = supabase
        .channel('notificacoes-changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'notificacoes',
            filter: `usuario_id=eq.${user.id}`
          },
          (payload) => {
            if (payload.eventType === 'INSERT') {
              const newNotif = payload.new
              const toastType = newNotif.tipo === 'warning' ? 'info' : newNotif.tipo
              showToast(newNotif.mensagem, toastType)
            }
            loadNotifications()
          }
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    }
  }, [user])

  const loadNotifications = async () => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('notificacoes')
        .select('*')
        .eq('usuario_id', user.id)
        .order('data_criacao', { ascending: false })

      if (error) {
        console.error('Erro ao carregar notificações:', error)
        return
      }

      const mappedNotifications: Notification[] = (data || []).map(item => ({
        id: item.id,
        title: item.titulo,
        message: item.mensagem,
        type: item.tipo as 'success' | 'info' | 'warning' | 'error',
        read: item.lida,
        timestamp: item.data_criacao,
        requestId: item.solicitacao_id
      }))

      setNotifications(mappedNotifications)
    } catch (error) {
      console.error('Erro ao carregar notificações:', error)
    }
  }

  const addNotification = async (notification: Omit<Notification, 'id' | 'read' | 'timestamp'>) => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('notificacoes')
        .insert([
          {
            usuario_id: user.id,
            titulo: notification.title,
            mensagem: notification.message,
            tipo: notification.type,
            solicitacao_id: notification.requestId,
            lida: false,
            data_criacao: new Date().toISOString()
          }
        ])
        .select()
        .single()

      if (error) {
        console.error('Erro ao adicionar notificação:', error)
        return
      }

      const newNotification: Notification = {
        id: data.id,
        title: notification.title,
        message: notification.message,
        type: notification.type,
        read: false,
        timestamp: data.data_criacao,
        requestId: notification.requestId
      }

      setNotifications(prev => [newNotification, ...prev])
    } catch (error) {
      console.error('Erro ao adicionar notificação:', error)
    }
  }

  const markAsRead = async (id: string) => {
    try {
      const { error } = await supabase
        .from('notificacoes')
        .update({ lida: true })
        .eq('id', id)

      if (error) {
        console.error('Erro ao marcar notificação como lida:', error)
        return
      }

      setNotifications(prev =>
        prev.map(notif => (notif.id === id ? { ...notif, read: true } : notif))
      )
    } catch (error) {
      console.error('Erro ao marcar notificação como lida:', error)
    }
  }

  const markAllAsRead = async () => {
    if (!user) return

    try {
      const { error } = await supabase
        .from('notificacoes')
        .update({ lida: true })
        .eq('usuario_id', user.id)
        .eq('lida', false)

      if (error) {
        console.error('Erro ao marcar todas como lidas:', error)
        return
      }

      setNotifications(prev => prev.map(notif => ({ ...notif, read: true })))
    } catch (error) {
      console.error('Erro ao marcar todas como lidas:', error)
    }
  }

  const clearAll = async () => {
    if (!user) return

    try {
      const { error } = await supabase
        .from('notificacoes')
        .delete()
        .eq('usuario_id', user.id)

      if (error) {
        console.error('Erro ao limpar notificações:', error)
        return
      }

      setNotifications([])
    } catch (error) {
      console.error('Erro ao limpar notificações:', error)
    }
  }

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <NotificationsContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        clearAll,
      }}
    >
      {children}
    </NotificationsContext.Provider>
  )
}

export const useNotifications = () => {
  const context = useContext(NotificationsContext)
  if (!context) {
    throw new Error('useNotifications must be used within NotificationsProvider')
  }
  return context
}
