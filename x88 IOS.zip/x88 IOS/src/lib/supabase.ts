import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    '❌ Credenciais do Supabase não encontradas!\n\n' +
    'Por favor, crie um arquivo .env na raiz do projeto com:\n' +
    'VITE_SUPABASE_URL=sua-url-aqui\n' +
    'VITE_SUPABASE_ANON_KEY=sua-chave-aqui\n\n' +
    'Veja .env.example para mais detalhes.'
  )
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})
