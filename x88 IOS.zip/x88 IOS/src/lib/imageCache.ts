const DB_NAME = 'x88-image-cache'
const DB_VERSION = 1
const STORE_NAME = 'images'
const CACHE_DURATION = 7 * 24 * 60 * 60 * 1000 // 7 dias

// Cache em memória para evitar piscar ao navegar
const memoryCache: Map<string, string> = new Map()

interface CachedImage {
  url: string
  blob: Blob
  timestamp: number
}

let dbPromise: Promise<IDBDatabase> | null = null

const openDB = (): Promise<IDBDatabase> => {
  if (dbPromise) return dbPromise

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'url' })
      }
    }
  })

  return dbPromise
}

const getHashedKey = (url: string): string => {
  let hash = 0
  for (let i = 0; i < url.length; i++) {
    const char = url.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return `img_${Math.abs(hash)}`
}

export const getCachedImage = async (url: string): Promise<string | null> => {
  try {
    const db = await openDB()
    const transaction = db.transaction(STORE_NAME, 'readonly')
    const store = transaction.objectStore(STORE_NAME)
    const key = getHashedKey(url)

    return new Promise((resolve) => {
      const request = store.get(key)

      request.onsuccess = () => {
        const result = request.result as CachedImage | undefined
        if (result && Date.now() - result.timestamp < CACHE_DURATION) {
          resolve(URL.createObjectURL(result.blob))
        } else {
          resolve(null)
        }
      }

      request.onerror = () => resolve(null)
    })
  } catch {
    return null
  }
}

export const cacheImage = async (url: string, blob: Blob): Promise<void> => {
  try {
    const db = await openDB()
    const transaction = db.transaction(STORE_NAME, 'readwrite')
    const store = transaction.objectStore(STORE_NAME)
    const key = getHashedKey(url)

    const data: CachedImage & { url: string } = {
      url: key,
      blob,
      timestamp: Date.now()
    }

    store.put(data)
  } catch (error) {
    console.warn('Erro ao cachear imagem:', error)
  }
}

export const loadImageWithCache = async (url: string): Promise<string> => {
  if (!url) return ''

  // Verificar cache em memória primeiro (instantâneo)
  const memCached = memoryCache.get(url)
  if (memCached) {
    return memCached
  }

  // Tentar obter do IndexedDB
  const cached = await getCachedImage(url)
  if (cached) {
    memoryCache.set(url, cached)
    return cached
  }

  // Se não estiver no cache, baixar e cachear
  try {
    const response = await fetch(url)
    const blob = await response.blob()
    await cacheImage(url, blob)
    const blobUrl = URL.createObjectURL(blob)
    memoryCache.set(url, blobUrl)
    return blobUrl
  } catch {
    // Se falhar, retornar a URL original
    return url
  }
}

// Verificação síncrona do cache em memória
export const getMemoryCachedImage = (url: string): string | null => {
  return memoryCache.get(url) || null
}

export const preloadImages = async (urls: string[]): Promise<void> => {
  await Promise.all(urls.map(url => loadImageWithCache(url)))
}

export const clearImageCache = async (): Promise<void> => {
  try {
    const db = await openDB()
    const transaction = db.transaction(STORE_NAME, 'readwrite')
    const store = transaction.objectStore(STORE_NAME)
    store.clear()
  } catch (error) {
    console.warn('Erro ao limpar cache:', error)
  }
}
