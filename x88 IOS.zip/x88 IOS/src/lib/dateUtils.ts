/**
 * Calcula a próxima segunda-feira a partir de uma data
 * Se hoje for segunda, retorna a próxima segunda (não hoje)
 */
export function getNextMonday(fromDate: Date = new Date()): Date {
  const date = new Date(fromDate)
  const dayOfWeek = date.getDay() // 0 = Domingo, 1 = Segunda, ..., 6 = Sábado
  
  // Calcula quantos dias faltam para a próxima segunda
  // Se hoje é segunda (1), adiciona 7 dias para pegar a próxima segunda
  const daysUntilMonday = dayOfWeek === 0 ? 1 : // Domingo -> 1 dia
                          dayOfWeek === 1 ? 7 : // Segunda -> 7 dias (próxima segunda)
                          8 - dayOfWeek // Outros dias -> dias restantes até segunda
  
  date.setDate(date.getDate() + daysUntilMonday)
  date.setHours(0, 0, 0, 0)
  
  return date
}

/**
 * Formata a data da próxima segunda para exibição
 * Retorna no formato: "15/12/2025 (Segunda-feira)"
 */
export function formatNextMondayDate(fromDate: Date = new Date(), locale: string = 'pt-PT'): string {
  const nextMonday = getNextMonday(fromDate)
  
  const dateStr = nextMonday.toLocaleDateString(locale, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  })
  
  const dayName = nextMonday.toLocaleDateString(locale, {
    weekday: 'long'
  })
  
  // Capitaliza a primeira letra do dia
  const capitalizedDay = dayName.charAt(0).toUpperCase() + dayName.slice(1)
  
  return `${dateStr} (${capitalizedDay})`
}

/**
 * Retorna uma string curta da próxima segunda
 * Formato: "Seg, 15/12"
 */
export function formatNextMondayShort(fromDate: Date = new Date(), locale: string = 'pt-PT'): string {
  const nextMonday = getNextMonday(fromDate)
  
  const dateStr = nextMonday.toLocaleDateString(locale, {
    day: '2-digit',
    month: '2-digit'
  })
  
  return `Seg, ${dateStr}`
}
