/// <reference lib="webworker" />

// Importa o Workbox do CDN
importScripts('https://storage.googleapis.com/workbox-cdn/releases/6.5.4/workbox-sw.js');

// Precache dos arquivos do app (gerado pelo Vite)
workbox.precaching.precacheAndRoute(self.__WB_MANIFEST || []);

// Limpa caches antigos
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // Lógica de limpeza se necessário
        })
      );
    })
  );
});

// Lógica de Recebimento de Push Notification
self.addEventListener('push', (event) => {
  let data = { title: 'Nova Notificação', body: 'Você tem uma nova mensagem.', url: '/' };

  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: '/logos/logotipo X88 green.fw.png', // Ícone Grande
    badge: '/logos/logotipo X88 green.fw.png', // Ícone Pequeno (Barra de status) - O ideal é ser branco/transparente
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    },
    actions: [
      { action: 'explore', title: 'Ver' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Clique na notificação
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Se já tiver uma janela aberta, foca nela
      for (const client of clientList) {
        if (client.url && 'focus' in client) {
          return client.focus();
        }
      }
      // Se não, abre uma nova
      if (clients.openWindow) {
        return clients.openWindow(event.notification.data.url);
      }
    })
  );
});
