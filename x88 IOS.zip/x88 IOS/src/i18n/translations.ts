export const translations = {
  'pt-BR': {
    // Menu
    'menu.home': 'Início',
    'menu.carteira': 'Histórico',
    'menu.solicitar': 'Solicitar',
    'menu.nova': 'Novo',
    'menu.solicitacoes': 'Solicitações',
    'menu.historico': 'Histórico',
    'menu.perfil': 'Perfil',
    
    // Home
    'home.ola': 'Olá',
    'home.saldo_disponivel': 'Resumo Disponível',
    'home.limite_disponivel': 'Limite Disponível',
    'home.solicitar_adiantamento': 'Solicitar Adiantamento',
    'home.novo_adiantamento': 'Novo Adiantamento',
    'home.solicite_rapido': 'Solicite rapidamente',
    'home.receber_satoshi': 'Receber Satoshi',
    'home.qr_code': 'QR Code Lightning',
    'home.ultimas_solicitacoes': 'Últimas Solicitações',
    'home.ver_todas': 'Ver todas',
    'home.nenhuma_solicitacao': 'Nenhuma solicitação recente',
    
    // Solicitar
    'solicitar.titulo': 'Solicitar Adiantamento',
    'solicitar.quanto': 'Qual valor você deseja solicitar?',
    'solicitar.valor_maximo': 'Valor máximo disponível',
    'solicitar.taxa': 'Taxa de serviço',
    'solicitar.receber': 'Você recebe',
    'solicitar.metodo': 'Onde você quer receber?',
    'solicitar.selecione_metodo': 'Selecione o método de recebimento',
    'solicitar.confirmar': 'Confirmar Solicitação',
    'solicitar.sucesso': 'Solicitação realizada com sucesso!',
    
    // Carteira
    'carteira.titulo': 'Meu Histórico',
    'carteira.saldo_euro': 'Total em Euro',
    'carteira.saldo_btc': 'Saldo em Bitcoin',
    
    // Histórico
    'historico.titulo': 'Histórico de Solicitações',
    'historico.filtrar': 'Filtrar',
    'historico.todos': 'Todos',
    'historico.pendentes': 'Pendentes',
    'historico.pagos': 'Pagos',
    'historico.rejeitados': 'Rejeitados',
    
    // Perfil / Configurações
    'perfil.titulo': 'Meu Perfil',
    'perfil.dados_pessoais': 'Dados Pessoais',
    'perfil.nome': 'Nome Completo',
    'perfil.email': 'E-mail',
    'perfil.telefone': 'Telefone',
    'perfil.salvar': 'Salvar Alterações',
    'perfil.configuracoes': 'Configurações',
    'perfil.idioma': 'Idioma',
    'perfil.sair': 'Sair do App',
    'perfil.editar': 'Editar Perfil',
    
    // Termos Gerais
    'geral.voltar': 'Voltar',
    'geral.confirmar': 'Confirmar',
    'geral.cancelar': 'Cancelar',
    'geral.pendente': 'Pendente',
    'geral.aprovado': 'Aprovado',
    'geral.pago': 'Pago',
    'geral.rejeitado': 'Rejeitado',
    
    // Chat IA
    'chat.titulo': 'X88 IA',
    'chat.placeholder': 'Digite sua mensagem...',
    'chat.limpar': 'Limpar conversa',
    'chat.digitando': 'Digitando...',
  },
  'pt-PT': {
    // Menu
    'menu.home': 'Início',
    'menu.carteira': 'Histórico',
    'menu.solicitar': 'Pedir',
    'menu.nova': 'Novo',
    'menu.solicitacoes': 'Pedidos',
    'menu.historico': 'Histórico',
    'menu.perfil': 'Perfil',
    
    // Home
    'home.ola': 'Olá',
    'home.saldo_disponivel': 'Resumo Disponível',
    'home.limite_disponivel': 'Limite Disponível',
    'home.solicitar_adiantamento': 'Pedir Adiantamento',
    'home.novo_adiantamento': 'Novo Adiantamento',
    'home.solicite_rapido': 'Peça rapidamente',
    'home.receber_satoshi': 'Receber Satoshi',
    'home.qr_code': 'QR Code Lightning',
    'home.ultimas_solicitacoes': 'Últimos Pedidos',
    'home.ver_todas': 'Ver todos',
    'home.nenhuma_solicitacao': 'Nenhum pedido recente',
    
    // Solicitar
    'solicitar.titulo': 'Pedir Adiantamento',
    'solicitar.quanto': 'Quanto quer adiantar?',
    'solicitar.valor_maximo': 'Valor máximo disponível',
    'solicitar.taxa': 'Taxa de serviço',
    'solicitar.receber': 'Você recebe',
    'solicitar.metodo': 'Onde quer receber?',
    'solicitar.selecione_metodo': 'Selecione o método de recebimento',
    'solicitar.confirmar': 'Confirmar Pedido',
    'solicitar.sucesso': 'Pedido realizado com sucesso!',
    
    // Carteira
    'carteira.titulo': 'A Minha Carteira',
    'carteira.saldo_euro': 'Saldo em Euro',
    'carteira.saldo_btc': 'Saldo em Bitcoin',
    
    // Histórico
    'historico.titulo': 'Histórico de Pedidos',
    'historico.filtrar': 'Filtrar',
    'historico.todos': 'Todos',
    'historico.pendentes': 'Pendentes',
    'historico.pagos': 'Pagos',
    'historico.rejeitados': 'Rejeitados',
    
    // Perfil / Configurações
    'perfil.titulo': 'O Meu Perfil',
    'perfil.dados_pessoais': 'Dados Pessoais',
    'perfil.nome': 'Nome Completo',
    'perfil.email': 'E-mail',
    'perfil.telefone': 'Telemóvel',
    'perfil.salvar': 'Guardar Alterações',
    'perfil.configuracoes': 'Definições',
    'perfil.idioma': 'Idioma',
    'perfil.sair': 'Sair da App',
    'perfil.editar': 'Editar Perfil',
    
    // Termos Gerais
    'geral.voltar': 'Voltar',
    'geral.confirmar': 'Confirmar',
    'geral.cancelar': 'Cancelar',
    'geral.pendente': 'Pendente',
    'geral.aprovado': 'Aprovado',
    'geral.pago': 'Pago',
    'geral.rejeitado': 'Rejeitado',
    
    // Chat IA
    'chat.titulo': 'X88 IA',
    'chat.placeholder': 'Escreva a sua mensagem...',
    'chat.limpar': 'Limpar conversa',
    'chat.digitando': 'A escrever...',
  }
};

export type TranslationKey = keyof typeof translations['pt-BR'];
