import { AlertTriangle, Eye, EyeOff, X } from 'lucide-react'
import { useState } from 'react'

interface DeleteAccountModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (password: string) => Promise<void>
  isLoading: boolean
}

export const DeleteAccountModal = ({ isOpen, onClose, onConfirm, isLoading }: DeleteAccountModalProps) => {
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')

  if (!isOpen) return null

  const handleSubmit = async () => {
    if (!password) {
      setError('Digite sua senha para confirmar')
      return
    }
    setError('')
    try {
      await onConfirm(password)
      setPassword('') 
    } catch (err) {
      // Error handling usually in parent
    }
  }

  const handleClose = () => {
      setPassword('')
      setError('')
      onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
        onClick={handleClose}
      />

      <div className="relative bg-white dark:bg-neutral-900 w-full max-w-sm rounded-3xl p-6 shadow-2xl transform transition-all scale-100">
        <button 
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-400 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mb-6">
            <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-500" />
          </div>

          <h3 className="text-xl font-bold text-black dark:text-white mb-2">
            Excluir Conta
          </h3>
          <p className="text-neutral-600 dark:text-neutral-400 mb-6 text-sm">
            Tem certeza que deseja excluir sua conta? Esta ação <b>não pode ser desfeita</b>. Todos os seus dados, histórico e solicitações serão apagados permanentemente.
          </p>

          <div className="w-full mb-6">
             <label className="block text-left text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Digite sua senha para confirmar
             </label>
             <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full p-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 border-transparent focus:border-red-500 focus:ring-0 text-black dark:text-white"
                  placeholder="Sua senha atual"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
             </div>
             {error && <p className="text-red-500 text-xs text-left mt-1">{error}</p>}
          </div>

          <div className="flex gap-3 w-full">
            <button
              onClick={handleClose}
              disabled={isLoading}
              className="flex-1 py-3.5 rounded-xl font-semibold text-neutral-700 dark:text-neutral-300 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors disabled:opacity-50"
            >
              Cancelar
            </button>
            <button
              onClick={handleSubmit}
              disabled={isLoading}
              className="flex-1 py-3.5 rounded-xl font-semibold text-white bg-red-600 hover:bg-red-700 transition-colors shadow-lg shadow-red-600/20 disabled:opacity-50 flex items-center justify-center"
            >
              {isLoading ? 'Excluindo...' : 'Excluir'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
