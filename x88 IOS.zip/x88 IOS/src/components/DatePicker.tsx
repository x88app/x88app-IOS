import { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'

interface DatePickerProps {
  selected: Date | null
  onChange: (date: Date) => void
  label: string
}

export const DatePicker = ({ selected, onChange, label }: DatePickerProps) => {
  const [currentMonth, setCurrentMonth] = useState(selected || new Date())
  const [showCalendar, setShowCalendar] = useState(false)
  const { formatDate } = useLanguage()

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ]

  const weekDays = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S']

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days: (number | null)[] = []

    // Adicionar dias vazios no início
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null)
    }

    // Adicionar dias do mês
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i)
    }

    return days
  }

  const previousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))
  }

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))
  }

  const selectDate = (day: number) => {
    const newDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day)
    onChange(newDate)
    setShowCalendar(false)
  }

  const isSelected = (day: number) => {
    if (!selected) return false
    return (
      selected.getDate() === day &&
      selected.getMonth() === currentMonth.getMonth() &&
      selected.getFullYear() === currentMonth.getFullYear()
    )
  }

  const isToday = (day: number) => {
    const today = new Date()
    return (
      today.getDate() === day &&
      today.getMonth() === currentMonth.getMonth() &&
      today.getFullYear() === currentMonth.getFullYear()
    )
  }

  const getFormattedDate = (date: Date | null) => {
    if (!date) return 'dd/mm/aaaa'
    return formatDate(date, {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  const days = getDaysInMonth(currentMonth)

  return (
    <div className="relative">
      <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
        {label}
      </label>
      
      <button
        type="button"
        onClick={() => setShowCalendar(!showCalendar)}
        className="w-full px-4 py-3 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#00d749] transition-all text-left"
      >
        {getFormattedDate(selected)}
      </button>

      {showCalendar && (
        <>
          <div 
            className="fixed inset-0 z-40"
            onClick={() => setShowCalendar(false)}
          />
          <div className="absolute left-0 right-0 mt-2 z-50 bg-white dark:bg-neutral-800 rounded-xl shadow-2xl border border-neutral-200 dark:border-neutral-700 p-4">
            {/* Header do calendário */}
            <div className="flex items-center justify-between mb-4">
              <button
                type="button"
                onClick={previousMonth}
                className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
              
              <h3 className="text-base font-bold text-black dark:text-white">
                {monthNames[currentMonth.getMonth()]} de {currentMonth.getFullYear()}
              </h3>
              
              <button
                type="button"
                onClick={nextMonth}
                className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-lg transition-colors"
              >
                <ChevronRight className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
            </div>

            {/* Dias da semana */}
            <div className="grid grid-cols-7 gap-1 mb-2">
              {weekDays.map((day, index) => (
                <div
                  key={index}
                  className="text-center text-xs font-semibold text-neutral-500 dark:text-neutral-400 py-2"
                >
                  {day}
                </div>
              ))}
            </div>

            {/* Dias do mês */}
            <div className="grid grid-cols-7 gap-1">
              {days.map((day, index) => (
                <div key={index}>
                  {day ? (
                    <button
                      type="button"
                      onClick={() => selectDate(day)}
                      className={`w-full aspect-square rounded-lg text-sm font-medium transition-all ${
                        isSelected(day)
                          ? 'bg-[#00d749] text-white'
                          : isToday(day)
                          ? 'bg-[#00d749]/20 text-[#00d749] font-bold'
                          : 'hover:bg-neutral-100 dark:hover:bg-neutral-700 text-black dark:text-white'
                      }`}
                    >
                      {day}
                    </button>
                  ) : (
                    <div className="w-full aspect-square" />
                  )}
                </div>
              ))}
            </div>

            {/* Botões de ação */}
            <div className="flex gap-2 mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-700">
              <button
                type="button"
                onClick={() => {
                  onChange(new Date())
                  setShowCalendar(false)
                }}
                className="flex-1 py-2 text-[#00d749] font-medium text-sm hover:bg-[#00d749]/10 rounded-lg transition-colors"
              >
                Hoje
              </button>
              <button
                type="button"
                onClick={() => setShowCalendar(false)}
                className="flex-1 py-2 bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-medium text-sm rounded-lg hover:bg-neutral-300 dark:hover:bg-neutral-600 transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
