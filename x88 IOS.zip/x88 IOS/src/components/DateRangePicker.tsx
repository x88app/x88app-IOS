import { useState, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { ChevronLeft, ChevronRight, Calendar, X } from 'lucide-react'

interface DateRangePickerProps {
  startDate: string
  endDate: string
  onStartDateChange: (date: string) => void
  onEndDateChange: (date: string) => void
  onClear: () => void
}

type SelectionMode = 'start' | 'end'

export const DateRangePicker = ({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  onClear
}: DateRangePickerProps) => {
  const [showCalendar, setShowCalendar] = useState(false)
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [selectionMode, setSelectionMode] = useState<SelectionMode>('start')

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ]

  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days: (number | null)[] = []

    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null)
    }

    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i)
    }

    return days
  }

  const previousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))
  }

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))
  }

  const formatDateString = (year: number, month: number, day: number): string => {
    const m = String(month + 1).padStart(2, '0')
    const d = String(day).padStart(2, '0')
    return `${year}-${m}-${d}`
  }

  const parseDate = (dateStr: string): Date | null => {
    if (!dateStr) return null
    const [year, month, day] = dateStr.split('-').map(Number)
    return new Date(year, month - 1, day)
  }

  const selectDate = (day: number) => {
    const dateStr = formatDateString(currentMonth.getFullYear(), currentMonth.getMonth(), day)
    
    if (selectionMode === 'start') {
      onStartDateChange(dateStr)
      if (endDate && new Date(dateStr) > new Date(endDate)) {
        onEndDateChange('')
      }
      setSelectionMode('end')
    } else {
      if (startDate && new Date(dateStr) < new Date(startDate)) {
        onStartDateChange(dateStr)
        onEndDateChange(startDate)
      } else {
        onEndDateChange(dateStr)
      }
      setShowCalendar(false)
      setSelectionMode('start')
    }
  }

  const isSelected = (day: number): 'start' | 'end' | 'range' | false => {
    const dateStr = formatDateString(currentMonth.getFullYear(), currentMonth.getMonth(), day)
    
    if (startDate === dateStr) return 'start'
    if (endDate === dateStr) return 'end'
    
    if (startDate && endDate) {
      const current = new Date(dateStr)
      const start = new Date(startDate)
      const end = new Date(endDate)
      if (current > start && current < end) return 'range'
    }
    
    return false
  }

  const isToday = (day: number) => {
    const today = new Date()
    return (
      today.getDate() === day &&
      today.getMonth() === currentMonth.getMonth() &&
      today.getFullYear() === currentMonth.getFullYear()
    )
  }

  const formatDisplayDate = (dateStr: string): string => {
    if (!dateStr) return '--/--/----'
    const date = parseDate(dateStr)
    if (!date) return '--/--/----'
    return date.toLocaleDateString('pt-BR')
  }

  const setQuickRange = (days: number) => {
    const end = new Date()
    const start = new Date()
    start.setDate(start.getDate() - days)
    
    onStartDateChange(formatDateString(start.getFullYear(), start.getMonth(), start.getDate()))
    onEndDateChange(formatDateString(end.getFullYear(), end.getMonth(), end.getDate()))
    setShowCalendar(false)
  }

  const setThisMonth = () => {
    const now = new Date()
    const start = new Date(now.getFullYear(), now.getMonth(), 1)
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0)
    
    onStartDateChange(formatDateString(start.getFullYear(), start.getMonth(), start.getDate()))
    onEndDateChange(formatDateString(end.getFullYear(), end.getMonth(), end.getDate()))
    setShowCalendar(false)
  }

  const setLastMonth = () => {
    const now = new Date()
    const start = new Date(now.getFullYear(), now.getMonth() - 1, 1)
    const end = new Date(now.getFullYear(), now.getMonth(), 0)
    
    onStartDateChange(formatDateString(start.getFullYear(), start.getMonth(), start.getDate()))
    onEndDateChange(formatDateString(end.getFullYear(), end.getMonth(), end.getDate()))
    setShowCalendar(false)
  }

  useEffect(() => {
    if (showCalendar && startDate) {
      const date = parseDate(startDate)
      if (date) {
        setCurrentMonth(new Date(date.getFullYear(), date.getMonth(), 1))
      }
    }
  }, [showCalendar])

  const days = getDaysInMonth(currentMonth)

  return (
    <div className="bg-white dark:bg-neutral-800 border-2 border-neutral-200 dark:border-neutral-700 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-[#00d749]" />
          <span className="font-semibold text-black dark:text-white">Filtrar por Data</span>
        </div>
        {(startDate || endDate) && (
          <button
            onClick={onClear}
            className="p-1 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-neutral-500" />
          </button>
        )}
      </div>

      <button
        onClick={() => setShowCalendar(!showCalendar)}
        className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-3 flex items-center justify-between hover:border-[#00d749] transition-all"
      >
        <div className="flex items-center gap-3">
          <div className="text-left">
            <p className="text-xs text-neutral-500 dark:text-neutral-400">De</p>
            <p className={`text-sm font-medium ${startDate ? 'text-black dark:text-white' : 'text-neutral-400'}`}>
              {formatDisplayDate(startDate)}
            </p>
          </div>
          <div className="w-px h-8 bg-neutral-300 dark:bg-neutral-600" />
          <div className="text-left">
            <p className="text-xs text-neutral-500 dark:text-neutral-400">Até</p>
            <p className={`text-sm font-medium ${endDate ? 'text-black dark:text-white' : 'text-neutral-400'}`}>
              {formatDisplayDate(endDate)}
            </p>
          </div>
        </div>
        <Calendar className="w-5 h-5 text-neutral-400" />
      </button>

      {showCalendar && createPortal(
        <>
          <div 
            style={{ zIndex: 999999 }}
            className="fixed inset-0 bg-black/20"
            onClick={() => setShowCalendar(false)}
          />
          <div 
            style={{ zIndex: 1000000 }}
            className="fixed left-4 right-4 top-1/2 -translate-y-1/2 bg-white dark:bg-neutral-800 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-700 p-4 max-w-md mx-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-black dark:text-white">
                Selecionar Período
              </h3>
              <button
                onClick={() => setShowCalendar(false)}
                className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-neutral-500" />
              </button>
            </div>

            <div className="flex gap-2 mb-4 flex-wrap">
              <button
                onClick={() => setQuickRange(7)}
                className="px-3 py-1.5 text-xs font-medium bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-lg hover:bg-[#00d749]/20 hover:text-[#00d749] transition-colors"
              >
                Últimos 7 dias
              </button>
              <button
                onClick={() => setQuickRange(30)}
                className="px-3 py-1.5 text-xs font-medium bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-lg hover:bg-[#00d749]/20 hover:text-[#00d749] transition-colors"
              >
                Últimos 30 dias
              </button>
              <button
                onClick={setThisMonth}
                className="px-3 py-1.5 text-xs font-medium bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-lg hover:bg-[#00d749]/20 hover:text-[#00d749] transition-colors"
              >
                Este mês
              </button>
              <button
                onClick={setLastMonth}
                className="px-3 py-1.5 text-xs font-medium bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-lg hover:bg-[#00d749]/20 hover:text-[#00d749] transition-colors"
              >
                Mês passado
              </button>
            </div>

            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setSelectionMode('start')}
                className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                  selectionMode === 'start'
                    ? 'bg-[#00d749] text-white'
                    : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <span className="text-xs block">Data Inicial</span>
                <span className="font-bold">{formatDisplayDate(startDate)}</span>
              </button>
              <button
                onClick={() => setSelectionMode('end')}
                className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                  selectionMode === 'end'
                    ? 'bg-[#00d749] text-white'
                    : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <span className="text-xs block">Data Final</span>
                <span className="font-bold">{formatDisplayDate(endDate)}</span>
              </button>
            </div>

            <div className="flex items-center justify-between mb-3">
              <button
                type="button"
                onClick={previousMonth}
                className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
              
              <h3 className="text-base font-bold text-black dark:text-white">
                {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
              </h3>
              
              <button
                type="button"
                onClick={nextMonth}
                className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-lg transition-colors"
              >
                <ChevronRight className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1 mb-2">
              {weekDays.map((day, index) => (
                <div
                  key={index}
                  className="text-center text-xs font-semibold text-neutral-500 dark:text-neutral-400 py-2"
                >
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
              {days.map((day, index) => {
                const selection = day ? isSelected(day) : false
                
                return (
                  <div key={index}>
                    {day ? (
                      <button
                        type="button"
                        onClick={() => selectDate(day)}
                        className={`w-full aspect-square rounded-lg text-sm font-medium transition-all ${
                          selection === 'start' || selection === 'end'
                            ? 'bg-[#00d749] text-white shadow-lg'
                            : selection === 'range'
                            ? 'bg-[#00d749]/20 text-[#00d749]'
                            : isToday(day)
                            ? 'bg-neutral-200 dark:bg-neutral-600 text-black dark:text-white font-bold'
                            : 'hover:bg-neutral-100 dark:hover:bg-neutral-700 text-black dark:text-white'
                        }`}
                      >
                        {day}
                      </button>
                    ) : (
                      <div className="w-full aspect-square" />
                    )}
                  </div>
                )
              })}
            </div>

            <div className="flex gap-2 mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-700">
              <button
                type="button"
                onClick={() => {
                  onClear()
                  setShowCalendar(false)
                }}
                className="flex-1 py-3 bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-semibold text-sm rounded-xl hover:bg-neutral-300 dark:hover:bg-neutral-600 transition-colors"
              >
                Limpar
              </button>
              <button
                type="button"
                onClick={() => setShowCalendar(false)}
                className="flex-1 py-3 bg-[#00d749] text-white font-semibold text-sm rounded-xl hover:bg-[#00c040] transition-colors"
              >
                Aplicar
              </button>
            </div>
          </div>
        </>,
        document.body
      )}
    </div>
  )
}
