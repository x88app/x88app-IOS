import { useState, useEffect } from 'react'
import { Euro } from 'lucide-react'
import { useRequests } from '../contexts/RequestsContext'
import { useAuth } from '../contexts/AuthContext'
import { useLanguage } from '../contexts/LanguageContext'

export const PaymentCards = () => {
  const { requests } = useRequests()
  const { user } = useAuth()
  const { formatCurrency, currencySymbol, language } = useLanguage()
  const isBR = language === 'pt-BR'
  const [currentCard, setCurrentCard] = useState(0)
  const [touchStart, setTouchStart] = useState(0)
  const [touchEnd, setTouchEnd] = useState(0)

  const bankDetails = user?.bankDetails
  const lightningAddress = user?.bankDetails?.wallet || ''

  const approvedRequests = requests.filter(req => req.status === 'paid')
  
  const totalEuro = approvedRequests
    .filter(req => req.currency === 'EUR')
    .reduce((sum, req) => sum + req.amount, 0) // Soma valor recebido (amount)
  
  const totalSats = approvedRequests
    .filter(req => req.currency === 'SATS')
    .reduce((sum, req) => sum + Math.round(req.amount), 0) // Soma valor recebido (amount)

  useEffect(() => {
    console.log('💳 PaymentCards - Total Requests:', requests.length)
    console.log('💳 PaymentCards - Approved Requests:', approvedRequests.length)
    console.log('💶 Total EUR:', totalEuro)
    console.log('⚡ Total SATS:', totalSats)
    console.log('👤 User bankDetails:', bankDetails)
    console.log('⚡ Lightning Address:', lightningAddress)
  }, [requests, approvedRequests.length, totalEuro, totalSats, bankDetails, lightningAddress])

  const cards = [
    {
      id: 1,
      title: 'Total em ' + (currencySymbol === 'R$' ? 'Reais' : 'Euro'),
      amount: formatCurrency(totalEuro),
      currency: 'EUR',
      gradient: 'bg-[#00d079]',
      icon: currencySymbol,
    },
    {
      id: 2,
      title: 'Total em Satoshi',
      amount: `${totalSats.toLocaleString('pt-PT')} sats`,
      currency: 'SATS',
      gradient: 'bg-[#ff8b21]',
      icon: '₿',
    },
  ]

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return
    
    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe && currentCard < cards.length - 1) {
      setCurrentCard(currentCard + 1)
    }
    if (isRightSwipe && currentCard > 0) {
      setCurrentCard(currentCard - 1)
    }

    setTouchStart(0)
    setTouchEnd(0)
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setTouchStart(e.clientX)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (touchStart) {
      setTouchEnd(e.clientX)
    }
  }

  const handleMouseUp = () => {
    if (!touchStart || !touchEnd) return
    
    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe && currentCard < cards.length - 1) {
      setCurrentCard(currentCard + 1)
    }
    if (isRightSwipe && currentCard > 0) {
      setCurrentCard(currentCard - 1)
    }

    setTouchStart(0)
    setTouchEnd(0)
  }

  return (
    <div className="relative -mx-2">
      <div
        className="relative h-64 cursor-grab active:cursor-grabbing px-2"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {cards.map((card, index) => {
          const isActive = index === currentCard
          const isPrev = index < currentCard
          const isNext = index > currentCard

          let positionClass = ''
          let zIndexClass = ''
          
          if (isActive) {
            positionClass = 'translate-x-0'
            zIndexClass = 'z-20'
          } else if (isNext) {
            positionClass = 'translate-x-[95%]'
            zIndexClass = 'z-10'
          } else if (isPrev) {
            positionClass = '-translate-x-full'
            zIndexClass = 'z-0'
          }

          return (
            <div
              key={card.id}
              className={`absolute inset-0 transition-all duration-500 ease-in-out ${positionClass} ${zIndexClass}`}
            >
              <div className={`${card.gradient} rounded-2xl p-6 h-full`}>
                <div className="h-full flex flex-col justify-between">
                  <div>
                    <p className="text-white text-sm font-semibold mb-3">
                      {card.title}
                    </p>
                    <p className="text-white text-3xl font-bold tracking-tight">
                      {card.amount}
                    </p>
                  </div>

                  <div className="flex items-end justify-between gap-4">
                    <div className="space-y-3 flex-1">
                    {card.currency === 'EUR' && bankDetails && (
                      <div className="space-y-2">
                        {bankDetails.iban && (
                          <div>
                            <p className="text-white/90 text-xs uppercase tracking-wide mb-1 font-semibold">{isBR ? 'Conta Bancária' : 'IBAN'}</p>
                            <p className="text-white font-mono text-sm font-bold">
                              {bankDetails.iban}
                            </p>
                          </div>
                        )}
                        {bankDetails.mbwayPhone && (
                          <div>
                            <p className="text-white/90 text-xs uppercase tracking-wide mb-1 font-semibold">{isBR ? 'PIX' : 'MBway'}</p>
                            <p className="text-white font-mono text-sm font-bold">
                              {bankDetails.mbwayPhone}
                            </p>
                          </div>
                        )}
                        {bankDetails.bankHolderName && (
                          <div>
                            <p className="text-white/90 text-xs uppercase tracking-wide mb-1 font-semibold">Titular</p>
                            <p className="text-white text-base font-bold uppercase">
                              {bankDetails.bankHolderName}
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {card.currency === 'SATS' && (
                      <div className="space-y-2">
                        {lightningAddress && (
                          <div>
                            <p className="text-white/90 text-xs uppercase tracking-wide mb-1 font-semibold">Endereço Lightning</p>
                            <p className="text-white font-mono text-xs font-bold break-all leading-relaxed">
                              {lightningAddress}
                            </p>
                          </div>
                        )}
                        {bankDetails?.bankHolderName && (
                          <div>
                            <p className="text-white/90 text-xs uppercase tracking-wide mb-1 font-semibold">Titular</p>
                            <p className="text-white text-base font-bold uppercase">
                              {bankDetails.bankHolderName}
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                    </div>

                    <div className="text-right">
                      <p className="text-white/90 text-xs font-semibold mb-1">Aprovadas</p>
                      <p className="text-white text-2xl font-bold">
                        {approvedRequests.filter(req => req.currency === card.currency).length}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
