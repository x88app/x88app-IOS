import { useState, useRef, useEffect } from 'react'
import { X, Send, Trash2, Sparkles, ExternalLink } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useChat } from '../hooks/useChat'
import { useLanguage } from '../contexts/LanguageContext'
import { useAuth } from '../contexts/AuthContext'
import { useUI } from '../contexts/UIContext'

interface ChatPopupProps {
  isOpen: boolean
  onClose: () => void
}

const parseMessageWithButtons = (text: string, navigate: (path: string) => void, onClose: () => void) => {
  const buttonRegex = /\[BUTTON:([^\]:]+):([^\]]+)\]/g
  const parts: (string | JSX.Element)[] = []
  let lastIndex = 0
  let match

  while ((match = buttonRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.slice(lastIndex, match.index))
    }

    const buttonText = match[1]
    const buttonUrl = match[2]
    const isExternal = buttonUrl.startsWith('http') || buttonUrl.startsWith('mailto:') || buttonUrl.startsWith('tel:')

    parts.push(
      <button
        key={`btn-${match.index}`}
        onClick={() => {
          if (isExternal) {
            window.open(buttonUrl, '_blank')
          } else {
            // Adiciona parâmetro para voltar ao chat popup
            const urlWithFrom = buttonUrl.includes('?') 
              ? `${buttonUrl}&from=chatpopup` 
              : `${buttonUrl}?from=chatpopup`
            // Fechar o chat primeiro e aguardar um tick para garantir que o estado seja atualizado
            onClose()
            setTimeout(() => {
              navigate(urlWithFrom)
            }, 50)
          }
        }}
        className="flex items-center gap-2 mt-2 px-4 py-2.5 bg-[#00d749] hover:bg-[#00c142] text-white rounded-xl font-medium text-sm transition-colors w-full justify-center"
      >
        {buttonText}
        {isExternal && <ExternalLink className="w-4 h-4" />}
      </button>
    )

    lastIndex = match.index + match[0].length
  }

  if (lastIndex < text.length) {
    parts.push(text.slice(lastIndex))
  }

  return parts.length > 0 ? parts : [text]
}

export const ChatPopup = ({ isOpen, onClose }: ChatPopupProps) => {
  const navigate = useNavigate()
  const { messages, isLoading, sendMessage, clearHistory } = useChat()
  const { language } = useLanguage()
  const { user } = useAuth()
  const { setHideBottomNav } = useUI()
  const [inputValue, setInputValue] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [showClearConfirm, setShowClearConfirm] = useState(false)

  const isBR = language === 'pt-BR'

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus()
      setHideBottomNav(true)
    } else {
      setHideBottomNav(false)
    }
  }, [isOpen, setHideBottomNav])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputValue.trim() && !isLoading) {
      sendMessage(inputValue)
      setInputValue('')
    }
  }

  const handleClear = () => {
    clearHistory()
    setShowClearConfirm(false)
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString(isBR ? 'pt-BR' : 'pt-PT', {
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const welcomeMessage = isBR
    ? `Olá${user?.name ? `, ${user.name.split(' ')[0]}` : ''}! 👋\n\nSou a X88 IA, sua assistente virtual. Como posso ajudar?`
    : `Olá${user?.name ? `, ${user.name.split(' ')[0]}` : ''}! 👋\n\nSou a X88 IA, a sua assistente virtual. Como posso ajudar?`

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Chat Container */}
      <div className="relative w-full h-[85vh] sm:h-[600px] sm:max-w-md bg-white dark:bg-neutral-900 rounded-t-3xl sm:rounded-2xl flex flex-col overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden">
              <img src="/logos/logoAi.png" alt="IA" className="w-full h-full object-cover" />
            </div>
            <div>
              <h1 className="font-bold text-black dark:text-white">X88 IA</h1>
              <p className="text-xs text-neutral-500">Assistente Virtual</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {messages.length > 0 && (
              <button
                onClick={() => setShowClearConfirm(true)}
                className="p-2 text-neutral-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 rounded-lg transition-all"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 pb-6 space-y-4">
          {/* Welcome message */}
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
              <img src="/logos/logoAi.png" alt="IA" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
              <div className="bg-neutral-100 dark:bg-neutral-800 rounded-2xl rounded-tl-md p-4">
                <p className="text-black dark:text-white whitespace-pre-wrap text-sm">{welcomeMessage}</p>
              </div>
            </div>
          </div>

          {/* Chat messages */}
          {messages.filter(m => !m.isLoading).map((message, index) => (
            <div
              key={index}
              className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : ''}`}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                  <img src="/logos/logoAi.png" alt="IA" className="w-full h-full object-cover" />
                </div>
              )}
              <div className={`flex-1 ${message.role === 'user' ? 'flex justify-end' : ''}`}>
                <div
                  className={`rounded-2xl p-4 max-w-[85%] ${
                    message.role === 'user'
                      ? 'bg-[#00d749] text-white rounded-tr-md'
                      : 'bg-neutral-100 dark:bg-neutral-800 rounded-tl-md'
                  }`}
                >
                  <div className={`whitespace-pre-wrap text-sm ${message.role === 'user' ? 'text-white' : 'text-black dark:text-white'}`}>
                    {message.role === 'assistant' 
                      ? parseMessageWithButtons(message.content, navigate, onClose)
                      : message.content
                    }
                  </div>
                  <p className={`text-xs mt-2 ${message.role === 'user' ? 'text-white/70' : 'text-neutral-400'}`}>
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            </div>
          ))}

          {/* Loading */}
          {isLoading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                <img src="/logos/logoAi.png" alt="IA" className="w-full h-full object-cover" />
              </div>
              <div className="bg-neutral-100 dark:bg-neutral-800 rounded-2xl rounded-tl-md p-4">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-[#00d749] rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                    <span className="w-2 h-2 bg-[#00d749] rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                    <span className="w-2 h-2 bg-[#00d749] rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                  </div>
                  <span className="text-neutral-500 text-sm">Digitando...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} className="h-4" />
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onFocus={() => {
                setTimeout(() => {
                  messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
                }, 300)
              }}
              placeholder={isLoading ? "IA está digitando, aguarde..." : "Digite sua mensagem..."}
              className="flex-1 px-4 py-3 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-black dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#00d749] text-sm"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isLoading}
              className="px-4 py-3 bg-[#00d749] text-white rounded-xl hover:bg-[#00c142] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </form>

        {/* Clear Confirm Modal */}
        {showClearConfirm && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white dark:bg-neutral-800 rounded-2xl p-6 max-w-sm w-full">
              <h3 className="text-lg font-bold text-black dark:text-white mb-2">Limpar conversa?</h3>
              <p className="text-neutral-500 mb-4 text-sm">Todas as mensagens serão apagadas.</p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="flex-1 py-2 border border-neutral-300 dark:border-neutral-700 rounded-xl text-black dark:text-white font-medium"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleClear}
                  className="flex-1 py-2 bg-red-500 text-white rounded-xl font-medium"
                >
                  Limpar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
