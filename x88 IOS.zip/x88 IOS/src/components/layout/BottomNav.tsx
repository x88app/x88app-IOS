import { Home, FileText, Sparkles, BarChart3, User } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import { useState, useEffect, useRef } from 'react'
import { NewRequestModal } from '../NewRequestModal'
import { useLanguage } from '../../contexts/LanguageContext'

const BottomNav = () => {
  const location = useLocation()
  const { t } = useLanguage()
  const [isNewRequestModalOpen, setIsNewRequestModalOpen] = useState(false)
  const [isHidden, setIsHidden] = useState(false)
  const [barHeight, setBarHeight] = useState(80)
  const barRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (barRef.current) {
      setBarHeight(barRef.current.offsetHeight)
    }
  }, [])

  useEffect(() => {
    let lastTouchY = 0
    let lastKnownScrollY = 0
    
    const getScrollElement = () => {
      return document.getElementById('main-scroll')
    }

    const handleTouchStart = (e: TouchEvent) => {
      lastTouchY = e.touches[0].clientY
      const scrollEl = getScrollElement()
      lastKnownScrollY = scrollEl?.scrollTop || 0
    }

    const handleTouchMove = (e: TouchEvent) => {
      const currentTouchY = e.touches[0].clientY
      const touchDiff = lastTouchY - currentTouchY // positivo = rolando pra baixo
      const scrollEl = getScrollElement()
      const currentScrollY = scrollEl?.scrollTop || 0

      if (currentScrollY <= 10) {
        setIsHidden(false)
      } else if (touchDiff > 8) {
        // Rolando pra baixo - esconde
        setIsHidden(true)
      } else if (touchDiff < -8) {
        // Rolando pra cima - mostra
        setIsHidden(false)
      }

      lastTouchY = currentTouchY
    }

    const handleWheel = (e: WheelEvent) => {
      const scrollEl = getScrollElement()
      const currentScrollY = scrollEl?.scrollTop || 0

      if (currentScrollY <= 10) {
        setIsHidden(false)
      } else if (e.deltaY > 0) {
        // Rolando pra baixo - esconde
        setIsHidden(true)
      } else if (e.deltaY < 0) {
        // Rolando pra cima - mostra
        setIsHidden(false)
      }
    }

    const handleScroll = () => {
      const scrollEl = getScrollElement()
      const currentScrollY = scrollEl?.scrollTop || 0
      const diff = currentScrollY - lastKnownScrollY

      if (currentScrollY <= 10) {
        setIsHidden(false)
      } else if (diff > 10) {
        setIsHidden(true)
      } else if (diff < -10) {
        setIsHidden(false)
      }

      lastKnownScrollY = currentScrollY
    }

    const scrollEl = getScrollElement()

    document.addEventListener('touchstart', handleTouchStart, { passive: true })
    document.addEventListener('touchmove', handleTouchMove, { passive: true })
    document.addEventListener('wheel', handleWheel, { passive: true })
    
    if (scrollEl) {
      scrollEl.addEventListener('scroll', handleScroll, { passive: true })
    }

    return () => {
      document.removeEventListener('touchstart', handleTouchStart)
      document.removeEventListener('touchmove', handleTouchMove)
      document.removeEventListener('wheel', handleWheel)
      if (scrollEl) {
        scrollEl.removeEventListener('scroll', handleScroll)
      }
    }
  }, [])

  const navItems = [
    { icon: Home, label: t('menu.home'), path: '/' },
    { icon: FileText, label: t('menu.solicitacoes'), path: '/requests' },
    { icon: Sparkles, label: t('menu.nova'), path: '/requests/new', highlight: true },
    { icon: BarChart3, label: t('menu.historico'), path: '/reports' },
    { icon: User, label: t('menu.perfil'), path: '/profile' },
  ]

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === path
    return location.pathname.startsWith(path)
  }

  return (
    <>
      <div
        ref={barRef}
        style={{
          position: 'fixed',
          left: 0,
          right: 0,
          bottom: 24,
          height: barHeight,
          zIndex: 9999,
          display: 'flex',
          alignItems: 'flex-start',
          justifyContent: 'center',
          paddingTop: 8,
          paddingLeft: 16,
          paddingRight: 16,
          background: 'transparent',
          pointerEvents: 'none',
          opacity: isHidden ? 0 : 1,
          transition: 'opacity 0.5s ease-in-out',
          WebkitTransition: 'opacity 0.5s ease-in-out',
          willChange: 'opacity'
        }}
      >
        <div
          style={{
            width: '100%',
            maxWidth: 480,
            height: 64,
            borderRadius: 28,
            boxShadow: '0 -4px 30px rgba(0,0,0,0.15)',
            display: 'grid',
            gridTemplateColumns: 'repeat(5, 1fr)',
            alignItems: 'flex-end',
            padding: '0 8px',
            pointerEvents: 'auto'
          }}
          className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800"
        >
          {navItems.map((item) => {
            const Icon = item.icon
            const active = isActive(item.path)

            if (item.highlight) {
              return (
                <button
                  key={item.path}
                  onClick={() => setIsNewRequestModalOpen(true)}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'flex-end',
                    position: 'relative',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    paddingBottom: 8
                  }}
                >
                  <div
                    style={{
                      width: 56,
                      height: 56,
                      borderRadius: '50%',
                      backgroundColor: '#00d749',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: '0 4px 15px rgba(0,215,73,0.4)',
                      marginTop: -32,
                      marginBottom: 4
                    }}
                  >
                    <Icon style={{ width: 28, height: 28, color: 'white' }} strokeWidth={2.5} />
                  </div>
                  <span style={{ fontSize: 10, fontWeight: 500, color: '#00d749' }}>
                    {item.label}
                  </span>
                </button>
              )
            }

            return (
              <Link
                key={item.path}
                to={item.path}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '8px 0',
                  textDecoration: 'none',
                  color: active ? '#00d749' : '#737373'
                }}
              >
                <Icon style={{ width: 24, height: 24 }} strokeWidth={active ? 2.5 : 2} />
                <span style={{ fontSize: 10, marginTop: 4, fontWeight: active ? 600 : 500 }}>
                  {item.label}
                </span>
              </Link>
            )
          })}
        </div>
      </div>

      <NewRequestModal 
        isOpen={isNewRequestModalOpen} 
        onClose={() => setIsNewRequestModalOpen(false)} 
      />
    </>
  )
}

export default BottomNav
