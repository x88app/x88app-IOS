import React from 'react';
import { useToast } from '../../contexts/ToastContext';
import Toast from '../ui/Toast';

const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useToast();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-0 right-0 z-[9999] flex flex-col gap-2">
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          id={toast.id}
          message={toast.message}
          type={toast.type}
          duration={toast.duration || 5000}
          onClose={removeToast}
        />
      ))}
    </div>
  );
};

export default ToastContainer;
