import { X, AlertTriangle } from 'lucide-react'

interface ConfirmCancelModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
}

const ConfirmCancelModal = ({ isOpen, onClose, onConfirm }: ConfirmCancelModalProps) => {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm" 
        onClick={onClose}
      />
      
      <div className="relative bg-white dark:bg-neutral-900 rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-neutral-200 dark:border-neutral-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
        >
          <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
        </button>

        <div className="text-center space-y-3">
          <div className="w-16 h-16 mx-auto rounded-full bg-amber-100 dark:bg-amber-950/30 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-amber-600 dark:text-amber-500" />
          </div>

          <h2 className="text-2xl font-bold text-black dark:text-white">
            Cancelar Solicitação?
          </h2>

          <p className="text-neutral-600 dark:text-neutral-400">
            Tem certeza que deseja cancelar esta solicitação? Esta ação não pode ser desfeita.
          </p>
        </div>

        <div className="flex gap-3 pt-2">
          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 rounded-2xl font-semibold bg-neutral-100 dark:bg-neutral-800 text-black dark:text-white hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
          >
            Voltar
          </button>
          
          <button
            onClick={onConfirm}
            className="flex-1 py-3 px-4 rounded-2xl font-semibold bg-red-600 text-white hover:bg-red-700 transition-colors"
          >
            Sim, Cancelar
          </button>
        </div>
      </div>
    </div>
  )
}

export default ConfirmCancelModal
