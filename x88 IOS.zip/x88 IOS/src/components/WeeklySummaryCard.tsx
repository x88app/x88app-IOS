import { Euro, CheckCircle } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'

type WeeklySummaryProps = {
  euroTotal: number
  satsTotal: number
  euroNetTotal: number
  satsNetTotal: number
  euroCount: number
  satsCount: number
}

const getNextMondayFormatted = () => {
  const today = new Date()
  const dayOfWeek = today.getDay()
  // Se hoje é segunda (1), vai para a próxima segunda
  const daysUntilMonday = dayOfWeek === 0 ? 1 : dayOfWeek === 1 ? 7 : (8 - dayOfWeek)
  const nextMonday = new Date(today)
  nextMonday.setDate(today.getDate() + daysUntilMonday)
  
  // Formato: "Segunda-feira, 16/12"
  const dayName = 'Segunda-feira'
  const dateStr = nextMonday.toLocaleDateString('pt-PT', { day: '2-digit', month: '2-digit' })
  
  return { dayName, dateStr, full: `${dayName}, ${dateStr}` }
}

export const WeeklySummaryCard = ({
  euroTotal = 0,
  satsTotal = 0,
  euroNetTotal = 0,
  satsNetTotal = 0,
  euroCount = 0,
  satsCount = 0,
}: WeeklySummaryProps) => {
  const { currencySymbol, language, formatCurrency } = useLanguage()
  const isBR = language === 'pt-BR'
  const nextMonday = getNextMondayFormatted()
  
  const hasEuroPending = euroTotal > 0
  const hasSatsPending = satsTotal > 0
  const hasAnyPending = hasEuroPending || hasSatsPending
  
  // Se não tem nenhum valor pendente, mostra mensagem de "tudo em dia"
  if (!hasAnyPending) {
    return (
      <div className="space-y-3">
        <p className="text-[11px] uppercase tracking-wider text-neutral-500 dark:text-neutral-400 font-semibold px-1">
          RESUMO
        </p>

        <div className="bg-white dark:bg-neutral-900 rounded-2xl p-6 border border-green-200 dark:border-green-800">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center flex-shrink-0">
              <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-lg font-semibold text-green-700 dark:text-green-400">
                Tudo em dia!
              </p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Não há valores pendentes de desconto.
                <br />
                Solicite agora mesmo um novo adiantamento.
              </p>
            </div>
          </div>
        </div>
      </div>
    )
  }
  
  return (
    <div className="space-y-3">
      <p className="text-[11px] uppercase tracking-wider text-neutral-500 dark:text-neutral-400 font-semibold px-1">
        VALORES PENDENTES
      </p>

      {hasEuroPending && (
        <div className="bg-white dark:bg-neutral-900 rounded-2xl p-5 border-2 border-[#00d749]">
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-3">
            Valor Recebido
          </p>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl font-bold text-[#00d749] tabular-nums mb-1">
                {formatCurrency(euroTotal)}
              </p>
              <p className="text-xs text-red-500 font-medium">
                A descontar do salário: {formatCurrency(euroNetTotal)}
              </p>
              <p className="text-xs text-red-500 font-medium mb-1">
                em {nextMonday.full}
              </p>
              <p className="text-xs text-neutral-400 dark:text-neutral-500">
                {euroCount} {euroCount === 1 ? 'solicitação' : 'solicitações'}
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[#00d749]/10 flex items-center justify-center flex-shrink-0">
              {isBR ? (
                <span className="text-lg font-bold text-[#00d749]">{currencySymbol}</span>
              ) : (
                <Euro className="w-6 h-6 text-[#00d749]" />
              )}
            </div>
          </div>
        </div>
      )}

      {hasSatsPending && (
        <div className="bg-white dark:bg-neutral-900 rounded-2xl p-5 border-2 border-[#E69F39]">
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-3">
            Satoshis
          </p>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl font-bold text-[#E69F39] tabular-nums mb-1">
                {Math.round(satsTotal).toLocaleString('pt-PT')}
              </p>
              <p className="text-xs text-red-500 font-medium">
                A descontar do salário: {Math.round(satsNetTotal).toLocaleString('pt-PT')} sats
              </p>
              <p className="text-xs text-red-500 font-medium mb-1">
                em {nextMonday.full}
              </p>
              <p className="text-xs text-neutral-400 dark:text-neutral-500">
                {satsCount} {satsCount === 1 ? 'solicitação' : 'solicitações'}
              </p>
            </div>
            <div className="w-10 h-10 rounded-lg bg-[#E69F39]/10 flex items-center justify-center flex-shrink-0">
              <img 
                src="/logos/BITCOIN.png" 
                alt="Bitcoin"
                className="w-6 h-6"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
