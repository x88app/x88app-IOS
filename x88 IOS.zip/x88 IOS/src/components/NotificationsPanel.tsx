import { X, CheckCircle, AlertCircle, Info, Bell, Trash2 } from 'lucide-react'
import { useNotifications } from '../contexts/NotificationsContext'
import { useLanguage } from '../contexts/LanguageContext'
import { createPortal } from 'react-dom'
import { useState, useEffect } from 'react'

interface NotificationsPanelProps {
  isOpen: boolean
  onClose: () => void
  bellPosition: { x: number; y: number }
}

export const NotificationsPanel = ({ isOpen, onClose, bellPosition }: NotificationsPanelProps) => {
  const { notifications, unreadCount, markAsRead, markAllAsRead, clearAll } = useNotifications()
  const { formatDate, formatMessage } = useLanguage()
  const [isAnimating, setIsAnimating] = useState(false)
  const [shouldRender, setShouldRender] = useState(false)

  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout>

    if (isOpen) {
      setShouldRender(true)
      // Pequeno delay para permitir que o React renderize o componente antes da animação
      timeoutId = setTimeout(() => setIsAnimating(true), 50)
    } else {
      setIsAnimating(false)
      // Aguarda a animação de saída terminar antes de remover do DOM
      timeoutId = setTimeout(() => setShouldRender(false), 700)
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId)
    }
  }, [isOpen])

  if (!shouldRender) return null

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-[#00d749]" />
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-600" />
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-amber-500" />
      default:
        return <Info className="w-5 h-5 text-blue-500" />
    }
  }

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return 'Agora mesmo'
    if (diffMins < 60) return `Há ${diffMins} min`
    if (diffHours < 24) return `Há ${diffHours}h`
    if (diffDays === 1) return 'Ontem'
    return formatDate(date, { day: '2-digit', month: '2-digit' })
  }

  const panelContent = (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-[9998] transition-opacity duration-700 ${
          isAnimating ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Panel - Popup style from bell */}
      <div 
        style={{
          transformOrigin: isAnimating ? 'center top' : `${bellPosition.x}px ${bellPosition.y}px`,
        }}
        className={`fixed top-20 left-1/2 -translate-x-1/2 w-[420px] max-w-[90vw] max-h-[70vh] bg-white dark:bg-neutral-900 shadow-2xl rounded-2xl z-[9999] flex flex-col transition-all duration-700 ease-in-out ${
          isAnimating 
            ? 'opacity-100 scale-100' 
            : 'opacity-0 scale-0 pointer-events-none'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#00d749]" />
            <h2 className="text-lg font-bold text-black dark:text-white">
              Notificações
            </h2>
            {unreadCount > 0 && (
              <span className="bg-[#00d749] text-white text-xs font-bold px-2 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
          </button>
        </div>

        {/* Actions */}
        {notifications.length > 0 && (
          <div className="flex gap-2 p-3 border-b border-neutral-200 dark:border-neutral-800">
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="text-xs text-[#00d749] font-medium hover:underline"
              >
                Marcar todas como lidas
              </button>
            )}
            <button
              onClick={clearAll}
              className="text-xs text-red-600 font-medium hover:underline ml-auto flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              Limpar tudo
            </button>
          </div>
        )}

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <Bell className="w-16 h-16 text-neutral-300 dark:text-neutral-700 mb-4" />
              <h3 className="text-lg font-bold text-black dark:text-white mb-2">
                Nenhuma notificação
              </h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Você não tem notificações no momento
              </p>
            </div>
          ) : (
            <div className="p-3 space-y-3">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  onClick={() => markAsRead(notification.id)}
                  className={`rounded-xl border-2 p-4 cursor-pointer transition-all ${
                    notification.read
                      ? 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800'
                      : 'bg-[#00d749]/5 dark:bg-[#00d749]/10 border-[#00d749]/30 hover:border-[#00d749]/50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-0.5">{getIcon(notification.type)}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <h4 className="font-bold text-black dark:text-white text-base">
                          {notification.title}
                        </h4>
                        {!notification.read && (
                          <div className="w-2.5 h-2.5 bg-[#00d749] rounded-full flex-shrink-0 animate-pulse" />
                        )}
                      </div>
                      <p className="text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed mb-3">
                        {formatMessage(notification.message)}
                      </p>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-px bg-neutral-200 dark:bg-neutral-800"></div>
                        <p className="text-xs text-neutral-500 dark:text-neutral-500 font-medium">
                          {formatTime(notification.timestamp)}
                        </p>
                        <div className="flex-1 h-px bg-neutral-200 dark:bg-neutral-800"></div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  )

  return createPortal(panelContent, document.body)
}
