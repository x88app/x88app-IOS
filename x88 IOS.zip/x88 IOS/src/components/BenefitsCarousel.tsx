import { useState, useEffect } from 'react'
import { Sparkles, Zap, Shield, Star, Heart, Gift, Award, TrendingUp, Target, Clock, Wallet, Euro, LucideIcon } from 'lucide-react'
import { supabase } from '../lib/supabase'

interface CardBeneficio {
  id: string
  titulo: string
  descricao: string
  icone: string
  cor: string
  ordem: number
  ativo: boolean
}

const defaultCards = [
  {
    id: '1',
    titulo: 'Benefícios',
    descricao: 'Receba adiantamentos de forma rápida e segura',
    icone: 'Sparkles',
    cor: 'green',
    ordem: 1,
    ativo: true,
  },
  {
    id: '2',
    titulo: 'O que você pode fazer',
    descricao: 'Solicite em Euro ou Satoshi com aprovação instantânea',
    icone: 'Zap',
    cor: 'orange',
    ordem: 2,
    ativo: true,
  },
  {
    id: '3',
    titulo: 'Segurança',
    descricao: 'Transações protegidas e criptografadas',
    icone: 'Shield',
    cor: 'green',
    ordem: 3,
    ativo: true,
  },
]

const iconMap: Record<string, LucideIcon> = {
  Sparkles,
  Zap,
  Shield,
  Star,
  Heart,
  Gift,
  Award,
  TrendingUp,
  Target,
  Clock,
  Wallet,
  Euro,
}

const colorMap: Record<string, { border: string; iconBg: string; iconColor: string }> = {
  green: {
    border: 'border-[#00d749]/20',
    iconBg: 'bg-[#00d749]/10',
    iconColor: 'text-[#00d749]',
  },
  orange: {
    border: 'border-[#E69F39]/20',
    iconBg: 'bg-[#E69F39]/10',
    iconColor: 'text-[#E69F39]',
  },
  blue: {
    border: 'border-[#3B82F6]/20',
    iconBg: 'bg-[#3B82F6]/10',
    iconColor: 'text-[#3B82F6]',
  },
  purple: {
    border: 'border-[#8B5CF6]/20',
    iconBg: 'bg-[#8B5CF6]/10',
    iconColor: 'text-[#8B5CF6]',
  },
  red: {
    border: 'border-[#EF4444]/20',
    iconBg: 'bg-[#EF4444]/10',
    iconColor: 'text-[#EF4444]',
  },
  pink: {
    border: 'border-[#EC4899]/20',
    iconBg: 'bg-[#EC4899]/10',
    iconColor: 'text-[#EC4899]',
  },
}

export const BenefitsCarousel = () => {
  const [cards, setCards] = useState<CardBeneficio[]>(defaultCards)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [touchStart, setTouchStart] = useState(0)
  const [touchEnd, setTouchEnd] = useState(0)

  useEffect(() => {
    const fetchCards = async () => {
      try {
        const { data, error } = await supabase
          .from('cards_beneficios')
          .select('*')
          .eq('ativo', true)
          .order('ordem', { ascending: true })
        
        if (error) throw error
        if (data && data.length > 0) {
          setCards(data)
        }
      } catch (error) {
        console.error('Error fetching cards beneficios:', error)
      }
    }

    fetchCards()

    const channel = supabase
      .channel('cards_beneficios_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'cards_beneficios' }, () => {
        fetchCards()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  useEffect(() => {
    if (cards.length === 0) return
    
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % cards.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [cards.length])

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return
    
    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % cards.length)
    }
    if (isRightSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex - 1 + cards.length) % cards.length)
    }

    setTouchStart(0)
    setTouchEnd(0)
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setTouchStart(e.clientX)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (touchStart) {
      setTouchEnd(e.clientX)
    }
  }

  const handleMouseUp = () => {
    if (!touchStart || !touchEnd) return
    
    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % cards.length)
    }
    if (isRightSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex - 1 + cards.length) % cards.length)
    }

    setTouchStart(0)
    setTouchEnd(0)
  }

  if (cards.length === 0) return null

  return (
    <div className="relative overflow-hidden">
      <div 
        className="relative h-40 cursor-grab active:cursor-grabbing"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {cards.map((card, index) => {
          const Icon = iconMap[card.icone] || Sparkles
          const colors = colorMap[card.cor] || colorMap.green
          const isActive = index === currentIndex
          const isPrev = index === (currentIndex - 1 + cards.length) % cards.length
          const isNext = index === (currentIndex + 1) % cards.length

          let positionClass = 'translate-x-[120%] opacity-0'
          if (isActive) positionClass = 'translate-x-0 opacity-100 scale-100'
          else if (isPrev) positionClass = '-translate-x-[120%] opacity-0'
          else if (isNext) positionClass = 'translate-x-[120%] opacity-0'

          return (
            <div
              key={card.id}
              className={`absolute inset-0 transition-all duration-700 ease-in-out ${positionClass}`}
            >
              <div className={`bg-white dark:bg-neutral-900 ${colors.border} border-2 rounded-2xl p-6 h-full shadow-sm`}>
                <div className="flex items-start gap-4">
                  <div className={`${colors.iconBg} p-3 rounded-xl`}>
                    <Icon className={`w-6 h-6 ${colors.iconColor}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-black dark:text-white mb-2">{card.titulo}</h3>
                    <p className="text-neutral-600 dark:text-neutral-400 text-sm leading-relaxed">
                      {card.descricao}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="flex justify-center gap-2 mt-4">
        {cards.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-2 rounded-full transition-all duration-300 ${
              index === currentIndex ? 'w-8 bg-[#00d749]' : 'w-2 bg-neutral-300 dark:bg-neutral-700'
            }`}
            aria-label={`Ir para card ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
