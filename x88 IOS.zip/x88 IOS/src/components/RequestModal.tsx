import { X, XCircle, CheckCircle, Euro } from 'lucide-react'
import { useEffect } from 'react'
import { createPortal } from 'react-dom'
import { useLanguage } from '../contexts/LanguageContext'
import { formatNextMondayDate } from '../lib/dateUtils'
import { useConfiguracoesGlobais } from '../hooks/useConfiguracoesGlobais'

interface Request {
  id: string
  amount: number
  netAmount: number
  status: string
  paymentMethod: string
  date: string
  currency?: string
  descontado?: boolean
}

interface RequestModalProps {
  request: Request
  onClose: () => void
}

export const RequestModal = ({ request, onClose }: RequestModalProps) => {
  const { formatCurrency, currencySymbol, language } = useLanguage()
  const isBR = language === 'pt-BR'
  const { config, handleContactWhatsapp } = useConfiguracoesGlobais()

  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [])

  const isSats = request.currency === 'SATS'
  const color = isSats ? '#E69F39' : '#00d749'
  const formatValue = (value: number) => isSats ? `${Math.round(value)} sats` : formatCurrency(value)

  const getMethodLabel = (method: string) => {
    const m = method.toLowerCase()
    if (m === 'mbway') return isBR ? 'PIX' : 'MB WAY'
    if (m === 'iban') return isBR ? 'CONTA BANCÁRIA' : 'IBAN'
    return method.toUpperCase()
  }

  const renderModalContent = () => {
    const upperStatus = request.status.toUpperCase()

    if (upperStatus === 'REJECTED') {
      return (
        <div className="text-center">
          <div className="mb-6">
            <div className="mx-auto w-20 h-20 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mb-4">
              <XCircle className="w-12 h-12 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-red-600 mb-2">Solicitação Negada</h2>
            <p className="text-neutral-600 dark:text-neutral-400">
              Sua solicitação não foi aprovada desta vez
            </p>
          </div>

          <div className="bg-neutral-50 dark:bg-neutral-800 rounded-xl p-6 space-y-4 text-left">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Valor Solicitado:</span>
              <span className="text-xl font-bold text-red-600">{formatValue(request.amount)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Método de Pagamento:</span>
              <span className="font-semibold text-black dark:text-white">{getMethodLabel(request.paymentMethod)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Data da Solicitação:</span>
              <span className="font-semibold text-black dark:text-white">
                {new Date(request.date).toLocaleDateString('pt-PT')}
              </span>
            </div>
          </div>

          <div className="mt-6 p-4 bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800 rounded-xl">
            <p className="text-sm text-red-700 dark:text-red-500">
              <strong>Motivo:</strong> Sua solicitação foi analisada e não atendeu aos critérios necessários para aprovação. 
              Entre em contato com o suporte para mais informações.
            </p>
          </div>

          {config.whatsapp_suporte && (
            <button
              onClick={handleContactWhatsapp}
              className="w-full mt-4 py-3 bg-[#25D366] text-white font-semibold rounded-xl hover:bg-[#20BD5A] transition-colors flex items-center justify-center gap-2"
            >
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
                alt="WhatsApp" 
                className="w-5 h-5"
              />
              Falar com Suporte
            </button>
          )}
        </div>
      )
    }

    if (upperStatus === 'APPROVED') {
      return (
        <div className="text-center">
          <div className="mb-6">
            <div className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: `${color}20` }}>
              <CheckCircle className="w-12 h-12" style={{ color }} />
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ color }}>Solicitação Aprovada</h2>
            <p className="text-neutral-600 dark:text-neutral-400">
              Sua solicitação foi aprovada com sucesso
            </p>
          </div>

          <div className="bg-neutral-50 dark:bg-neutral-800 rounded-xl p-6 space-y-4 text-left">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Você receberá:</span>
              <span className="text-2xl font-bold" style={{ color }}>{formatValue(request.amount)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">A Descontar:</span>
              <span className="text-xl font-bold text-red-600">{formatValue(request.netAmount)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Método de Pagamento:</span>
              <span className="font-semibold text-black dark:text-white">{getMethodLabel(request.paymentMethod)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Data da Solicitação:</span>
              <span className="font-semibold text-black dark:text-white">
                {new Date(request.date).toLocaleDateString('pt-PT')}
              </span>
            </div>
          </div>

          <div className="mt-6 p-4 bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl">
            <p className="text-sm text-neutral-700 dark:text-neutral-300">
              O pagamento será processado em até 3 horas.
            </p>
          </div>
        </div>
      )
    }

    if (upperStatus === 'VERIFYING') {
      return (
        <div className="text-center">
          <div className="mb-6">
            <div className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: `${color}20` }}>
              {isSats ? (
                <img src="/logos/BITCOIN.png" alt="Bitcoin" className="w-12 h-12" />
              ) : (
                <CheckCircle className="w-12 h-12" style={{ color }} />
              )}
            </div>
            <h2 className="text-2xl font-bold text-[#E69F39] mb-2">Em Verificação</h2>
            <p className="text-neutral-600 dark:text-neutral-400">
              Aguardando confirmação do gestor
            </p>
          </div>

          <div className="bg-neutral-50 dark:bg-neutral-800 rounded-xl p-6 space-y-4 text-left">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Valor Recebido:</span>
              <span className="text-2xl font-bold text-[#E69F39]">{formatValue(request.amount)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Método de Pagamento:</span>
              <span className="font-semibold text-black dark:text-white">
                {request.paymentMethod === 'satoshi' ? 'SATOSHI' : getMethodLabel(request.paymentMethod)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Data da Solicitação:</span>
              <span className="font-semibold text-black dark:text-white">
                {new Date(request.date).toLocaleDateString('pt-PT')}
              </span>
            </div>
          </div>

          <div className="mt-6 p-4 bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-200 dark:border-yellow-800 rounded-xl">
            <p className="text-sm text-yellow-700 dark:text-yellow-500">
              O gestor precisa confirmar que a transação de Satoshi foi realizada. Você receberá uma notificação quando for confirmado.
            </p>
          </div>
        </div>
      )
    }

    if (upperStatus === 'PAID') {
      return (
        <div className="text-center">
          <div className="mb-6">
            <div className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: `${color}20` }}>
              <CheckCircle className="w-12 h-12" style={{ color }} />
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ color }}>Solicitação Paga</h2>
            <p className="text-neutral-600 dark:text-neutral-400">
              O valor foi transferido para sua conta
            </p>
          </div>

          <div className="bg-neutral-50 dark:bg-neutral-800 rounded-xl p-6 space-y-4 text-left">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Valor Recebido:</span>
              <span className="text-2xl font-bold" style={{ color }}>{formatValue(request.amount)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">
                {request.descontado ? 'Valor descontado do salário:' : 'A descontar do salário:'}
              </span>
              <span className={`text-xl font-bold ${request.descontado ? 'text-green-600' : 'text-red-600'}`}>
                {formatValue(request.netAmount)}
              </span>
            </div>
            {!request.descontado && (
              <div className="flex items-center justify-between">
                <span className="text-neutral-600 dark:text-neutral-400">Data do desconto:</span>
                <span className="font-semibold text-black dark:text-white">{formatNextMondayDate(new Date(request.date))}</span>
              </div>
            )}
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Método de Pagamento:</span>
              <span className="font-semibold text-black dark:text-white">{getMethodLabel(request.paymentMethod)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-400">Data da Solicitação:</span>
              <span className="font-semibold text-black dark:text-white">
                {new Date(request.date).toLocaleDateString('pt-PT')}
              </span>
            </div>
          </div>

          <div className="mt-6 p-4 bg-[#00d749]/10 border border-[#00d749]/30 rounded-xl">
          <p className="text-sm text-[#00d749] font-semibold">
              ✓ Valor transferido com sucesso para sua conta bancária
            </p>
          </div>
        </div>
      )
    }

    return (
    <div className="text-center">
    <div className="mb-6">
    <div className="mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: `${color}20` }}>
    {isSats ? (
        <img src="/logos/BITCOIN.png" alt="Bitcoin" className="w-12 h-12" />
              ) : (
                isBR ? (
                  <span className="text-2xl font-bold" style={{ color }}>R$</span>
                ) : (
                  <Euro className="w-12 h-12" style={{ color }} />
                )
              )}
            </div>
          <h2 className="text-2xl font-bold text-yellow-600 mb-2">Solicitação Pendente</h2>
          <p className="text-neutral-600 dark:text-neutral-400">
            Sua solicitação está sendo analisada
          </p>
        </div>

        <div className="bg-neutral-50 dark:bg-neutral-800 rounded-xl p-6 space-y-4 text-left">
          <div className="flex items-center justify-between">
          <span className="text-neutral-600 dark:text-neutral-400">Valor Solicitado:</span>
          <span className="text-xl font-bold text-yellow-600">{formatValue(request.amount)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-neutral-600 dark:text-neutral-400">Método de Pagamento:</span>
            <span className="font-semibold text-black dark:text-white">{request.paymentMethod.toUpperCase()}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-neutral-600 dark:text-neutral-400">Data da Solicitação:</span>
            <span className="font-semibold text-black dark:text-white">
              {new Date(request.date).toLocaleDateString('pt-PT')}
            </span>
          </div>
        </div>
      </div>
    )
  }

  const modalContent = (
    <div 
      className="fixed bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
      style={{ 
        zIndex: 99999,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        position: 'fixed',
        width: '100vw',
        height: '100vh',
        margin: 0,
        padding: '1rem'
      }}
      onClick={onClose}
    >
      <div 
        className="bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl max-w-md w-full p-6 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
        </button>

        {renderModalContent()}

        <button
          onClick={onClose}
          className="w-full mt-6 py-3 bg-neutral-900 dark:bg-neutral-700 text-white font-semibold rounded-xl hover:bg-neutral-800 dark:hover:bg-neutral-600 transition-colors"
        >
          Fechar
        </button>
      </div>
    </div>
  )

  return createPortal(modalContent, document.body)
}
