import { useState, useEffect, useRef } from 'react'
import { X, ExternalLink } from 'lucide-react'
import { supabase } from '../lib/supabase'

interface PopupBanner {
  id: string
  titulo: string
  imagem_url: string
  ativo: boolean
  tipo: string
  max_views?: number
  nome_botao?: string
  link_botao?: string
  usar_whatsapp?: boolean
}

export const AdsPopup = () => {
  const [banners, setBanners] = useState<PopupBanner[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isOpen, setIsOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [gestorPhone, setGestorPhone] = useState<string | null>(null)
  const viewCountedRef = useRef<Set<string>>(new Set())

  useEffect(() => {
    fetchBanners()
    fetchGestorPhone()

    // Inscreve para receber atualizações em tempo real da tabela banners
    const channel = supabase
      .channel('banners-popup-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'banners'
        },
        (payload) => {
          // Se houver qualquer mudança (novo banner, edição, inativação), recarrega
          console.log('Mudança detectada nos cards de anúncio:', payload)
          fetchBanners(true) // true = é atualização em tempo real
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  const fetchGestorPhone = async () => {
    try {
      // Buscar WhatsApp global das configurações
      const { data: configGlobal } = await supabase
        .from('configuracoes_globais')
        .select('whatsapp_suporte')
        .limit(1)
        .maybeSingle()

      if (configGlobal?.whatsapp_suporte) {
        setGestorPhone(configGlobal.whatsapp_suporte)
      }
    } catch (error) {
      console.error('Erro ao buscar WhatsApp global:', error)
    }
  }

  const handleButtonClick = (banner: PopupBanner) => {
    if (banner.usar_whatsapp && gestorPhone) {
      const cleanPhone = gestorPhone.replace(/\D/g, '')
      window.open(`https://wa.me/${cleanPhone}`, '_blank')
    } else if (banner.link_botao) {
      window.open(banner.link_botao, '_blank')
    }
  }

  const fetchBanners = async (isRealtimeUpdate = false) => {
    try {
      const { data, error } = await supabase
        .from('banners')
        .select('*')
        .eq('ativo', true)
        .eq('tipo', 'popup')
        .order('ordem', { ascending: true })
      
      if (error) throw error
      
      if (data && data.length > 0) {
        // Filtrar banners baseados no localStorage e max_views
        const validBanners = data.filter((banner: PopupBanner) => {
          if (!banner.max_views) return true // Se não tiver limite, mostra sempre
          
          // Lê o contador atual do localStorage
          const viewsKey = `x88_banner_view_${banner.id}`
          const currentViews = parseInt(localStorage.getItem(viewsKey) || '0')
          const maxViews = banner.max_views || 3
          
          return currentViews < maxViews
        })

        if (validBanners.length > 0) {
          // Verificar se há novos banners (para realtime)
          const currentBannerIds = banners.map(b => b.id)
          const hasNewBanners = validBanners.some(b => !currentBannerIds.includes(b.id))
          
          setBanners(validBanners)
          
          // Abrir popup se:
          // 1. É o carregamento inicial (não é realtime)
          // 2. Ou é realtime E há novos banners
          if (!isRealtimeUpdate || hasNewBanners) {
            setCurrentIndex(0)
            setIsOpen(true)
            console.log('Card de anúncio aberto!', isRealtimeUpdate ? '(novo banner em tempo real)' : '(inicial)')
          }
        }
      }
    } catch (error) {
      console.error('Erro ao buscar popups:', error)
    } finally {
      setLoading(false)
    }
  }

  // Efeito para registrar a visualização quando o banner atual muda ou abre
  useEffect(() => {
    if (isOpen && banners.length > 0) {
      const banner = banners[currentIndex]
      
      // Se já contamos para este banner nesta sessão do componente, ignora
      if (banner && !viewCountedRef.current.has(banner.id)) {
        const viewsKey = `x88_banner_view_${banner.id}`
        const lastViewKey = `x88_banner_last_view_${banner.id}`
        
        const now = Date.now()
        const lastViewTime = parseInt(localStorage.getItem(lastViewKey) || '0')
        
        // Previne contagem duplicada (React StrictMode ou re-renders rápidos)
        // Só conta se passou mais de 5 segundos desde a última vez registrada
        if (now - lastViewTime > 5000) {
          let currentViews = parseInt(localStorage.getItem(viewsKey) || '0')
          if (isNaN(currentViews)) currentViews = 0
          
          const newViews = currentViews + 1
          
          localStorage.setItem(viewsKey, newViews.toString())
          localStorage.setItem(lastViewKey, now.toString())
          
          // Marca como contado nesta instância de memória
          viewCountedRef.current.add(banner.id)
          
          console.log(`Banner ${banner.titulo} view counted: ${newViews}/${banner.max_views || 3}`)
        } else {
          console.log(`Banner ${banner.titulo} view ignored (debounce): ${now - lastViewTime}ms`)
        }
      }
    }
  }, [isOpen, currentIndex, banners])

  const handleClose = () => {
    if (currentIndex < banners.length - 1) {
      setCurrentIndex(prev => prev + 1)
    } else {
      setIsOpen(false)
    }
  }

  if (loading || !isOpen || banners.length === 0) return null

  const currentBanner = banners[currentIndex]

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center px-4">
      {/* Backdrop com blur */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity animate-in fade-in duration-300"
        onClick={handleClose}
      />
      
      {/* Container do Card */}
      <div className="relative w-full max-w-sm bg-transparent rounded-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300 mx-auto">
        {/* Botão Fechar */}
        <button 
          onClick={handleClose}
          className="absolute top-2 right-2 z-20 p-1.5 bg-black/40 hover:bg-black/60 text-white/90 rounded-full backdrop-blur-sm transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Imagem - Container flexível que se ajusta à altura da imagem */}
        <div className="w-full relative flex flex-col">
          <img 
            src={currentBanner.imagem_url} 
            alt={currentBanner.titulo}
            className="w-full h-auto object-contain block"
            loading="eager"
          />
          
          {/* Indicador de múltiplos banners */}
          {banners.length > 1 && (
             <div className={`absolute left-0 right-0 flex justify-center gap-2 z-10 ${currentBanner.nome_botao ? 'bottom-16' : 'bottom-4'}`}>
               {banners.map((_, idx) => (
                 <div 
                   key={idx} 
                   className={`w-2 h-2 rounded-full transition-all ${
                     idx === currentIndex ? 'bg-white w-4 shadow-sm' : 'bg-white/50'
                   }`}
                 />
               ))}
             </div>
          )}

          {/* Botão de ação */}
          {currentBanner.nome_botao && (
            <button
              onClick={() => handleButtonClick(currentBanner)}
              className="absolute bottom-3 left-3 right-3 py-3 px-4 bg-[#0FB841] hover:bg-[#0da838] text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg"
            >
              {currentBanner.usar_whatsapp ? (
                <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp" className="w-5 h-5" />
              ) : (
                <ExternalLink className="w-5 h-5" />
              )}
              {currentBanner.nome_botao}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
