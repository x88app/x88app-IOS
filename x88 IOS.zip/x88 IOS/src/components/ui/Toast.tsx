import React, { useEffect, useState } from 'react';
import { X, CheckCircle, AlertCircle, Bell } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

type ToastType = 'success' | 'error' | 'info';

interface ToastProps {
  id: string;
  message: string;
  type: ToastType;
  duration?: number;
  onClose: (id: string) => void;
}

const Toast: React.FC<ToastProps> = ({ id, message, type, duration = 5000, onClose }) => {
  const { formatMessage } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsVisible(true), 10);
    
    const timer = setTimeout(() => {
      setIsLeaving(true);
      setTimeout(() => onClose(id), 200);
    }, duration);
    
    return () => clearTimeout(timer);
  }, [id, duration, onClose]);

  const handleClose = () => {
    setIsLeaving(true);
    setTimeout(() => onClose(id), 200);
  };

  const getConfig = () => {
    switch (type) {
      case 'success':
        return {
          bg: 'bg-[#00d749]',
          icon: <CheckCircle className="w-4 h-4 text-white" />
        };
      case 'error':
        return {
          bg: 'bg-red-500',
          icon: <AlertCircle className="w-4 h-4 text-white" />
        };
      case 'info':
        return {
          bg: 'bg-neutral-800 dark:bg-neutral-700',
          icon: <Bell className="w-4 h-4 text-white" />
        };
    }
  };

  const config = getConfig();

  return (
    <div
      className={`
        ${config.bg}
        mx-4 px-4 py-3
        rounded-xl
        shadow-lg
        flex items-center gap-3
        transition-all duration-200 ease-out
        ${isVisible && !isLeaving 
          ? 'opacity-100 translate-y-0' 
          : 'opacity-0 -translate-y-2'}
      `}
      role="alert"
    >
      <div className="flex-shrink-0">
        {config.icon}
      </div>
      
      <p className="flex-1 text-sm text-white font-medium leading-tight">
        {formatMessage(message)}
      </p>
      
      <button
        onClick={handleClose}
        className="flex-shrink-0 p-1 rounded-lg hover:bg-white/20 transition-colors"
        aria-label="Fechar"
      >
        <X className="w-4 h-4 text-white/80" />
      </button>
    </div>
  );
};

export default Toast;
