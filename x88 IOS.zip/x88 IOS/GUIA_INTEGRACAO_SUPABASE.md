# 🚀 Guia de Integração com Supabase

## Passo 1: Obter Credenciais do Supabase

1. No painel do Supabase, vá em **Settings** (⚙️) → **API**
2. Copie estas informações:
   - **Project URL**: `https://[seu-projeto].supabase.co`
   - **anon public key**: Sua chave pública (começa com `eyJ...`)

---

## Passo 2: Instalar Dependências

Execute no terminal (na pasta raiz do projeto colaborador):

```bash
npm install @supabase/supabase-js
```

Execute no terminal (na pasta do gestor):

```bash
cd x88gestor
npm install @supabase/supabase-js
```

---

## Passo 3: Criar Arquivos de Configuração

Vou criar automaticamente os arquivos:
- `.env` (colaborador)
- `x88gestor/.env` (gestor)
- `src/lib/supabase.ts` (cliente Supabase - colaborador)
- `x88gestor/src/lib/supabase.ts` (cliente Supabase - gestor)

---

## Passo 4: Executar Seed (Dados Iniciais)

1. No Supabase, vá em **SQL Editor**
2. Clique em **New Query**
3. Copie todo o conteúdo de `supabase_seed.sql`
4. Cole e clique em **Run**

Isso criará:
- ✅ 1 Gestor
- ✅ 5 Colaboradores
- ✅ 8 Solicitações
- ✅ Notificações
- ✅ Carteira com saldo
- ✅ Banners e Cards

---

## Passo 5: Configurar Autenticação no Supabase

### Habilitar Email/Password Auth:

1. Vá em **Authentication** → **Providers**
2. Certifique-se que **Email** está habilitado
3. Desabilite **"Confirm email"** (para testes)
4. Salve

---

## Passo 6: Atualizar os Contexts

Vou atualizar automaticamente:
- `src/contexts/AuthContext.tsx` → Usar Supabase Auth
- `src/contexts/RequestsContext.tsx` → Buscar dados do Supabase
- `x88gestor/src/contexts/ColaboradoresContext.tsx` → Buscar do Supabase
- `x88gestor/src/contexts/RequestsGestorContext.tsx` → Buscar do Supabase

---

## Passo 7: Testar

### Credenciais de Teste (criadas pelo seed):

**GESTOR:**
- Email: `gestor@x88.pt`
- Senha: Você escolhe ao executar o seed modificado

**COLABORADOR:**
- Email: `joao.silva@x88.pt`
- Senha: Você escolhe ao executar o seed modificado

---

## 🎯 Próximos Passos

Após eu criar os arquivos:

1. ✅ Verificar se as dependências foram instaladas
2. ✅ Adicionar suas credenciais do Supabase no `.env`
3. ✅ Reiniciar os apps (npm run dev)
4. ✅ Fazer login e testar!

---

Pronto para começar? Vou criar os arquivos agora! 🚀
