-- =====================================================
-- MIGRATION: Storage para Fotos de Perfil (Avatares)
-- =====================================================

-- 1. Criar bucket para avatares
INSERT INTO storage.buckets (id, name, public) 
VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

-- 2. Política: Qualquer pessoa pode VER avatares (público)
CREATE POLICY "Avatares são públicos para visualização"
ON storage.objects FOR SELECT
USING ( bucket_id = 'avatars' );

-- 3. Política: Usuário autenticado pode fazer upload do seu próprio avatar
CREATE POLICY "Usuários podem fazer upload do próprio avatar"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'avatars' AND
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 4. Política: Usuário pode atualizar seu próprio avatar
CREATE POLICY "Usuários podem atualizar próprio avatar"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'avatars' AND
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 5. Política: Usuário pode deletar seu próprio avatar
CREATE POLICY "Usuários podem deletar próprio avatar"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'avatars' AND
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- NOTA: A estrutura de pastas será:
-- avatars/{user_id}/avatar.jpg
-- Isso garante que cada usuário só pode manipular arquivos na sua própria pasta
