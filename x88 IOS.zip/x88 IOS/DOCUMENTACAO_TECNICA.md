# 📱 X88 Motorista Parceiro - Documentação Técnica Completa

## Índice

1. [Visão Geral](#visão-geral)
2. [Arquitetura do Sistema](#arquitetura-do-sistema)
3. [Stack Tecnológico](#stack-tecnológico)
4. [Estrutura de Pastas](#estrutura-de-pastas)
5. [Contextos (State Management)](#contextos-state-management)
6. [Páginas e Rotas](#páginas-e-rotas)
7. [Componentes](#componentes)
8. [Hooks Customizados](#hooks-customizados)
9. [Integração com Supabase](#integração-com-supabase)
10. [Schema do Banco de Dados](#schema-do-banco-de-dados)
11. [Fluxos de Negócio](#fluxos-de-negócio)
12. [Internacionalização](#internacionalização)
13. [PWA e Capacitor](#pwa-e-capacitor)
14. [Guia de Desenvolvimento](#guia-de-desenvolvimento)

---

## Visão Geral

O **X88 Motorista Parceiro** é um aplicativo móvel (PWA + Capacitor) desenvolvido para motoristas parceiros (autônomos que rodam para Uber, Bolt e outras plataformas) solicitarem adiantamentos de forma rápida e eficiente.

### Principais Funcionalidades

| Funcionalidade | Descrição |
|----------------|-----------|
| **Dashboard** | Resumo de solicitações, banners promocionais e ações rápidas |
| **Adiantamentos** | Solicitar adiantamentos em EUR ou Satoshi (Bitcoin) |
| **Acompanhamento** | Visualizar status das solicitações em tempo real |
| **Carteira** | Ver saldo pendente de desconto e histórico |
| **Dados Bancários** | Gerenciar IBAN, MB Way e Lightning Address |
| **Perfil** | Dados pessoais, notificações, segurança e idioma |
| **Notificações** | Sistema de alertas em tempo real |

> **Público-alvo**: Motoristas autônomos que rodam para plataformas como Uber, Bolt, 99, etc.

### Design

- **Cores**: Preto, Verde (#22c55e / #00d749) e Branco
- **Fonte**: Inter
- **Estilo**: Moderno, mobile-first com bottom navigation
- **Tema**: Suporta modo claro e escuro

---

## Arquitetura do Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (React)                         │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │   Páginas   │  │ Componentes │  │   Modais    │              │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘              │
│         │                │                │                      │
│         └────────────────┼────────────────┘                      │
│                          ▼                                       │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                    CONTEXTOS (State)                       │  │
│  │  AuthContext │ RequestsContext │ NotificationsContext     │  │
│  │  LanguageContext │ ToastContext                           │  │
│  └───────────────────────────────────────────────────────────┘  │
│                          │                                       │
│                          ▼                                       │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │                   HOOKS CUSTOMIZADOS                       │  │
│  │  useWebPush │ useStatusBar │ useConfiguracoesGlobais      │  │
│  └───────────────────────────────────────────────────────────┘  │
│                          │                                       │
│                          ▼                                       │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │              SUPABASE CLIENT (lib/supabase.ts)            │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SUPABASE (Backend)                           │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │ PostgreSQL  │  │    Auth     │  │   Storage   │              │
│  │  (Banco)    │  │ (Supabase)  │  │  (Avatars)  │              │
│  └─────────────┘  └─────────────┘  └─────────────┘              │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │                    REALTIME                                  ││
│  │  Postgres Changes: solicitacoes, notificacoes, colaboradores││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

---

## Stack Tecnológico

### Frontend

| Tecnologia | Versão | Uso |
|------------|--------|-----|
| React | 18.2.0 | Framework UI |
| TypeScript | 5.0.2 | Tipagem estática |
| Vite | 4.4.5 | Build tool |
| Tailwind CSS | 3.3.2 | Estilização |
| React Router | 6.8.1 | Navegação |
| TanStack Query | 4.29.7 | Cache e estado do servidor |
| Lucide React | 0.263.1 | Ícones |

### Backend (Supabase)

| Serviço | Uso |
|---------|-----|
| Supabase Auth | Autenticação de usuários |
| Supabase Database | PostgreSQL com RLS |
| Supabase Storage | Upload de avatares e banners |
| Supabase Realtime | Atualizações em tempo real |

### Mobile

| Tecnologia | Versão | Uso |
|------------|--------|-----|
| Capacitor | 7.4.4 | Build nativo iOS/Android |
| vite-plugin-pwa | 0.16.4 | Progressive Web App |

---

## Estrutura de Pastas

```
colaborador/
├── public/
│   ├── icons/                    # Ícones PWA
│   ├── logos/                    # Logos (X88, Bitcoin)
│   └── manifest.webmanifest      # Manifesto PWA
│
├── src/
│   ├── components/
│   │   ├── auth/                 # Componentes de autenticação
│   │   │   └── PrivateRoute.tsx  # Proteção de rotas
│   │   ├── forms/                # Inputs especializados
│   │   ├── layout/               # Layout global
│   │   │   ├── Header.tsx        # Cabeçalho
│   │   │   ├── BottomNav.tsx     # Navegação inferior
│   │   │   └── ToastContainer.tsx
│   │   ├── ui/                   # Componentes UI base
│   │   │   ├── Toast.tsx
│   │   │   └── X88Logo.tsx
│   │   │
│   │   ├── ActiveRequestCard.tsx # Card de solicitação ativa
│   │   ├── AdsPopup.tsx          # Popup de anúncios
│   │   ├── BenefitsCarousel.tsx  # Carrossel de benefícios
│   │   ├── ConfirmCancelModal.tsx# Modal de cancelamento
│   │   ├── DatePicker.tsx        # Seletor de data
│   │   ├── FeedPanel.tsx         # Painel de comunicados
│   │   ├── ImageCarousel.tsx     # Carrossel de banners
│   │   ├── LoadingScreen.tsx     # Tela de carregamento
│   │   ├── NewRequestModal.tsx   # Modal nova solicitação
│   │   ├── NotificationsPanel.tsx# Painel de notificações
│   │   ├── RequestModal.tsx      # Detalhes da solicitação
│   │   ├── SatoshiModal.tsx      # Modal Bitcoin/Lightning
│   │   └── WeeklySummaryCard.tsx # Resumo semanal
│   │
│   ├── contexts/
│   │   ├── AuthContext.tsx       # Autenticação e usuário
│   │   ├── LanguageContext.tsx   # i18n (PT-BR/PT-PT)
│   │   ├── NotificationsContext.tsx # Notificações
│   │   ├── RequestsContext.tsx   # Solicitações
│   │   └── ToastContext.tsx      # Toasts/Alertas
│   │
│   ├── features/
│   │   ├── advances/             # Lógica de adiantamentos
│   │   └── bank/                 # Lógica bancária
│   │
│   ├── hooks/
│   │   ├── useConfiguracoesGlobais.ts # Configurações do sistema
│   │   ├── useFirebasePush.ts    # Push via Firebase
│   │   ├── useGestorEmail.ts     # Email do gestor
│   │   ├── useGestorPhone.ts     # Telefone do gestor
│   │   ├── useNativePush.ts      # Push nativo
│   │   ├── useOneSignal.ts       # OneSignal push
│   │   ├── useStatusBar.ts       # Status bar nativa
│   │   └── useWebPush.ts         # Web Push API
│   │
│   ├── i18n/
│   │   └── translations.ts       # Traduções PT-BR/PT-PT
│   │
│   ├── lib/
│   │   ├── dateUtils.ts          # Utilitários de data
│   │   ├── imageCache.ts         # Cache de imagens
│   │   └── supabase.ts           # Cliente Supabase
│   │
│   ├── pages/
│   │   ├── Auth/
│   │   │   ├── Login.tsx
│   │   │   ├── Register.tsx
│   │   │   ├── ForgotPassword.tsx
│   │   │   └── UpdatePassword.tsx
│   │   ├── Home/
│   │   │   └── Home.tsx          # Dashboard principal
│   │   ├── Legal/
│   │   │   ├── PrivacyPolicy.tsx
│   │   │   └── TermsOfUse.tsx
│   │   ├── Onboarding/           # Fluxo inicial
│   │   ├── Profile/
│   │   │   ├── Profile.tsx       # Menu do perfil
│   │   │   ├── PersonalData.tsx  # Dados pessoais
│   │   │   ├── BankDetails.tsx   # Dados bancários
│   │   │   ├── NotificationSettings.tsx
│   │   │   ├── PrivacySecurity.tsx
│   │   │   ├── LanguageRegion.tsx
│   │   │   └── Help.tsx
│   │   ├── Reports/
│   │   │   └── Reports.tsx       # Relatórios
│   │   ├── Requests/
│   │   │   ├── RequestsList.tsx  # Lista de solicitações
│   │   │   ├── NewRequest.tsx    # Nova solicitação (página)
│   │   │   └── RequestDetails.tsx# Detalhes
│   │   ├── Setup/
│   │   │   └── InitialSetup.tsx  # Configuração inicial
│   │   └── Wallet/
│   │       └── Wallet.tsx        # Carteira
│   │
│   ├── styles/                   # Estilos globais
│   ├── utils/
│   │   └── helpers.tsx           # Funções auxiliares
│   │
│   ├── App.tsx                   # Componente raiz
│   ├── main.tsx                  # Entry point
│   └── sw.js                     # Service Worker
│
├── android/                      # Projeto Android (Capacitor)
├── ios/                          # Projeto iOS (Capacitor)
│
├── capacitor.config.ts           # Configuração Capacitor
├── vite.config.ts                # Configuração Vite
├── tailwind.config.js            # Configuração Tailwind
├── tsconfig.json                 # Configuração TypeScript
└── package.json                  # Dependências
```

---

## Contextos (State Management)

### 1. AuthContext

Gerencia autenticação e dados do usuário.

```typescript
interface User {
  id: string
  name: string
  email: string
  phone: string
  nif: string
  interestRate: number                    // Taxa de juros individual
  status: 'ativo' | 'inativo' | 'pendente'
  avatarUrl: string | null
  bankDetails: {
    iban: string
    bankHolderName: string
    swiftBic: string
    mbwayPhone: string
    preferredMethod: string               // 'mbway' | 'iban' | 'satoshi'
    wallet: string                        // Lightning Address
  }
  preferences: {
    notifications: { email, push, sms, types, sound }
    security: { twoFactor, biometrics, loginNotify }
  }
}

// Funções disponíveis
- login(email, password)
- register(name, email, phone, nif, password)
- logout()
- updateBankDetails(bankDetails)
- updatePersonalData(data)
- updatePreferences(preferences)
- updatePassword(newPassword)
- updateAvatar(file)
```

**Recursos:**
- Monitora status em tempo real (desativa se `status = 'inativo'`)
- Refresh automático de token
- Pré-carregamento de banners após login

### 2. RequestsContext

Gerencia solicitações de adiantamento.

```typescript
interface Request {
  id: string
  amount: number
  paymentMethod: 'mbway' | 'iban' | 'satoshi'
  status: 'pending' | 'processing' | 'approved' | 'paid' | 'rejected' | 'verifying' | 'canceled'
  date: string
  netAmount: number                       // Valor a descontar (com juros)
  accountDetails?: string
  currency: 'EUR' | 'SATS'
  lightningAddress?: string
  paymentDate?: string
  descontado?: boolean                    // Se já foi descontado do salário
  dataDesconto?: string
}

// Funções disponíveis
- addRequest(request)
- getRequestById(id)
- getPendingRequests()
- getApprovedRequests()
- updateRequest(id, updates)
```

**Recursos:**
- Realtime via Supabase Postgres Changes
- Banners com cache (TanStack Query)
- Mapeamento de status PT → EN

### 3. NotificationsContext

Sistema de notificações em tempo real.

```typescript
interface Notification {
  id: string
  title: string
  message: string
  type: 'success' | 'info' | 'warning' | 'error'
  read: boolean
  timestamp: string
  requestId?: string
}

// Funções disponíveis
- addNotification(notification)
- markAsRead(id)
- markAllAsRead()
- clearAll()
- unreadCount                             // Contador de não lidas
```

### 4. LanguageContext

Internacionalização (PT-BR e PT-PT).

```typescript
// Funções disponíveis
- language: 'pt-BR' | 'pt-PT'
- timezone: 'America/Sao_Paulo' | 'Europe/Lisbon'
- setLanguage(lang)
- formatDate(date, options)
- formatTime(date)
- formatDateTime(date)
- formatCurrency(value)                   // R$ ou €
- formatMessage(message)                  // Adapta textos
- currencySymbol                          // 'R$' ou '€'
- t(key)                                  // Tradução
```

**Adaptações PT-BR:**
- MB Way → PIX
- IBAN → Conta Bancária
- € → R$

### 5. ToastContext

Sistema de alertas/toasts.

```typescript
- showToast(message, type)                // 'success' | 'error' | 'info' | 'warning'
```

---

## Páginas e Rotas

### Rotas Públicas (sem autenticação)

| Rota | Componente | Descrição |
|------|------------|-----------|
| `/auth/login` | Login | Tela de login |
| `/auth/register` | Register | Cadastro de novo usuário |
| `/auth/forgot-password` | ForgotPassword | Recuperação de senha |
| `/auth/update-password` | UpdatePassword | Atualização de senha |
| `/setup` | InitialSetup | Configuração inicial |
| `/legal/privacy` | PrivacyPolicy | Política de privacidade |
| `/legal/terms` | TermsOfUse | Termos de uso |

### Rotas Privadas (requer autenticação)

| Rota | Componente | Descrição |
|------|------------|-----------|
| `/` | Home | Dashboard principal |
| `/requests` | RequestsList | Lista de solicitações |
| `/requests/new` | NewRequest | Nova solicitação |
| `/requests/:id` | RequestDetails | Detalhes da solicitação |
| `/reports` | Reports | Relatórios e histórico |
| `/profile` | Profile | Menu do perfil |
| `/profile/personal` | PersonalData | Dados pessoais |
| `/profile/bank` | BankDetails | Dados bancários |
| `/profile/notifications` | NotificationSettings | Configurações de notificações |
| `/profile/security` | PrivacySecurity | Privacidade e segurança |
| `/profile/language` | LanguageRegion | Idioma e região |
| `/profile/help` | Help | Ajuda e suporte |

---

## Componentes

### Componentes de Layout

| Componente | Descrição |
|------------|-----------|
| `Header` | Cabeçalho com logo e botão voltar |
| `BottomNav` | Navegação inferior (5 tabs: Home, Requests, Reports, Wallet, Profile) |
| `ToastContainer` | Container de alertas toast |
| `LoadingScreen` | Tela de carregamento animada |

### Componentes de Negócio

| Componente | Descrição |
|------------|-----------|
| `ActiveRequestCard` | Card de solicitação em andamento com progress bar |
| `WeeklySummaryCard` | Resumo do valor pendente de desconto |
| `NewRequestModal` | Modal wizard de 2 passos para nova solicitação |
| `RequestModal` | Modal de detalhes da solicitação |
| `SatoshiModal` | Modal para receber Bitcoin via Lightning |
| `PendingSatoshiCard` | Card de confirmação Satoshi pendente |
| `NotificationsPanel` | Painel lateral de notificações |
| `FeedPanel` | Painel de comunicados |
| `BenefitsCarousel` | Carrossel horizontal de benefícios |
| `ImageCarousel` | Carrossel de banners promocionais |
| `AdsPopup` | Popup de anúncios (exibe apenas 1x) |

### Componentes Modais

| Componente | Descrição |
|------------|-----------|
| `ConfirmCancelModal` | Confirmação de cancelamento |
| `ConfirmLogoutModal` | Confirmação de logout |
| `DeleteAccountModal` | Exclusão de conta |
| `LogoutModal` | Modal de logout |

### Componentes de Formulário

| Componente | Descrição |
|------------|-----------|
| `DatePicker` | Seletor de data |
| `DateRangePicker` | Seletor de intervalo de datas |
| `FormattedDate` | Exibe data formatada conforme idioma |

---

## Hooks Customizados

| Hook | Descrição |
|------|-----------|
| `useConfiguracoesGlobais` | Busca configurações globais do sistema |
| `useWebPush` | Gerencia Web Push API |
| `useNativePush` | Push notifications via Capacitor |
| `useFirebasePush` | Push via Firebase Cloud Messaging |
| `useOneSignal` | Integração OneSignal |
| `useStatusBar` | Controle da status bar nativa |
| `useGestorEmail` | Busca email do gestor |
| `useGestorPhone` | Busca telefone do gestor |

---

## Integração com Supabase

### Configuração

```typescript
// src/lib/supabase.ts
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})
```

### Variáveis de Ambiente

```bash
# .env
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anon
```

### Realtime Subscriptions

O app utiliza Postgres Changes para atualizações em tempo real:

1. **Solicitações**: Atualiza lista quando há mudanças
2. **Notificações**: Adiciona novas notificações automaticamente
3. **Status do colaborador**: Monitora se foi desativado

```typescript
// Exemplo de subscription
supabase
  .channel('solicitacoes-changes')
  .on('postgres_changes', {
    event: '*',
    schema: 'public',
    table: 'solicitacoes'
  }, (payload) => {
    loadRequests()
  })
  .subscribe()
```

---

## Schema do Banco de Dados

### Tabelas Principais

#### `usuarios`
Dados básicos de todos os usuários.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| id | UUID | PK |
| nome | VARCHAR(255) | Nome completo |
| email | VARCHAR(255) | Email único |
| telefone | VARCHAR(20) | Telefone |
| nif | VARCHAR(20) | NIF/CPF |
| tipo_usuario | VARCHAR(20) | 'colaborador', 'gestor', 'admin' |
| ativo | BOOLEAN | Se está ativo |
| foto_perfil | TEXT | URL do avatar |
| preferencias | JSONB | Preferências do usuário |

#### `colaboradores`
Dados profissionais e financeiros dos motoristas parceiros.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| id | UUID | PK |
| usuario_id | UUID | FK → usuarios |
| iban | VARCHAR(50) | IBAN |
| nome_titular_banco | VARCHAR(255) | Titular |
| telefone_mbway | VARCHAR(20) | MB Way/PIX |
| carteira_lightning | TEXT | Lightning Address |
| metodo_pagamento_preferido | VARCHAR(20) | 'iban', 'mbway', 'satoshi' |
| status | VARCHAR(20) | 'ativo', 'inativo', 'pendente' |
| limite_total | DECIMAL(10,2) | Limite máximo |
| limite_disponivel | DECIMAL(10,2) | Limite atual |
| taxa_juros | DECIMAL(5,2) | Taxa individual |
| gestor_id | UUID | FK → usuarios (gestor) |

#### `solicitacoes`
Solicitações de adiantamento.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| id | UUID | PK |
| colaborador_id | UUID | FK → colaboradores |
| valor_solicitado | DECIMAL(10,2) | Valor pedido |
| valor_liquido | DECIMAL(10,2) | Valor a descontar |
| moeda | VARCHAR(10) | 'EUR', 'SATS' |
| metodo_pagamento | VARCHAR(20) | 'iban', 'mbway', 'satoshi' |
| status | VARCHAR(20) | Status atual |
| etapa_progresso | INTEGER | 0-4 |
| taxa_juros_aplicada | DECIMAL(5,2) | Taxa no momento |
| valor_juros | DECIMAL(10,2) | Valor dos juros |
| data_solicitacao | TIMESTAMP | Data criação |
| data_pagamento | TIMESTAMP | Data do pagamento |
| descontado | BOOLEAN | Se já foi descontado |
| data_desconto | TIMESTAMP | Data do desconto |

#### `notificacoes`
Sistema de notificações.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| id | UUID | PK |
| usuario_id | UUID | FK → usuarios |
| solicitacao_id | UUID | FK → solicitacoes (opcional) |
| titulo | VARCHAR(255) | Título |
| mensagem | TEXT | Mensagem |
| tipo | VARCHAR(20) | 'success', 'info', 'warning', 'error' |
| lida | BOOLEAN | Se foi lida |
| data_criacao | TIMESTAMP | Data criação |

#### `banners`
Banners promocionais.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| id | UUID | PK |
| titulo | VARCHAR(255) | Título |
| imagem_url | TEXT | URL da imagem |
| tipo | VARCHAR(20) | 'carousel', 'popup' |
| ordem | INTEGER | Ordem de exibição |
| ativo | BOOLEAN | Se está ativo |

---

## Fluxos de Negócio

### Fluxo de Nova Solicitação

```
┌─────────────────┐
│  Usuário clica  │
│  "Novo Adiant." │
└────────┬────────┘
         ▼
┌─────────────────┐
│   PASSO 1       │
│ - Valor         │
│ - Método pgto   │
└────────┬────────┘
         ▼
┌─────────────────┐
│   PASSO 2       │
│ - Resumo        │
│ - Confirmação   │
│ - Termos        │
└────────┬────────┘
         ▼
┌─────────────────┐
│   Solicitação   │
│   criada com    │
│ status='pending'│
└────────┬────────┘
         ▼
┌─────────────────┐
│   Notificação   │
│   enviada       │
└─────────────────┘
```

### Fluxo de Status

```
PENDING → PROCESSING → APPROVED → PAID
    ↓                      ↓
REJECTED              CANCELED (pelo usuário)
```

### Cálculo de Valores

```
Valor Solicitado: €100.00
Taxa de Juros: 10%
Valor dos Juros: €10.00
Valor a Descontar: €110.00 (Valor + Juros)

O colaborador RECEBE €100.00
O colaborador terá DESCONTADO €110.00 do salário
```

---

## Internacionalização

### Idiomas Suportados

| Idioma | Código | Moeda | Timezone |
|--------|--------|-------|----------|
| Português (Portugal) | pt-PT | € (Euro) | Europe/Lisbon |
| Português (Brasil) | pt-BR | R$ (Real) | America/Sao_Paulo |

### Adaptações PT-BR

| PT-PT | PT-BR |
|-------|-------|
| MB Way | PIX |
| IBAN | Conta Bancária |
| € 100.00 | R$ 100,00 |
| NIF | CPF |

### Uso

```typescript
const { t, formatCurrency, language } = useLanguage()

// Tradução
<h1>{t('home.novo_adiantamento')}</h1>

// Moeda
<span>{formatCurrency(100)}</span>  // €100.00 ou R$ 100,00
```

---

## PWA e Capacitor

### PWA Features

- ✅ Instalável no dispositivo
- ✅ Manifesto web
- ✅ Service Worker
- ✅ Ícones personalizados
- ✅ Splash screen
- ⏳ Modo offline (planejado)

### Capacitor

```typescript
// capacitor.config.ts
export default {
  appId: 'com.x88.colaborador',
  appName: 'X88 Colaborador',
  webDir: 'dist',
  plugins: {
    PushNotifications: { ... },
    SplashScreen: { ... },
    StatusBar: { ... },
    Keyboard: { ... }
  }
}
```

### Plataformas

| Plataforma | Status |
|------------|--------|
| Web (PWA) | ✅ Funcionando |
| Android | ✅ Configurado |
| iOS | ✅ Configurado |

---

## Guia de Desenvolvimento

### Instalação

```bash
# Instalar dependências
npm install

# Iniciar desenvolvimento
npm run dev

# Build de produção
npm run build

# Preview da build
npm run preview
```

### Variáveis de Ambiente

Crie um arquivo `.env` na raiz:

```bash
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anon
```

### Build Mobile

```bash
# Android
npx cap add android
npx cap sync
npx cap open android

# iOS
npx cap add ios
npx cap sync
npx cap open ios
```

### Convenções de Código

- **Componentes**: PascalCase (`NewRequestModal.tsx`)
- **Hooks**: camelCase com prefixo `use` (`useWebPush.ts`)
- **Contextos**: PascalCase com sufixo `Context` (`AuthContext.tsx`)
- **Páginas**: PascalCase organizadas em pastas (`pages/Home/Home.tsx`)
- **Estilos**: Tailwind CSS classes

### Estrutura de Commit

```
feat: adiciona nova funcionalidade
fix: corrige bug
docs: atualiza documentação
style: formatação
refactor: refatoração
test: testes
chore: manutenção
```

---

## Arquivos SQL Importantes

| Arquivo | Descrição |
|---------|-----------|
| `supabase_schema.sql` | Schema completo do banco |
| `supabase_rls_policies.sql` | Políticas RLS |
| `supabase_seed.sql` | Dados iniciais |
| `migration_*.sql` | Migrações incrementais |

---

## Contato e Suporte

- **Projeto**: X88 Motorista Parceiro
- **Versão**: 1.0.0
- **Licença**: Privado - Todos os direitos reservados © 2025 X88

---

*Documentação gerada automaticamente. Última atualização: Dezembro 2025*
