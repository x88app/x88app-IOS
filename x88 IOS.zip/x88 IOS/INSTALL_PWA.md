# 📱 Como Instalar o X88 Colaborador (PWA)

## 🤖 Android (Chrome/Edge)

### Opção 1: Banner Automático
1. Acesse o site no navegador
2. Aguarde aparecer o banner "Instalar aplicativo"
3. Clique em **"Instalar"**
4. Pronto! O app aparecerá na tela inicial

### Opção 2: Menu do Navegador
1. Acesse o site no Chrome
2. Toque nos **3 pontinhos** (menu)
3. Selecione **"Instalar aplicativo"** ou **"Adicionar à tela inicial"**
4. Confirme a instalação
5. O ícone aparecerá na tela inicial

## 🍎 iPhone/iPad (Safari)

1. Acesse o site no Safari
2. Toque no ícone de **Compartilhar** (quadrado com seta)
3. Role para baixo e toque em **"Adicionar à Tela de Início"**
4. Edite o nome se quiser (padrão: "X88")
5. Toque em **"Adicionar"**
6. O ícone aparecerá na tela inicial

## 💻 Desktop (Chrome/Edge/Brave)

1. Acesse o site no navegador
2. Procure o ícone de **instalação** na barra de endereço (➕)
3. Clique em **"Instalar"**
4. O app abrirá em janela própria
5. Aparecerá no menu de aplicativos

## ✅ Recursos PWA

Após instalar, você terá:

- ✅ **Ícone na tela inicial** com a logo verde X88
- ✅ **Funciona offline** (cache de dados)
- ✅ **Tela cheia** (sem barra do navegador)
- ✅ **Notificações** (quando implementadas)
- ✅ **Atualização automática** quando houver nova versão
- ✅ **Dados salvos localmente** (mesmo offline)

## 🎨 Configurações PWA

- **Nome:** X88 Colaborador
- **Nome curto:** X88
- **Cor do tema:** Verde (#15ff5d)
- **Cor de fundo:** Preto (#000000)
- **Orientação:** Retrato (portrait)
- **Logo:** logotipo X88 green.fw.png

## 🔧 Troubleshooting

### O banner de instalação não aparece?
- Certifique-se de estar em **HTTPS** (não localhost)
- Use Chrome, Edge ou navegador compatível
- Limpe o cache e recarregue a página

### Não encontro a opção de instalar?
- Verifique se o navegador suporta PWA
- No Safari (iOS), use **"Adicionar à Tela de Início"**
- No Chrome (Android), procure **"Instalar aplicativo"** no menu

### Como desinstalar?
- **Android:** Segure o ícone e arraste para "Desinstalar"
- **iOS:** Segure o ícone e selecione "Remover App"
- **Desktop:** Vá nas configurações do app e clique em "Desinstalar"

## 🚀 Deploy

Para que o PWA funcione em produção:

1. ✅ Site deve estar em **HTTPS**
2. ✅ Manifest configurado (já está!)
3. ✅ Service Worker ativo (VitePWA faz isso)
4. ✅ Ícones nas resoluções corretas (já está!)

Faça o deploy no Vercel, Netlify ou qualquer host com HTTPS!
