# 🗄️ Documentação Completa do Banco de Dados - X88 Adiantamento Salarial

## 📋 Índice
1. [Visão Geral](#visão-geral)
2. [Estrutura das Tabelas](#estrutura-das-tabelas)
3. [Relacionamentos](#relacionamentos)
4. [Como Usar no Supabase](#como-usar-no-supabase)
5. [Políticas de Segurança (RLS)](#políticas-de-segurança-rls)
6. [Queries Úteis](#queries-úteis)

---

## 🎯 Visão Geral

O banco de dados foi projetado para gerenciar um sistema de **adiantamento salarial** com as seguintes características:

- ✅ **100% em Português Brasileiro** (nomes de tabelas e colunas)
- ✅ **Segurança RLS** (Row Level Security) completa
- ✅ **Suporte a múltiplas moedas** (EUR e SATS/Bitcoin)
- ✅ **Auditoria completa** de todas as ações
- ✅ **Sistema de notificações** em tempo real
- ✅ **Carteira integrada** para gestão de saldo

---

## 📊 Estrutura das Tabelas

### 1. **usuarios**
Armazena dados de autenticação e perfil básico de todos os usuários.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único do usuário (PK) |
| `nome` | VARCHAR(255) | Nome completo |
| `email` | VARCHAR(255) | Email único para login |
| `telefone` | VARCHAR(20) | Telefone de contato |
| `nif` | VARCHAR(20) | NIF (Número de Identificação Fiscal) |
| `senha_hash` | TEXT | Hash da senha (bcrypt) |
| `tipo_usuario` | VARCHAR(20) | Tipo: colaborador, gestor, admin |
| `ativo` | BOOLEAN | Status ativo/inativo |
| `foto_perfil` | TEXT | URL da foto de perfil |

### 2. **colaboradores**
Dados profissionais e financeiros dos colaboradores.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único do colaborador (PK) |
| `usuario_id` | UUID | Referência ao usuário (FK) |
| `iban` | VARCHAR(50) | IBAN para transferências |
| `nome_titular_banco` | VARCHAR(255) | Nome do titular da conta |
| `swift_bic` | VARCHAR(20) | Código SWIFT/BIC |
| `telefone_mbway` | VARCHAR(20) | Telefone para MBWAY |
| `carteira_lightning` | TEXT | Endereço Lightning Network |
| `metodo_pagamento_preferido` | VARCHAR(20) | iban, mbway ou satoshi |
| `status` | VARCHAR(20) | ativo, inativo ou pendente |
| `limite_total` | DECIMAL(10,2) | Limite máximo de crédito |
| `limite_disponivel` | DECIMAL(10,2) | Limite ainda disponível |
| `taxa_juros` | DECIMAL(5,2) | Taxa de juros personalizada (%) |
| `total_adiantamentos` | INTEGER | Total de solicitações feitas |
| `data_admissao` | TIMESTAMP | Data de admissão na empresa |

### 3. **solicitacoes**
Todas as solicitações de adiantamento salarial.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único da solicitação (PK) |
| `colaborador_id` | UUID | Referência ao colaborador (FK) |
| `valor_solicitado` | DECIMAL(10,2) | Valor total solicitado |
| `valor_liquido` | DECIMAL(10,2) | Valor após dedução de juros |
| `moeda` | VARCHAR(10) | EUR ou SATS |
| `metodo_pagamento` | VARCHAR(20) | iban, mbway ou satoshi |
| `status` | VARCHAR(20) | pendente, processando, aprovado, pago, rejeitado, verificando |
| `etapa_progresso` | INTEGER | Etapa atual (0-4) |
| `taxa_juros_aplicada` | DECIMAL(5,2) | Taxa de juros aplicada (%) |
| `valor_juros` | DECIMAL(10,2) | Valor dos juros |
| `lida` | BOOLEAN | Marcador de leitura pelo gestor |
| `data_solicitacao` | TIMESTAMP | Data/hora da solicitação |
| `data_aprovacao` | TIMESTAMP | Data/hora da aprovação |
| `data_pagamento` | TIMESTAMP | Data/hora do pagamento |

### 4. **notificacoes**
Sistema de notificações para os usuários.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único da notificação (PK) |
| `usuario_id` | UUID | Usuário destinatário (FK) |
| `solicitacao_id` | UUID | Solicitação relacionada (FK) |
| `titulo` | VARCHAR(255) | Título da notificação |
| `mensagem` | TEXT | Conteúdo da mensagem |
| `tipo` | VARCHAR(20) | success, info, warning, error |
| `lida` | BOOLEAN | Status de leitura |

### 5. **carteira_gestor**
Saldo disponível do gestor para pagamentos.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único da carteira (PK) |
| `gestor_id` | UUID | Referência ao gestor (FK) |
| `saldo_eur` | DECIMAL(12,2) | Saldo em Euros |
| `saldo_sats` | BIGINT | Saldo em Satoshis |

### 6. **transacoes_carteira**
Histórico de movimentações da carteira.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único da transação (PK) |
| `carteira_id` | UUID | Referência à carteira (FK) |
| `tipo_transacao` | VARCHAR(20) | deposito, pagamento, estorno |
| `moeda` | VARCHAR(10) | EUR ou SATS |
| `valor` | DECIMAL(12,2) | Valor da transação |
| `saldo_anterior` | DECIMAL(12,2) | Saldo antes da transação |
| `saldo_atual` | DECIMAL(12,2) | Saldo após a transação |
| `solicitacao_id` | UUID | Solicitação relacionada (FK) |

### 7. **banners**
Banners promocionais exibidos no app.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único do banner (PK) |
| `titulo` | VARCHAR(255) | Título do banner |
| `imagem_url` | TEXT | URL da imagem |
| `ordem` | INTEGER | Ordem de exibição |
| `ativo` | BOOLEAN | Status ativo/inativo |

### 8. **cards_anuncio**
Cards de anúncios e benefícios.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único do card (PK) |
| `titulo` | VARCHAR(255) | Título do card |
| `descricao` | TEXT | Descrição do benefício |
| `imagem_url` | TEXT | URL da imagem |
| `ordem` | INTEGER | Ordem de exibição |
| `ativo` | BOOLEAN | Status ativo/inativo |

### 9. **configuracoes_sistema**
Configurações gerais do sistema.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único da configuração (PK) |
| `chave` | VARCHAR(100) | Chave única da configuração |
| `valor` | TEXT | Valor da configuração |
| `tipo` | VARCHAR(20) | texto, numero, booleano, json |
| `descricao` | TEXT | Descrição da configuração |

### 10. **auditoria**
Log completo de todas as ações no sistema.

| Coluna | Tipo | Descrição |
|--------|------|-----------|
| `id` | UUID | ID único do log (PK) |
| `usuario_id` | UUID | Usuário que executou a ação (FK) |
| `acao` | VARCHAR(100) | Tipo da ação executada |
| `tabela` | VARCHAR(50) | Tabela afetada |
| `registro_id` | UUID | ID do registro afetado |
| `dados_anteriores` | JSONB | Estado anterior (JSON) |
| `dados_novos` | JSONB | Novo estado (JSON) |
| `endereco_ip` | VARCHAR(45) | IP de origem |
| `user_agent` | TEXT | Navegador/App usado |

---

## 🔗 Relacionamentos

```
usuarios (1) ──→ (1) colaboradores
usuarios (1) ──→ (1) carteira_gestor
usuarios (1) ──→ (N) notificacoes

colaboradores (1) ──→ (N) solicitacoes

carteira_gestor (1) ──→ (N) transacoes_carteira

solicitacoes (1) ──→ (N) notificacoes
solicitacoes (1) ──→ (0..1) transacoes_carteira
```

---

## 🚀 Como Usar no Supabase

### Passo 1: Criar o Projeto no Supabase
1. Acesse [https://supabase.com](https://supabase.com)
2. Crie uma nova conta ou faça login
3. Clique em **"New Project"**
4. Escolha nome, senha do banco e região
5. Aguarde a criação do projeto

### Passo 2: Executar o Schema
1. No painel do Supabase, vá em **SQL Editor**
2. Clique em **"New Query"**
3. Copie todo o conteúdo de `supabase_schema.sql`
4. Cole no editor e clique em **"Run"**
5. Aguarde a execução (pode levar alguns segundos)

### Passo 3: Configurar as Políticas RLS
1. Ainda no **SQL Editor**, crie uma **nova query**
2. Copie todo o conteúdo de `supabase_rls_policies.sql`
3. Cole no editor e clique em **"Run"**
4. As políticas de segurança serão aplicadas

### Passo 4: Inserir Dados de Teste
1. Crie mais uma **nova query**
2. Copie todo o conteúdo de `supabase_seed.sql`
3. Cole no editor e clique em **"Run"**
4. Os dados fictícios serão inseridos

### Passo 5: Obter as Credenciais
1. Vá em **Settings** → **API**
2. Copie:
   - **Project URL**: `https://[seu-projeto].supabase.co`
   - **anon public key**: Chave pública para uso no frontend
   - **service_role key**: Chave privada (apenas backend)

---

## 🔒 Políticas de Segurança (RLS)

O sistema possui RLS (Row Level Security) habilitado em **TODAS** as tabelas.

### Regras Principais:

#### **Colaboradores**
- ✅ Podem ver apenas seus próprios dados
- ✅ Podem criar suas próprias solicitações
- ✅ Podem atualizar apenas solicitações pendentes
- ❌ Não podem ver dados de outros colaboradores
- ❌ Não podem aprovar/rejeitar solicitações

#### **Gestores**
- ✅ Podem ver todos os colaboradores e solicitações
- ✅ Podem aprovar/rejeitar qualquer solicitação
- ✅ Podem marcar solicitações como pagas
- ✅ Podem gerenciar banners e cards de anúncio
- ✅ Têm acesso à carteira e transações

#### **Admins**
- ✅ Têm acesso total a todas as tabelas
- ✅ Podem modificar configurações do sistema
- ✅ Podem visualizar logs de auditoria

---

## 🔍 Queries Úteis

### Listar todas as solicitações com dados do colaborador
```sql
SELECT * FROM vw_solicitacoes_completas
WHERE status = 'pendente'
ORDER BY data_solicitacao DESC;
```

### Estatísticas de um colaborador específico
```sql
SELECT * FROM vw_estatisticas_colaboradores
WHERE colaborador_id = 'uuid-do-colaborador';
```

### Saldo atual da carteira do gestor
```sql
SELECT 
    saldo_eur,
    saldo_sats,
    data_atualizacao
FROM carteira_gestor
WHERE gestor_id = 'uuid-do-gestor';
```

### Histórico de pagamentos do mês atual
```sql
SELECT 
    s.id,
    u.nome AS colaborador,
    s.valor_solicitado,
    s.moeda,
    s.data_pagamento
FROM solicitacoes s
JOIN colaboradores c ON s.colaborador_id = c.id
JOIN usuarios u ON c.usuario_id = u.id
WHERE s.status = 'pago'
  AND EXTRACT(MONTH FROM s.data_pagamento) = EXTRACT(MONTH FROM NOW())
  AND EXTRACT(YEAR FROM s.data_pagamento) = EXTRACT(YEAR FROM NOW())
ORDER BY s.data_pagamento DESC;
```

### Notificações não lidas de um usuário
```sql
SELECT 
    n.titulo,
    n.mensagem,
    n.tipo,
    n.data_criacao
FROM notificacoes n
WHERE n.usuario_id = 'uuid-do-usuario'
  AND n.lida = false
ORDER BY n.data_criacao DESC;
```

### Relatório de juros cobrados no período
```sql
SELECT 
    DATE_TRUNC('month', s.data_pagamento) AS mes,
    SUM(s.valor_juros) AS total_juros_eur,
    COUNT(*) AS total_solicitacoes
FROM solicitacoes s
WHERE s.status = 'pago'
  AND s.moeda = 'EUR'
GROUP BY DATE_TRUNC('month', s.data_pagamento)
ORDER BY mes DESC;
```

---

## 📝 Notas Importantes

1. **Senhas**: As senhas devem ser armazenadas usando **bcrypt** com salt rounds >= 10
2. **UUIDs**: Todos os IDs são UUIDs gerados automaticamente pelo PostgreSQL
3. **Timestamps**: Todos os timestamps incluem timezone (TIMESTAMP WITH TIME ZONE)
4. **Moedas**: O sistema suporta EUR (decimal) e SATS (bigint)
5. **RLS**: Todas as queries devem ser autenticadas via Supabase Auth

---

## 🔄 Atualizações Automáticas

O sistema possui **triggers** que atualizam automaticamente:
- `data_atualizacao` em todas as tabelas quando há UPDATE
- Validações de constraints antes de INSERT/UPDATE
- Logs de auditoria (pode ser implementado via triggers adicionais)

---

## 📞 Suporte

Para dúvidas sobre a estrutura do banco de dados:
- Consulte este arquivo
- Verifique os comentários no código SQL
- Consulte a documentação do Supabase: https://supabase.com/docs

---

**Versão:** 1.0.0  
**Última atualização:** 2025  
**Criado para:** X88 Adiantamento Salarial
