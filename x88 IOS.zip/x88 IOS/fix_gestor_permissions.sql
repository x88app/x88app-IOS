-- =====================================================
-- CORRIGIR PERMISSÕES PARA GESTORES
-- Permitir que TODOS os gestores vejam TODOS os colaboradores e solicitações
-- =====================================================

-- Criar função auxiliar para verificar se usuário é gestor (evita recursão)
CREATE OR REPLACE FUNCTION is_gestor()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN (
        SELECT tipo_usuario = 'gestor'
        FROM usuarios
        WHERE id = auth.uid()
        LIMIT 1
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- =====================================================
-- 1. POLÍTICAS PARA COLABORADORES
-- =====================================================

-- Gestores podem ver TODOS os colaboradores
DROP POLICY IF EXISTS "Gestores veem todos colaboradores" ON colaboradores;
CREATE POLICY "Gestores veem todos colaboradores"
    ON colaboradores FOR SELECT
    USING (is_gestor());

-- Gestores podem atualizar TODOS os colaboradores
DROP POLICY IF EXISTS "Gestores atualizam colaboradores" ON colaboradores;
CREATE POLICY "Gestores atualizam colaboradores"
    ON colaboradores FOR UPDATE
    USING (is_gestor());

-- =====================================================
-- 2. POLÍTICAS PARA SOLICITAÇÕES
-- =====================================================

-- Gestores podem ver TODAS as solicitações
DROP POLICY IF EXISTS "Gestores veem todas solicitações" ON solicitacoes;
CREATE POLICY "Gestores veem todas solicitações"
    ON solicitacoes FOR SELECT
    USING (is_gestor());

-- Gestores podem atualizar TODAS as solicitações
DROP POLICY IF EXISTS "Gestores atualizam solicitações" ON solicitacoes;
CREATE POLICY "Gestores atualizam solicitações"
    ON solicitacoes FOR UPDATE
    USING (is_gestor())
    WITH CHECK (is_gestor());

-- =====================================================
-- 3. POLÍTICAS PARA USUÁRIOS
-- =====================================================

-- Gestores podem ver TODOS os usuários (sem recursão)
DROP POLICY IF EXISTS "Gestores veem todos usuários" ON usuarios;
CREATE POLICY "Gestores veem todos usuários"
    ON usuarios FOR SELECT
    USING (is_gestor());

-- =====================================================
-- 4. MENSAGEM DE CONFIRMAÇÃO
-- =====================================================

DO $$
BEGIN
    RAISE NOTICE '✅ Permissões de gestor corrigidas com sucesso!';
    RAISE NOTICE '   - Gestores agora podem ver TODOS os colaboradores';
    RAISE NOTICE '   - Gestores agora podem ver TODAS as solicitações';
    RAISE NOTICE '   - Gestores agora podem atualizar colaboradores e solicitações';
END $$;
