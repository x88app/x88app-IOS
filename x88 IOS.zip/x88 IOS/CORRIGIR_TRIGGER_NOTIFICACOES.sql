-- =====================================================
-- CORREÇÃO DO TRIGGER DE NOTIFICAÇÕES
-- Agora verifica as preferências do usuário antes de enviar
-- =====================================================

-- 1. Função corrigida que verifica preferências antes de gerar notificação
CREATE OR REPLACE FUNCTION notify_status_change()
RETURNS TRIGGER AS $$
DECLARE
    colab_user_id UUID;
    user_preferences JSONB;
    notification_title TEXT;
    notification_message TEXT;
    notification_type VARCHAR;
    should_notify BOOLEAN := FALSE;
BEGIN
    -- Verifica se houve mudança de status
    IF (OLD.status IS DISTINCT FROM NEW.status) THEN
        -- Busca o ID do usuário e suas preferências
        SELECT u.id, u.preferencias INTO colab_user_id, user_preferences
        FROM colaboradores c
        INNER JOIN usuarios u ON c.usuario_id = u.id
        WHERE c.id = NEW.colaborador_id;

        -- Define mensagem e verifica preferência baseada no novo status
        IF (NEW.status = 'aprovado') THEN
            -- Verifica se o usuário quer receber notificação de aprovação
            should_notify := COALESCE(
                (user_preferences->'notifications'->'types'->>'approved')::boolean, 
                TRUE
            );
            
            IF should_notify THEN
                notification_title := 'Solicitação Aprovada';
                notification_message := 'Sua solicitação foi aprovada. Você receberá a transferência em breve.';
                notification_type := 'success';
            END IF;
        
        ELSIF (NEW.status = 'rejeitado') THEN
            -- Verifica se o usuário quer receber notificação de rejeição
            should_notify := COALESCE(
                (user_preferences->'notifications'->'types'->>'rejected')::boolean, 
                TRUE
            );
            
            IF should_notify THEN
                notification_title := 'Solicitação Rejeitada';
                notification_message := 'Sua solicitação não foi aprovada desta vez.';
                notification_type := 'error';
            END IF;
        
        ELSIF (NEW.status = 'pago') THEN
            -- Verifica se o usuário quer receber notificação de pagamento
            should_notify := COALESCE(
                (user_preferences->'notifications'->'types'->>'payment')::boolean, 
                TRUE
            );
            
            IF should_notify THEN
                notification_title := 'Transferência Realizada';
                
                -- Personaliza mensagem por método de pagamento
                IF (NEW.metodo_pagamento = 'iban') THEN
                    notification_message := 'O valor foi transferido para a conta bancária.';
                ELSIF (NEW.metodo_pagamento = 'mbway') THEN
                    notification_message := 'O valor foi enviado via MBWAY.';
                ELSIF (NEW.metodo_pagamento = 'satoshi') THEN
                    notification_message := 'O valor foi enviado para sua carteira Lightning.';
                ELSE
                    notification_message := 'O valor foi transferido.';
                END IF;
                
                notification_type := 'success';
            END IF;
        END IF;

        -- Se houver mensagem definida e usuário quer receber, insere a notificação
        IF (notification_message IS NOT NULL AND should_notify = TRUE) THEN
            INSERT INTO notificacoes (usuario_id, solicitacao_id, titulo, mensagem, tipo, lida)
            VALUES (colab_user_id, NEW.id, notification_title, notification_message, notification_type, FALSE);
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Remove trigger anterior se existir
DROP TRIGGER IF EXISTS trigger_notify_status_change ON solicitacoes;

-- 3. Recria o trigger na tabela solicitacoes
CREATE TRIGGER trigger_notify_status_change
AFTER UPDATE ON solicitacoes
FOR EACH ROW
EXECUTE FUNCTION notify_status_change();
