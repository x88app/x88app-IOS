-- Remove todos os banners fictícios inseridos via seed
DELETE FROM banners;

-- (Opcional) Se quiser remover apenas os específicos do seed:
-- DELETE FROM banners WHERE id IN (
--   '66666666-6666-6666-6666-666666666661',
--   '66666666-6666-6666-6666-666666666662',
--   '66666666-6666-6666-6666-666666666663'
-- );
