-- =====================================================
-- MIGRATION: Adicionar foto_perfil nas views
-- =====================================================

-- Primeiro, dropar as views existentes
DROP VIEW IF EXISTS vw_colaboradores_completos CASCADE;
DROP VIEW IF EXISTS vw_solicitacoes_completas CASCADE;

-- Recriar view de colaboradores com foto_perfil
CREATE VIEW vw_colaboradores_completos AS
SELECT 
    c.id,
    c.usuario_id,
    u.nome,
    u.email,
    u.telefone,
    u.nif,
    u.foto_perfil,
    c.iban,
    c.nome_titular_banco,
    c.telefone_mbway,
    c.carteira_lightning,
    c.status,
    c.limite_total,
    c.limite_disponivel,
    c.taxa_juros,
    c.total_adiantamentos,
    c.data_admissao,
    c.data_registro,
    u.ativo AS usuario_ativo
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- Recriar view de solicitações com foto_perfil do colaborador
CREATE VIEW vw_solicitacoes_completas AS
SELECT 
    s.id,
    s.colaborador_id,
    c.usuario_id,
    u.nome AS colaborador_nome,
    u.email AS colaborador_email,
    u.foto_perfil AS colaborador_foto,
    s.valor_solicitado,
    s.valor_liquido,
    s.moeda,
    s.metodo_pagamento,
    s.detalhes_conta,
    s.iban_pagamento,
    s.mbway_pagamento,
    s.lightning_address,
    s.status,
    s.etapa_progresso,
    s.taxa_juros_aplicada,
    s.valor_juros,
    s.lida,
    s.descontado,
    s.data_desconto,
    s.data_solicitacao,
    s.data_aprovacao,
    s.data_pagamento,
    s.data_atualizacao
FROM solicitacoes s
INNER JOIN colaboradores c ON s.colaborador_id = c.id
INNER JOIN usuarios u ON c.usuario_id = u.id;
