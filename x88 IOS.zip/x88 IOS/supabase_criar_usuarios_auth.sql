-- =====================================================
-- CRIAR USUÁRIOS NO SUPABASE AUTH
-- =====================================================
-- IMPORTANTE: Execute este script ANTES do seed normal
-- =====================================================

-- Limpar dados anteriores (CUIDADO EM PRODUÇÃO!)
TRUNCATE TABLE auditoria CASCADE;
TRUNCATE TABLE transacoes_carteira CASCADE;
TRUNCATE TABLE notificacoes CASCADE;
TRUNCATE TABLE solicitacoes CASCADE;
TRUNCATE TABLE carteira_gestor CASCADE;
TRUNCATE TABLE colaboradores CASCADE;
TRUNCATE TABLE usuarios CASCADE;

-- =====================================================
-- INSERIR USUÁRIOS NA TABELA AUTH (Supabase)
-- =====================================================

-- Esses inserts precisam ser feitos via Dashboard do Supabase!
-- Vá em: Authentication → Users → Add User
-- 
-- Crie estes usuários:
--
-- 1. Email: gestor@x88.pt | Senha: Gestor@123
-- 2. Email: joao.silva@x88.pt | Senha: Joao@123
-- 3. Email: maria.santos@x88.pt | Senha: Maria@123
-- 4. Email: pedro.costa@x88.pt | Senha: Pedro@123
-- 5. Email: ana.ferreira@x88.pt | Senha: Ana@123
-- 6. Email: carlos.oliveira@x88.pt | Senha: Carlos@123
--
-- ✅ Marque "Auto Confirm User" para cada um
-- ✅ Após criar, volte aqui e continue o script

-- =====================================================
-- PASSO 2: INSERIR NA TABELA USUARIOS
-- =====================================================
-- SUBSTITUA os UUIDs abaixo pelos IDs reais do auth.users!
-- Execute: SELECT id, email FROM auth.users;
-- E copie os IDs correspondentes

-- Gestor (SUBSTITUA o UUID)
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo) 
VALUES (
    'COLE-AQUI-O-UUID-DO-GESTOR',
    'Gestor de administração X88',
    'gestor@x88.pt',
    '+351 910 000 000',
    '100000000',
    'nao-usado',  -- senha gerenciada pelo Supabase Auth
    'gestor',
    true
);

-- João Silva (SUBSTITUA o UUID)
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo)
VALUES (
    'COLE-AQUI-O-UUID-DO-JOAO',
    'João Silva',
    'joao.silva@x88.pt',
    '+351 912 345 678',
    '123456789',
    'nao-usado',
    'colaborador',
    true
);

-- Maria Santos (SUBSTITUA o UUID)
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo)
VALUES (
    'COLE-AQUI-O-UUID-DA-MARIA',
    'Maria Santos',
    'maria.santos@x88.pt',
    '+351 913 456 789',
    '234567890',
    'nao-usado',
    'colaborador',
    true
);

-- Pedro Costa (SUBSTITUA o UUID)
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo)
VALUES (
    'COLE-AQUI-O-UUID-DO-PEDRO',
    'Pedro Costa',
    'pedro.costa@x88.pt',
    '+351 914 567 890',
    '345678901',
    'nao-usado',
    'colaborador',
    true
);

-- Ana Ferreira (SUBSTITUA o UUID)
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo)
VALUES (
    'COLE-AQUI-O-UUID-DA-ANA',
    'Ana Ferreira',
    'ana.ferreira@x88.pt',
    '+351 915 678 901',
    '456789012',
    'nao-usado',
    'colaborador',
    true
);

-- Carlos Oliveira (SUBSTITUA o UUID)
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo)
VALUES (
    'COLE-AQUI-O-UUID-DO-CARLOS',
    'Carlos Oliveira',
    'carlos.oliveira@x88.pt',
    '+351 916 789 012',
    '567890123',
    'nao-usado',
    'colaborador',
    true
);

-- =====================================================
-- VERIFICAR SE DEU CERTO
-- =====================================================
SELECT 
    u.id,
    u.email,
    u.tipo_usuario,
    au.email as auth_email,
    au.confirmed_at
FROM usuarios u
LEFT JOIN auth.users au ON u.id = au.id
ORDER BY u.tipo_usuario, u.email;

-- Se aparecer dados na coluna 'auth_email', está correto! ✅
