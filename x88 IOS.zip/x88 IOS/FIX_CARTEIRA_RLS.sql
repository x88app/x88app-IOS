-- CORREÇÃO DE PERMISSÕES DA CARTEIRA DO GESTOR
-- Garante que o gestor possa visualizar e atualizar sua própria carteira

-- 1. Habilitar RLS na tabela carteira_gestor (se não estiver)
ALTER TABLE carteira_gestor ENABLE ROW LEVEL SECURITY;

-- 2. Remover policies antigas para evitar conflitos
DROP POLICY IF EXISTS "Gestor ve sua propria carteira" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestor atualiza sua propria carteira" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores veem suas carteiras" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores atualizam suas carteiras" ON carteira_gestor;

-- 3. Criar Policy de Leitura (SELECT)
CREATE POLICY "Gestor ve sua propria carteira"
ON carteira_gestor FOR SELECT
USING (auth.uid() = gestor_id);

-- 4. Criar Policy de Atualização (UPDATE)
CREATE POLICY "Gestor atualiza sua propria carteira"
ON carteira_gestor FOR UPDATE
USING (auth.uid() = gestor_id);

-- 5. Criar Policy de Inserção (INSERT) - caso precise criar a carteira
CREATE POLICY "Gestor cria sua propria carteira"
ON carteira_gestor FOR INSERT
WITH CHECK (auth.uid() = gestor_id);

-- TRANSAÇÕES DA CARTEIRA
-- Garantir permissões também na tabela de histórico

ALTER TABLE transacoes_carteira ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Gestor ve suas transacoes" ON transacoes_carteira;
DROP POLICY IF EXISTS "Gestor cria transacoes" ON transacoes_carteira;

-- Policy de Leitura
CREATE POLICY "Gestor ve suas transacoes"
ON transacoes_carteira FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM carteira_gestor
        WHERE carteira_gestor.id = transacoes_carteira.carteira_id
        AND carteira_gestor.gestor_id = auth.uid()
    )
);

-- Policy de Inserção
CREATE POLICY "Gestor cria transacoes"
ON transacoes_carteira FOR INSERT
WITH CHECK (
    EXISTS (
        SELECT 1 FROM carteira_gestor
        WHERE carteira_gestor.id = transacoes_carteira.carteira_id
        AND carteira_gestor.gestor_id = auth.uid()
    )
);
