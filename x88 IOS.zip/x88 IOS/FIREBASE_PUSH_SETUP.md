# 🔔 Configuração Firebase Push Notifications - iOS

## Pré-requisitos
- ✅ Conta Apple Developer ativa
- ✅ Conta Firebase (gratuita)
- ✅ Xcode instalado

---

## Passo 1: Criar Projeto no Firebase

1. Acesse [Firebase Console](https://console.firebase.google.com/)
2. Clique **Adicionar projeto**
3. Nome: `X88 Colaborador`
4. Desative Google Analytics (opcional)
5. Clique **Criar projeto**

---

## Passo 2: Adicionar App iOS ao Firebase

1. No Firebase Console, clique no ícone **iOS+**
2. Preencha:
   - **Bundle ID**: `com.x88.colaborador`
   - **Apelido do app**: `X88 Colaborador iOS`
3. Clique **Registrar app**
4. **Baixe o arquivo `GoogleService-Info.plist`**
5. Clique **Próximo** até finalizar

---

## Passo 3: Adicionar GoogleService-Info.plist ao Xcode

1. Abra o projeto no Xcode:
   ```bash
   npx cap open ios
   ```

2. No Xcode, clique com botão direito na pasta **App** (não App.xcodeproj)
3. Selecione **Add Files to "App"...**
4. Selecione o arquivo `GoogleService-Info.plist` baixado
5. ✅ Marque **Copy items if needed**
6. ✅ Marque **Add to targets: App**
7. Clique **Add**

---

## Passo 4: Criar Chave APNs no Apple Developer

1. Acesse [Apple Developer - Keys](https://developer.apple.com/account/resources/authkeys/list)
2. Clique no **+** para criar nova chave
3. Nome: `X88 Push Key`
4. ✅ Marque **Apple Push Notifications service (APNs)**
5. Clique **Continue** → **Register**
6. **IMPORTANTE**: Baixe a chave `.p8` (só pode baixar 1 vez!)
7. Anote o **Key ID** (ex: ABC123DEFG)
8. Anote o **Team ID** (aparece no canto superior direito)

---

## Passo 5: Adicionar Chave APNs ao Firebase

1. No Firebase Console, vá em **Configurações do projeto** (⚙️)
2. Aba **Cloud Messaging**
3. Seção **Configuração do app Apple**
4. Clique **Upload** em **Chave de autenticação APNs**
5. Faça upload da chave `.p8`
6. Preencha:
   - **Key ID**: O ID da chave (ABC123DEFG)
   - **Team ID**: Seu Team ID da Apple
7. Clique **Upload**

---

## Passo 6: Habilitar Push Notifications no Xcode

1. No Xcode, selecione o projeto **App**
2. Aba **Signing & Capabilities**
3. Clique **+ Capability**
4. Adicione **Push Notifications**
5. Adicione **Background Modes**
6. Em Background Modes, marque:
   - ✅ **Remote notifications**

---

## Passo 7: Testar Push Notifications

### No Firebase Console:
1. Vá em **Messaging** (menu lateral)
2. Clique **Criar sua primeira campanha**
3. Selecione **Mensagens do Firebase Notifications**
4. Preencha título e texto
5. Clique **Enviar mensagem de teste**
6. Cole o **FCM Token** do dispositivo (aparece nos logs do app)

### Para obter o FCM Token:
Rode o app em um **iPhone físico** (simulador não suporta push real) e veja o log no Xcode Console.

---

## Estrutura de Arquivos

```
ios/App/App/
├── GoogleService-Info.plist  ← Adicionar aqui
├── AppDelegate.swift
├── Info.plist
└── ...
```

---

## Enviar Push via API (Backend)

### Usando Firebase Admin SDK (Node.js):

```javascript
const admin = require('firebase-admin');

// Inicializar com service account
admin.initializeApp({
  credential: admin.credential.cert('path/to/serviceAccountKey.json')
});

// Enviar notificação
async function sendPush(fcmToken, title, body, data = {}) {
  const message = {
    notification: {
      title,
      body
    },
    data,
    token: fcmToken
  };

  try {
    const response = await admin.messaging().send(message);
    console.log('Push enviado:', response);
  } catch (error) {
    console.error('Erro ao enviar push:', error);
  }
}

// Exemplo de uso
sendPush(
  'FCM_TOKEN_DO_USUARIO',
  'Solicitação Aprovada!',
  'Seu adiantamento de €500 foi aprovado.',
  { url: '/requests/123' }
);
```

---

## Integração com Supabase

Para enviar push quando uma solicitação for aprovada, crie uma Edge Function:

```typescript
// supabase/functions/send-push/index.ts
import { createClient } from '@supabase/supabase-js'

const firebaseServerKey = Deno.env.get('FIREBASE_SERVER_KEY')

Deno.serve(async (req) => {
  const { fcm_token, title, body, data } = await req.json()

  const response = await fetch('https://fcm.googleapis.com/fcm/send', {
    method: 'POST',
    headers: {
      'Authorization': `key=${firebaseServerKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      to: fcm_token,
      notification: { title, body },
      data
    })
  })

  const result = await response.json()
  return new Response(JSON.stringify(result))
})
```

---

## Troubleshooting

### Push não chega:
1. Verifique se está usando **iPhone físico** (simulador não funciona)
2. Verifique se as permissões foram concedidas no app
3. Verifique se o `GoogleService-Info.plist` está no lugar certo
4. Verifique se a chave APNs está configurada no Firebase

### Token não aparece:
1. Verifique os logs do Xcode Console
2. Certifique-se de que o app pediu permissão de notificações

### Erro de assinatura:
1. Certifique-se de que o Team está selecionado no Xcode
2. Verifique se o Bundle ID é `com.x88.colaborador`

---

## Checklist Final

- [ ] Projeto criado no Firebase
- [ ] App iOS adicionado ao Firebase
- [ ] `GoogleService-Info.plist` adicionado ao Xcode
- [ ] Chave APNs (.p8) criada no Apple Developer
- [ ] Chave APNs configurada no Firebase
- [ ] Push Notifications capability no Xcode
- [ ] Background Modes → Remote notifications
- [ ] Teste com iPhone físico

---

**Pronto! 🎉** Agora seu app receberá notificações push nativas no iOS.
