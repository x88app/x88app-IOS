# Personalização do E-mail de Recuperação de Senha

Para que o e-mail chegue em português e com a identidade visual do seu aplicativo, você precisa alterar o modelo (template) diretamente no painel do Supabase.

## Passo a Passo

1. Acesse o painel do seu projeto no [Supabase](https://supabase.com/dashboard).
2. No menu lateral esquerdo, clique em **Authentication**.
3. Em seguida, clique em **Email Templates** (ou Configuração de E-mail).
4. Selecione a opção **Reset Password** (ou Redefinição de Senha).

## Configurações

### Assunto (Subject)
Mude de `Reset Your Password` para:
```text
Recuperação de Senha - X88
```

### Corpo do E-mail (Body)
Substitua todo o código existente pelo HTML abaixo. Este modelo usa as cores do seu aplicativo (#00d749) e está traduzido para o português.

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperação de Senha</title>
</head>
<body style="font-family: sans-serif; background-color: #f5f5f5; margin: 0; padding: 0;">
  <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; margin-top: 40px; margin-bottom: 40px; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
    
    <!-- Cabeçalho Verde -->
    <div style="background: linear-gradient(to right, #00d749, #00dc43); padding: 40px 20px; text-align: center;">
      <h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: bold;">X88</h1>
    </div>

    <!-- Conteúdo -->
    <div style="padding: 40px 30px; text-align: center;">
      <h2 style="color: #333333; margin-top: 0; font-size: 24px;">Esqueceu sua senha?</h2>
      
      <p style="color: #666666; font-size: 16px; line-height: 1.5; margin-bottom: 30px;">
        Recebemos uma solicitação para redefinir a senha da sua conta. Se você não fez esse pedido, pode ignorar este e-mail com segurança.
      </p>

      <!-- Botão -->
      <a href="{{ .ConfirmationURL }}" style="display: inline-block; background-color: #00d749; color: #ffffff; text-decoration: none; padding: 16px 32px; border-radius: 12px; font-weight: bold; font-size: 16px; margin-bottom: 30px;">
        Redefinir Minha Senha
      </a>

      <p style="color: #999999; font-size: 14px; margin-top: 20px;">
        Ou copie e cole o link abaixo no seu navegador:<br>
        <a href="{{ .ConfirmationURL }}" style="color: #00d749; word-break: break-all;">{{ .ConfirmationURL }}</a>
      </p>
    </div>

    <!-- Rodapé -->
    <div style="background-color: #f9f9f9; padding: 20px; text-align: center; border-top: 1px solid #eeeeee;">
      <p style="color: #999999; font-size: 12px; margin: 0;">
        © 2024 X88. Todos os direitos reservados.
      </p>
    </div>
  </div>
</body>
</html>
```

## Importante
Certifique-se de que a **Site URL** nas configurações de URL do Supabase esteja apontando para o seu aplicativo (ex: `http://localhost:5173` para testes ou `https://seu-dominio.com` para produção).
