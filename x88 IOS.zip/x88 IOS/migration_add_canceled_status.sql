-- Migration: Adicionar status 'cancelado' na tabela solicitacoes

ALTER TABLE solicitacoes DROP CONSTRAINT IF EXISTS solicitacoes_status_check;

ALTER TABLE solicitacoes 
ADD CONSTRAINT solicitacoes_status_check 
CHECK (status IN ('pendente', 'processando', 'aprovado', 'pago', 'rejeitado', 'verificando', 'cancelado'));

-- Comentário para documentar
COMMENT ON COLUMN solicitacoes.status IS 'Status da solicitação: pendente, processando, aprovado, pago, rejeitado, verificando, cancelado';
