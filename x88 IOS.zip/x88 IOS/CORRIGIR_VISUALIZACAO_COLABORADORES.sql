-- ==============================================================================
-- CORREÇÃO DEFINITIVA: VISUALIZAÇÃO DE COLABORADORES NO GESTOR
-- ==============================================================================

-- 1. Atualizar permissões na tabela de USUÁRIOS
-- O problema principal geralmente é que o Gestor não consegue ver os dados dos usuários
-- associados aos colaboradores, então o JOIN da view falha e não retorna o registro.

DROP POLICY IF EXISTS "Usuarios veem proprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Gestores veem todos usuarios" ON usuarios;
DROP POLICY IF EXISTS "Publico_Leitura_Auth" ON usuarios;

-- Política simplificada: Todo usuário autenticado pode ler dados básicos de todos os usuários
-- Isso é necessário para que o gestor veja os nomes/emails dos colaboradores na lista
CREATE POLICY "Todos podem ver usuarios"
    ON usuarios FOR SELECT
    TO authenticated
    USING (true);

-- 2. Atualizar permissões na tabela de COLABORADORES
DROP POLICY IF EXISTS "Colaboradores veem proprios dados" ON colaboradores;
DROP POLICY IF EXISTS "Gestores veem tudo" ON colaboradores;
DROP POLICY IF EXISTS "Colab_Leitura_Mista" ON colaboradores;
DROP POLICY IF EXISTS "Gestores veem todos colaboradores" ON colaboradores;

CREATE POLICY "Gestores veem todos colaboradores"
    ON colaboradores FOR SELECT
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
        OR 
        usuario_id = auth.uid() -- O próprio colaborador também pode ver seu registro
    );

-- 3. Recriar a View com SECURITY INVOKER
-- Isso garante que a view respeite as permissões acima
DROP VIEW IF EXISTS vw_colaboradores_completos;

CREATE OR REPLACE VIEW vw_colaboradores_completos WITH (security_invoker = true) AS
SELECT 
    c.id,
    c.usuario_id,
    u.nome,
    u.email,
    u.telefone,
    u.nif,
    c.iban,
    c.nome_titular_banco,
    c.telefone_mbway,
    c.carteira_lightning,
    c.status,
    c.metodo_pagamento_preferido,
    c.limite_total,
    c.limite_disponivel,
    c.taxa_juros,
    c.total_adiantamentos,
    c.data_admissao,
    c.data_registro,
    u.ativo AS usuario_ativo
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- 4. Garantir que seu usuário seja GESTOR
-- Substitua o email abaixo pelo seu email de login no app
UPDATE usuarios 
SET tipo_usuario = 'gestor' 
WHERE email = 'silvioluigmj@gmail.com';

-- 5. Verificar total de colaboradores que devem aparecer
SELECT 'Total de Colaboradores na Base' as info, count(*) as total FROM colaboradores;

-- 6. Verificar quantos você consegue ver agora (simulando a view)
SELECT 'Total Visivel na View' as info, count(*) as total FROM vw_colaboradores_completos;
