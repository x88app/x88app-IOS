-- =====================================================
-- TESTE FINAL - Execute LOGADO como gestor
-- =====================================================

-- 1. Verificar quem você é
SELECT 
    auth.uid() as meu_user_id,
    auth.role() as meu_role;

-- 2. Ver seus dados em usuarios
SELECT * FROM usuarios WHERE id = auth.uid();

-- 3. Verificar se é reconhecido como gestor
SELECT EXISTS (
    SELECT 1 FROM usuarios 
    WHERE id = auth.uid() 
    AND tipo_usuario IN ('gestor', 'admin')
) AS sou_gestor_reconhecido;

-- 4. Contar usuários que você vê
SELECT COUNT(*) as total_usuarios FROM usuarios;

-- 5. Contar colaboradores que você vê
SELECT COUNT(*) as total_colaboradores FROM colaboradores;

-- 6. Contar na view (o que o app usa)
SELECT COUNT(*) as total_view FROM vw_colaboradores_completos;

-- 7. Ver TODOS os dados da view
SELECT * FROM vw_colaboradores_completos;

-- 8. Ver policies ativas
SELECT 
    tablename,
    policyname,
    cmd,
    SUBSTRING(qual::text, 1, 100) as condicao
FROM pg_policies
WHERE tablename IN ('usuarios', 'colaboradores')
ORDER BY tablename, policyname;

-- =====================================================
-- DIAGNÓSTICO ESPERADO:
-- =====================================================
-- Se total_view = 0 mas total_colaboradores > 0:
--   - O problema está na VIEW (JOIN entre colaboradores e usuarios)
--   - Pode ser que a policy de usuarios não esteja permitindo o JOIN
--
-- Se total_colaboradores = 0:
--   - A policy de colaboradores não está funcionando
--   - Verifique se sou_gestor_reconhecido = TRUE
--
-- Se sou_gestor_reconhecido = FALSE:
--   - Seu registro em usuarios não tem tipo_usuario = 'gestor'
-- =====================================================
