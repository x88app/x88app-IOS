-- =====================================================
-- FIX: Corrigir trigger que usa campo errado
-- O campo correto é valor_solicitado, não valor
-- Execute no Supabase SQL Editor
-- =====================================================

CREATE OR REPLACE FUNCTION notify_solicitacao_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_valor NUMERIC;
    v_title TEXT;
    v_body TEXT;
    v_usuario_id UUID;
BEGIN
    -- Só notifica se o status mudou
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        
        -- Buscar usuario_id do colaborador
        SELECT usuario_id INTO v_usuario_id 
        FROM colaboradores 
        WHERE id = NEW.colaborador_id;
        
        -- Se não encontrar usuario_id, retorna sem inserir
        IF v_usuario_id IS NULL THEN
            RETURN NEW;
        END IF;
        
        -- CORRIGIDO: usar valor_solicitado em vez de valor
        v_valor := NEW.valor_solicitado;
        
        -- Define mensagem baseada no novo status
        CASE NEW.status
            WHEN 'aprovado' THEN
                v_title := 'Solicitação Aprovada!';
                v_body := 'Seu adiantamento de €' || to_char(v_valor, 'FM999990.00') || ' foi aprovado.';
            WHEN 'rejeitado' THEN
                v_title := 'Solicitação Rejeitada';
                v_body := 'Seu adiantamento de €' || to_char(v_valor, 'FM999990.00') || ' foi rejeitado.';
            WHEN 'pago' THEN
                v_title := 'Pagamento Realizado!';
                v_body := 'Seu adiantamento de €' || to_char(v_valor, 'FM999990.00') || ' foi pago.';
            WHEN 'cancelado' THEN
                v_title := 'Solicitação Cancelada';
                v_body := 'Seu adiantamento de €' || to_char(v_valor, 'FM999990.00') || ' foi cancelado.';
            ELSE
                RETURN NEW;
        END CASE;
        
        -- Insere notificação na tabela usando usuario_id
        INSERT INTO notificacoes (usuario_id, solicitacao_id, titulo, mensagem, tipo, lida)
        VALUES (v_usuario_id, NEW.id, v_title, v_body, 'info', false);
        
    END IF;
    
    RETURN NEW;
END;
$$;

SELECT 'Trigger corrigido com sucesso!' as status;
