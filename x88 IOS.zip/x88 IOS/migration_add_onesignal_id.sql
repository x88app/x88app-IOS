-- Adiciona coluna onesignal_id na tabela de usuarios
ALTER TABLE usuarios
ADD COLUMN IF NOT EXISTS onesignal_id TEXT;

-- Cria índice para busca rápida (útil para enviar notificações)
CREATE INDEX IF NOT EXISTS idx_usuarios_onesignal_id ON usuarios(onesignal_id);
