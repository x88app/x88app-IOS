-- Criar tabela para cards de benefícios configuráveis pelo gestor
CREATE TABLE IF NOT EXISTS cards_beneficios (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  titulo VARCHAR(100) NOT NULL,
  descricao VARCHAR(255) NOT NULL,
  icone VARCHAR(50) NOT NULL DEFAULT 'Sparkles',
  cor VARCHAR(20) NOT NULL DEFAULT 'green',
  ordem INTEGER NOT NULL DEFAULT 0,
  ativo BOOLEAN NOT NULL DEFAULT true,
  gestor_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_cards_beneficios_ativo ON cards_beneficios(ativo);
CREATE INDEX IF NOT EXISTS idx_cards_beneficios_ordem ON cards_beneficios(ordem);

-- Habilitar RLS
ALTER TABLE cards_beneficios ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
-- Gestores podem fazer tudo
CREATE POLICY "Gestores podem gerenciar cards_beneficios" ON cards_beneficios
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM usuarios 
      WHERE usuarios.id = auth.uid() 
      AND usuarios.tipo_usuario = 'gestor'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM usuarios 
      WHERE usuarios.id = auth.uid() 
      AND usuarios.tipo_usuario = 'gestor'
    )
  );

-- Colaboradores podem apenas visualizar cards ativos
CREATE POLICY "Colaboradores podem ver cards ativos" ON cards_beneficios
  FOR SELECT
  TO authenticated
  USING (ativo = true);

-- Inserir dados padrão
INSERT INTO cards_beneficios (titulo, descricao, icone, cor, ordem, ativo) VALUES
  ('Benefícios', 'Receba adiantamentos de forma rápida e segura', 'Sparkles', 'green', 1, true),
  ('O que você pode fazer', 'Solicite em Euro ou Satoshi com aprovação instantânea', 'Zap', 'orange', 2, true),
  ('Segurança', 'Transações protegidas e criptografadas', 'Shield', 'green', 3, true)
ON CONFLICT DO NOTHING;

-- Trigger para atualizar data_atualizacao
CREATE OR REPLACE FUNCTION update_cards_beneficios_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.data_atualizacao = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_cards_beneficios_updated_at ON cards_beneficios;
CREATE TRIGGER trigger_cards_beneficios_updated_at
  BEFORE UPDATE ON cards_beneficios
  FOR EACH ROW
  EXECUTE FUNCTION update_cards_beneficios_updated_at();

-- Habilitar realtime
ALTER PUBLICATION supabase_realtime ADD TABLE cards_beneficios;
