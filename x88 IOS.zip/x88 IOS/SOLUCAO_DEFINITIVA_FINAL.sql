-- =====================================================
-- LIMPEZA TOTAL E CORREÇÃO DE DADOS
-- =====================================================

-- 1. Remover TODAS as policies (incluindo as _all geradas pelo dashboard)
DROP POLICY IF EXISTS "colaboradores_select_all" ON colaboradores;
DROP POLICY IF EXISTS "colaboradores_insert_all" ON colaboradores;
DROP POLICY IF EXISTS "colaboradores_update_all" ON colaboradores;
DROP POLICY IF EXISTS "colaboradores_delete_all" ON colaboradores;

DROP POLICY IF EXISTS "usuarios_select_all" ON usuarios;
DROP POLICY IF EXISTS "usuarios_insert_all" ON usuarios;
DROP POLICY IF EXISTS "usuarios_update_all" ON usuarios;
DROP POLICY IF EXISTS "usuarios_delete_all" ON usuarios;
DROP POLICY IF EXISTS "usuarios_insert_public" ON usuarios;
DROP POLICY IF EXISTS "usuarios_update_own" ON usuarios;

-- Remover as nossas policies anteriores para garantir recriação limpa
DROP POLICY IF EXISTS "Ver colaboradores proprios ou gestor ve tudo" ON colaboradores;
DROP POLICY IF EXISTS "Todos usuarios autenticados veem todos" ON usuarios;
DROP POLICY IF EXISTS "Usuarios atualizam proprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Colaboradores atualizam proprios" ON colaboradores;
DROP POLICY IF EXISTS "Gestores atualizam qualquer colaborador" ON colaboradores;
DROP POLICY IF EXISTS "Gestores inserem colaboradores" ON colaboradores;
DROP POLICY IF EXISTS "Ver solicitacoes proprias ou gestor ve tudo" ON solicitacoes;

-- 2. REAPLICAR AS POLICIES LIMPAS E CORRETAS

-- USUARIOS: Leitura pública (autenticada), Update próprio
CREATE POLICY "Publico_Leitura_Auth" ON usuarios FOR SELECT TO authenticated USING (true);
CREATE POLICY "Proprio_Update_Auth" ON usuarios FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- COLABORADORES: Leitura (Próprio ou Gestor), Update (Próprio ou Gestor), Insert (Gestor)
CREATE POLICY "Colab_Leitura_Mista" ON colaboradores FOR SELECT TO authenticated 
USING (usuario_id = auth.uid() OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo_usuario IN ('gestor', 'admin')));

CREATE POLICY "Colab_Update_Mista" ON colaboradores FOR UPDATE TO authenticated 
USING (usuario_id = auth.uid() OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo_usuario IN ('gestor', 'admin')));

CREATE POLICY "Colab_Insert_Gestor" ON colaboradores FOR INSERT TO authenticated 
WITH CHECK (EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo_usuario IN ('gestor', 'admin')));

-- SOLICITACOES: Leitura (Próprio ou Gestor), Insert (Próprio), Update (Gestor)
CREATE POLICY "Sol_Leitura_Mista" ON solicitacoes FOR SELECT TO authenticated 
USING (colaborador_id IN (SELECT id FROM colaboradores WHERE usuario_id = auth.uid()) OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo_usuario IN ('gestor', 'admin')));

CREATE POLICY "Sol_Insert_Colab" ON solicitacoes FOR INSERT TO authenticated 
WITH CHECK (colaborador_id IN (SELECT id FROM colaboradores WHERE usuario_id = auth.uid()));

CREATE POLICY "Sol_Update_Gestor" ON solicitacoes FOR UPDATE TO authenticated 
USING (EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo_usuario IN ('gestor', 'admin')));

-- 3. CORREÇÃO DE DADOS (Crucial!)
-- Garante que os colaboradores existam e estejam ATIVOS
UPDATE colaboradores SET status = 'ativo';
UPDATE usuarios SET ativo = TRUE;

-- 4. VERIFICAÇÃO
SELECT 'Policies Limpas' as status, count(*) as total FROM pg_policies WHERE tablename IN ('usuarios', 'colaboradores');
SELECT 'Colaboradores Ativos' as status, count(*) as total FROM colaboradores WHERE status = 'ativo';
