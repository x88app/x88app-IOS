-- =====================================================
-- TRIGGER DE NOTIFICAÇÕES AUTOMÁTICAS
-- =====================================================

-- 1. Função que gera a notificação
CREATE OR REPLACE FUNCTION notify_status_change()
RETURNS TRIGGER AS $$
DECLARE
    colab_user_id UUID;
    notification_title TEXT;
    notification_message TEXT;
    notification_type VARCHAR;
BEGIN
    -- Verifica se houve mudança de status
    IF (OLD.status IS DISTINCT FROM NEW.status) THEN
        -- Busca o ID do usuário dono da solicitação
        SELECT usuario_id INTO colab_user_id
        FROM colaboradores
        WHERE id = NEW.colaborador_id;

        -- Define mensagem baseada no novo status
        IF (NEW.status = 'aprovado') THEN
            notification_title := 'Solicitação Aprovada';
            notification_message := 'Sua solicitação foi aprovada. Você receberá a transferência em breve.';
            notification_type := 'success';
        
        ELSIF (NEW.status = 'rejeitado') THEN
            notification_title := 'Solicitação Rejeitada';
            notification_message := 'Sua solicitação não foi aprovada desta vez.';
            notification_type := 'error';
        
        ELSIF (NEW.status = 'pago') THEN
            notification_title := 'Transferência Realizada';
            
            -- Personaliza mensagem por método de pagamento
            IF (NEW.metodo_pagamento = 'iban') THEN
                notification_message := 'O valor foi transferido para a conta bancária.';
            ELSIF (NEW.metodo_pagamento = 'mbway') THEN
                notification_message := 'O valor foi enviado via MBWAY.';
            ELSIF (NEW.metodo_pagamento = 'satoshi') THEN
                notification_message := 'O valor foi enviado para sua carteira Lightning.';
            ELSE
                notification_message := 'O valor foi transferido.';
            END IF;
            
            notification_type := 'success';
        END IF;

        -- Se houver mensagem definida, insere a notificação na tabela
        IF (notification_message IS NOT NULL) THEN
            INSERT INTO notificacoes (usuario_id, solicitacao_id, titulo, mensagem, tipo, lida)
            VALUES (colab_user_id, NEW.id, notification_title, notification_message, notification_type, FALSE);
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Remove trigger anterior se existir
DROP TRIGGER IF EXISTS trigger_notify_status_change ON solicitacoes;

-- 3. Cria o trigger na tabela solicitacoes
CREATE TRIGGER trigger_notify_status_change
AFTER UPDATE ON solicitacoes
FOR EACH ROW
EXECUTE FUNCTION notify_status_change();
