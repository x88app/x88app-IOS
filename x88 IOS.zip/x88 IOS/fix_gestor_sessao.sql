-- =====================================================
-- CORREÇÃO: Garantir que gestor veja TODOS os colaboradores
-- =====================================================

-- Primeiro, identifique qual é o seu ID (execute logado como gestor):
SELECT auth.uid() as meu_id;

-- OPÇÃO 1: Se você já sabe seu ID, substitua 'SEU_ID_AQUI' e execute:
-- UPDATE usuarios 
-- SET tipo_usuario = 'gestor', ativo = TRUE
-- WHERE id = 'SEU_ID_AQUI';

-- OPÇÃO 2: Atualizar TODOS os gestores que possam estar com problemas
-- (Identifique pelo email se necessário)
UPDATE usuarios 
SET tipo_usuario = 'gestor', ativo = TRUE
WHERE email LIKE '%@gestor%' 
   OR email IN ('seu_email_aqui@example.com');

-- OPÇÃO 3: Se você criou um usuário mas ele não tem registro em usuarios
-- Execute isto substituindo os valores:
/*
INSERT INTO usuarios (id, nome, email, tipo_usuario, senha_hash, ativo)
VALUES (
    auth.uid(),
    'Nome do Gestor',
    'email@gestor.com',
    'gestor',
    'hash_gerado_pelo_supabase_auth',
    TRUE
)
ON CONFLICT (id) DO UPDATE
SET tipo_usuario = 'gestor', ativo = TRUE;
*/

-- Verificar se a correção funcionou:
SELECT 
    id,
    nome,
    email,
    tipo_usuario,
    ativo
FROM usuarios
WHERE tipo_usuario IN ('gestor', 'admin');

-- Agora tente novamente:
SELECT count(*) as total_colaboradores FROM vw_colaboradores_completos;
