-- =====================================================
-- FIX: Incluir metodo_pagamento_preferido na View
-- =====================================================

DROP VIEW IF EXISTS vw_colaboradores_completos;

CREATE OR REPLACE VIEW vw_colaboradores_completos AS
SELECT 
    c.id,
    c.usuario_id,
    u.nome,
    u.email,
    u.telefone,
    u.nif,
    c.iban,
    c.nome_titular_banco,
    c.telefone_mbway,
    c.carteira_lightning,
    c.metodo_pagamento_preferido, -- Campo adicionado
    c.status,
    c.limite_total,
    c.limite_disponivel,
    c.taxa_juros,
    c.total_adiantamentos,
    c.data_admissao,
    c.data_registro,
    u.ativo AS usuario_ativo
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id;
