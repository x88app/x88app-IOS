-- Script para diagnosticar e corrigir inconsistências de status do usuário SILVIO LUIZ
-- e de outros colaboradores que possam estar na mesma situação.

-- 1. Verificar o estado atual (apenas leitura)
SELECT 
    u.id as usuario_id, 
    u.nome, 
    u.email, 
    u.ativo as usuario_ativo_bool, 
    c.status as colaborador_status_texto
FROM usuarios u
JOIN colaboradores c ON c.usuario_id = u.id
WHERE u.email = 'silvioluigmj@gmail.com';

-- 2. Correção: Garantir que se o colaborador está 'ativo', o usuário também esteja true
UPDATE usuarios u
SET ativo = true
FROM colaboradores c
WHERE c.usuario_id = u.id
AND c.status = 'ativo'
AND (u.ativo = false OR u.ativo IS NULL);

-- 3. Verificar novamente após a correção
SELECT 
    u.id as usuario_id, 
    u.nome, 
    u.email, 
    u.ativo as usuario_ativo_bool, 
    c.status as colaborador_status_texto
FROM usuarios u
JOIN colaboradores c ON c.usuario_id = u.id
WHERE u.email = 'silvioluigmj@gmail.com';
