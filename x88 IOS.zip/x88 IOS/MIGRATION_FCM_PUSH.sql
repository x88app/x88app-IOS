-- =====================================================
-- MIGRATION: Configurar Firebase Cloud Messaging (FCM)
-- Execute este script no Supabase SQL Editor
-- =====================================================

-- 1. Adicionar coluna fcm_token na tabela colaboradores (se não existir)
ALTER TABLE colaboradores ADD COLUMN IF NOT EXISTS fcm_token TEXT;
ALTER TABLE colaboradores ADD COLUMN IF NOT EXISTS fcm_token_updated_at TIMESTAMPTZ;
ALTER TABLE colaboradores ADD COLUMN IF NOT EXISTS device_platform TEXT;

-- 2. Adicionar coluna colaborador_id na tabela notificacoes (se não existir)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'notificacoes' AND column_name = 'colaborador_id'
    ) THEN
        ALTER TABLE notificacoes ADD COLUMN colaborador_id UUID REFERENCES colaboradores(id) ON DELETE CASCADE;
    END IF;
END $$;

-- 3. Criar função trigger para notificar quando solicitação muda de status
CREATE OR REPLACE FUNCTION notify_solicitacao_status_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_valor NUMERIC;
    v_title TEXT;
    v_body TEXT;
BEGIN
    -- Só notifica se o status mudou
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        
        v_valor := NEW.valor;
        
        -- Define mensagem baseada no novo status
        CASE NEW.status
            WHEN 'aprovado' THEN
                v_title := 'Solicitação Aprovada!';
                v_body := format('Seu adiantamento de %.2f foi aprovado.', v_valor);
            WHEN 'rejeitado' THEN
                v_title := 'Solicitação Rejeitada';
                v_body := format('Seu adiantamento de %.2f foi rejeitado.', v_valor);
            WHEN 'pago' THEN
                v_title := 'Pagamento Realizado!';
                v_body := format('Seu adiantamento de %.2f foi pago.', v_valor);
            WHEN 'cancelado' THEN
                v_title := 'Solicitação Cancelada';
                v_body := format('Seu adiantamento de %.2f foi cancelado.', v_valor);
            ELSE
                RETURN NEW;
        END CASE;
        
        -- Insere notificação na tabela
        INSERT INTO notificacoes (colaborador_id, titulo, mensagem, tipo, lida)
        VALUES (NEW.colaborador_id, v_title, v_body, 'solicitacao', false);
        
    END IF;
    
    RETURN NEW;
END;
$$;

-- 4. Criar trigger na tabela solicitacoes
DROP TRIGGER IF EXISTS trigger_notify_solicitacao_status ON solicitacoes;
CREATE TRIGGER trigger_notify_solicitacao_status
    AFTER UPDATE ON solicitacoes
    FOR EACH ROW
    EXECUTE FUNCTION notify_solicitacao_status_change();

-- 5. RLS para notificações
ALTER TABLE notificacoes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Colaborador ve suas notificacoes" ON notificacoes;
CREATE POLICY "Colaborador ve suas notificacoes" ON notificacoes
    FOR ALL USING (
        colaborador_id IN (
            SELECT id FROM colaboradores WHERE usuario_id = auth.uid()
        )
    );

-- 6. Índices para performance
CREATE INDEX IF NOT EXISTS idx_notificacoes_colaborador ON notificacoes(colaborador_id);
CREATE INDEX IF NOT EXISTS idx_colaboradores_fcm_token ON colaboradores(fcm_token) WHERE fcm_token IS NOT NULL;

SELECT 'Migration FCM Push concluída!' as status;
