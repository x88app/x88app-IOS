-- ============================================================================
-- AGENDAMENTO DE LIMPEZA AUTOMÁTICA DE NOTIFICAÇÕES
-- Descrição: Configura um job CRON para deletar todas as notificações 
--            toda terça-feira à meia-noite (virada de segunda para terça).
-- ============================================================================

-- 1. Habilitar a extensão pg_cron (necessário para agendamento)
--    OBS: Em alguns ambientes gerenciados do Supabase, isso deve ser feito 
--    manualmente no Dashboard em Database > Extensions.
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- 2. Criar função de limpeza
CREATE OR REPLACE FUNCTION limpar_todas_notificacoes_semanal()
RETURNS void AS $$
DECLARE
    count_deleted INTEGER;
BEGIN
    -- Deleta TODAS as notificações da tabela
    DELETE FROM notificacoes;
    
    GET DIAGNOSTICS count_deleted = ROW_COUNT;
    
    -- Opcional: Registrar log na tabela de auditoria (se existir)
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'auditoria') THEN
        INSERT INTO auditoria (acao, tabela, dados_novos, data_acao)
        VALUES ('LIMPEZA_CRON', 'notificacoes', jsonb_build_object('mensagem', 'Limpeza semanal automática realizada', 'registros_deletados', count_deleted), NOW());
    END IF;
    
    RAISE NOTICE 'Limpeza semanal de notificações concluída. % registros removidos.', count_deleted;
END;
$$ LANGUAGE plpgsql;

-- 3. Agendar o job
--    Sintaxe Cron: min hour daymonth month dayweek
--    0 0 * * 2  => 00:00 de Terça-feira (2 = Terça)
--    (Domingo=0, Segunda=1, Terça=2, etc.)

-- Remove o job antigo se existir (de forma segura, sem erro)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'limpeza-semanal-notificacoes') THEN
        PERFORM cron.unschedule('limpeza-semanal-notificacoes');
    END IF;
EXCEPTION WHEN OTHERS THEN
    -- Se ocorrer algum erro na verificação ou remoção (ex: tabela não acessível), segue em frente
    NULL;
END $$;

-- Agenda o novo job
SELECT cron.schedule(
    'limpeza-semanal-notificacoes', -- Nome único do job
    '0 0 * * 2',                    -- Cron: Terça-feira às 00:00
    'SELECT limpar_todas_notificacoes_semanal()'
);

-- Para verificar se foi agendado corretamente:
-- SELECT * FROM cron.job;
