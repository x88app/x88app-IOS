-- ==============================================================================
-- CORREÇÃO: DEFINIR MB WAY COMO PADRÃO PARA TODOS
-- ==============================================================================

-- 1. Atualizar o telefone_mbway com o telefone do cadastro (usuario)
-- Apenas para quem ainda não tem telefone_mbway definido
UPDATE colaboradores c
SET telefone_mbway = u.telefone
FROM usuarios u
WHERE c.usuario_id = u.id
AND (c.telefone_mbway IS NULL OR c.telefone_mbway = '');

-- 2. Definir 'mbway' como método preferido padrão
-- Apenas para quem não tem nenhum método definido ou está como NULL
UPDATE colaboradores
SET metodo_pagamento_preferido = 'mbway'
WHERE metodo_pagamento_preferido IS NULL;

-- 3. Verificar os resultados
SELECT 
    u.nome, 
    c.telefone_mbway, 
    c.metodo_pagamento_preferido 
FROM colaboradores c
JOIN usuarios u ON c.usuario_id = u.id;
