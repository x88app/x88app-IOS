# 🚀 X88 Motorista Parceiro

## Adiantamento na Palma da Mão

---

## 💡 O Problema

| Desafio | Impacto |
|---------|---------|
| Motoristas precisam de dinheiro antes do repasse | Stress financeiro, empréstimos com juros altos |
| Processo manual de solicitação de adiantamentos | Burocracia, demora, papelada |
| Falta de visibilidade do gestor | Dificuldade de controle financeiro |
| Motoristas sem acesso a serviços bancários rápidos | Dependência de terceiros |

---

## ✅ A Solução

**X88 Motorista Parceiro** é um aplicativo móvel que permite aos motoristas parceiros solicitar adiantamentos de forma rápida, segura e transparente.

### Em 3 Passos Simples

```
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│   PASSO 1   │  →   │   PASSO 2   │  →   │   PASSO 3   │
│  Escolher   │      │  Confirmar  │      │   Receber   │
│   Valor     │      │   Dados     │      │  Pagamento  │
└─────────────┘      └─────────────┘      └─────────────┘
```

---

## 📱 Funcionalidades

### Para Motoristas Parceiros

| Funcionalidade | Descrição |
|----------------|-----------|
| 🏠 **Dashboard Inteligente** | Visão geral de solicitações e saldo |
| 💰 **Adiantamentos Rápidos** | Solicite em menos de 1 minuto |
| 📊 **Acompanhamento em Tempo Real** | Veja o status atualizado instantaneamente |
| 💳 **Múltiplos Métodos** | MB Way, IBAN ou Bitcoin (Lightning) |
| 🔔 **Notificações Push** | Alertas quando aprovado ou pago |
| 🌍 **Multi-idioma** | Português (PT) e Português (BR) |

### Para Gestores (App Separado)

| Funcionalidade | Descrição |
|----------------|-----------|
| ✅ **Aprovar/Rejeitar** | Gerencie solicitações facilmente |
| 👥 **Gestão de Colaboradores** | Controle limites e taxas |
| 💼 **Carteira Digital** | Controle de saldo para pagamentos |
| 📈 **Relatórios** | Visão completa das operações |

---

## 🎨 Design Moderno

### Identidade Visual

| Elemento | Especificação |
|----------|---------------|
| **Cor Principal** | Verde #00D749 |
| **Cor Secundária** | Preto #000000 |
| **Cor de Destaque** | Laranja Bitcoin #E69F39 |
| **Fonte** | Inter |
| **Estilo** | Mobile-first, minimalista |

### Temas

- ☀️ **Modo Claro** - Interface limpa e moderna
- 🌙 **Modo Escuro** - Confortável para uso noturno

---

## 💳 Métodos de Pagamento

### MB Way / PIX
- Pagamentos instantâneos
- Sem necessidade de conta bancária
- Disponível 24/7

### IBAN / Conta Bancária
- Transferência tradicional
- Processamento em até 1 dia útil
- Suporte internacional (SWIFT)

### ₿ Bitcoin (Lightning Network)
- Pagamentos em satoshis
- Instantâneo e global
- Taxas mínimas

---

## 📊 Como Funciona

### Fluxo do Motorista Parceiro

```
┌──────────────────────────────────────────────────────────┐
│                                                          │
│   📱 MOTORISTA PARCEIRO                                  │
│   ─────────────────────                                  │
│                                                          │
│   1. Abre o app                                          │
│   2. Clica em "Novo Adiantamento"                        │
│   3. Escolhe valor e método de pagamento                 │
│   4. Confirma e aceita os termos                         │
│   5. Aguarda aprovação do gestor                         │
│   6. Recebe o pagamento!                                 │
│                                                          │
└──────────────────────────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────┐
│                                                          │
│   👔 GESTOR                                              │
│   ───────                                                │
│                                                          │
│   1. Recebe notificação de nova solicitação              │
│   2. Analisa o pedido                                    │
│   3. Aprova ou rejeita                                   │
│   4. Se aprovado, processa o pagamento                   │
│   5. Motorista é notificado automaticamente              │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

### Cálculo de Valores

| Item | Valor |
|------|-------|
| Valor Solicitado | €100,00 |
| Taxa de Serviço | 10% |
| **Motorista Recebe** | **€100,00** |
| **Desconto no Repasse** | **€110,00** |

> O motorista sempre recebe o valor integral solicitado. A taxa é acrescida ao valor que será descontado do próximo repasse.

---

## 🔒 Segurança

| Recurso | Descrição |
|---------|-----------|
| 🔐 **Autenticação Supabase** | Login seguro com tokens JWT |
| 🛡️ **Row Level Security** | Cada usuário só vê seus dados |
| 📱 **Biometria** | Face ID / Touch ID (opcional) |
| 🔔 **Alertas de Login** | Notificação em novos acessos |
| 🗑️ **Exclusão de Conta** | LGPD compliant |

---

## 🌐 Plataformas

| Plataforma | Status | Tecnologia |
|------------|--------|------------|
| 📱 **iOS** | ✅ Disponível | Capacitor |
| 🤖 **Android** | ✅ Disponível | Capacitor |
| 🌐 **Web (PWA)** | ✅ Disponível | React |

### PWA Features

- ✅ Instalável na tela inicial
- ✅ Funciona como app nativo
- ✅ Notificações push
- ✅ Ícone personalizado

---

## 🛠️ Tecnologias

### Frontend
- **React 18** - Interface moderna e reativa
- **TypeScript** - Código seguro e tipado
- **Tailwind CSS** - Design system consistente
- **Vite** - Build ultrarrápido

### Backend
- **Supabase** - Backend as a Service
- **PostgreSQL** - Banco de dados robusto
- **Realtime** - Atualizações instantâneas

### Mobile
- **Capacitor** - Apps nativos iOS/Android
- **PWA** - Progressive Web App

---

## 📈 Benefícios

### Para a Empresa/Frota

| Benefício | Impacto |
|-----------|---------|
| 💰 **Reduz turnover** | Motoristas mais satisfeitos |
| 📊 **Controle financeiro** | Visão clara dos adiantamentos |
| ⏱️ **Economia de tempo** | Processo 100% digital |
| 🏢 **Imagem moderna** | Empresa inovadora |

### Para o Motorista Parceiro

| Benefício | Impacto |
|-----------|---------|
| 💵 **Acesso rápido** | Dinheiro quando precisa |
| 📱 **Conveniência** | Solicita de qualquer lugar |
| 🔍 **Transparência** | Vê taxas e valores claramente |
| 🔒 **Segurança** | Dados protegidos |

---

## 📸 Screenshots

### Tela Principal
```
┌────────────────────────────┐
│  ▓▓▓▓ BANNER ▓▓▓▓▓▓▓▓▓▓▓  │
│  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓  │
├────────────────────────────┤
│                            │
│  ┌────────────────────┐    │
│  │ 💰 Resumo Semanal  │    │
│  │    €150.00         │    │
│  └────────────────────┘    │
│                            │
│  ┌────────────────────┐    │
│  │ 🆕 Novo Adiantam.  │ →  │
│  └────────────────────┘    │
│                            │
│  ┌────────────────────┐    │
│  │ ₿ Receber Satoshi  │ →  │
│  └────────────────────┘    │
│                            │
│  📋 Últimas Solicitações   │
│  ├─ €50.00 ✅ Pago         │
│  ├─ €30.00 ⏳ Pendente     │
│  └─ €20.00 ✅ Aprovado     │
│                            │
├────────────────────────────┤
│  🏠   📋   📊   💼   👤   │
└────────────────────────────┘
```

### Nova Solicitação
```
┌────────────────────────────┐
│  ← Nova Solicitação        │
│     Passo 1 de 2           │
├────────────────────────────┤
│                            │
│  Valor do Adiantamento     │
│  ┌────────────────────┐    │
│  │  €  100.00         │    │
│  └────────────────────┘    │
│                            │
│  Método de Recebimento     │
│                            │
│  ┌────────────────────┐    │
│  │ 📱 MB Way     ✓    │    │
│  │    912 345 678     │    │
│  └────────────────────┘    │
│                            │
│  ┌────────────────────┐    │
│  │ 💳 IBAN            │    │
│  │    PT50...         │    │
│  └────────────────────┘    │
│                            │
│  ┌────────────────────┐    │
│  │ ₿ Satoshi          │    │
│  │    lnurl...        │    │
│  └────────────────────┘    │
│                            │
│  ┌────────────────────┐    │
│  │     Continuar      │    │
│  └────────────────────┘    │
│                            │
└────────────────────────────┘
```

---

## 🚀 Roadmap

### ✅ Fase 1 - MVP (Concluído)
- [x] Autenticação de usuários
- [x] Solicitações de adiantamento
- [x] Aprovação pelo gestor
- [x] Pagamentos MB Way e IBAN
- [x] Notificações push
- [x] Apps iOS e Android

### 🔄 Fase 2 - Em Desenvolvimento
- [x] Pagamentos em Bitcoin (Lightning)
- [x] Multi-idioma (PT-BR / PT-PT)
- [x] Banners promocionais
- [ ] Modo offline

### 📋 Fase 3 - Planejado
- [ ] Relatórios avançados
- [ ] Integração com folha de pagamento
- [ ] API para sistemas externos
- [ ] Dashboard web para gestores

---

## 💼 Modelo de Negócio

| Receita | Descrição |
|---------|-----------|
| **Taxa por transação** | 10% sobre cada adiantamento (configurável) |
| **Licenciamento** | Valor mensal por empresa |
| **Customização** | Branding e integrações personalizadas |

---

## 📞 Contato

| Canal | Informação |
|-------|------------|
| **Website** | x88.pt |
| **Email** | contato@x88.pt |
| **WhatsApp** | +351 912 345 678 |

---

## 📄 Informações Legais

- **Empresa**: X88
- **Versão**: 1.0.0
- **Licença**: Software Proprietário
- **LGPD/RGPD**: Compliant

---

<div align="center">

### 💚 X88 Motorista Parceiro

**Adiantamento moderno, rápido e seguro para motoristas de aplicativo.**

*© 2025 X88 - Todos os direitos reservados*

</div>
