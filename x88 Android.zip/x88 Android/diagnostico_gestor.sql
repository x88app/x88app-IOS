-- =====================================================
-- DIAGNÓSTICO: Verificar por que gestor vê 0 colaboradores
-- =====================================================
-- Execute este script logado como o gestor que está vendo 0

-- 1. Verificar contexto da sessão atual
SELECT 
    auth.role() as papel,
    auth.uid() as meu_id,
    'Verificando se estou autenticado' as info;

-- 2. Verificar se o gestor é reconhecido pelas policies
SELECT 
    EXISTS (
        SELECT 1 FROM usuarios 
        WHERE id = auth.uid() 
        AND tipo_usuario IN ('gestor', 'admin')
    ) AS sou_gestor_visivel,
    'Se FALSE, o problema está aqui!' as diagnóstico;

-- 3. Verificar meus próprios dados
SELECT 
    id,
    nome,
    email,
    tipo_usuario,
    ativo,
    data_registro
FROM usuarios 
WHERE id = auth.uid();

-- 4. Contar TODOS os registros (sem RLS)
-- NOTA: Isso só funciona se você tiver permissões de superuser
-- Caso contrário, pule esta etapa
-- SET session_replication_role = 'replica'; -- Desabilita RLS temporariamente
-- SELECT 'TOTAL REAL COLABORADORES' as info, count(*) FROM colaboradores;
-- SELECT 'TOTAL REAL USUARIOS' as info, count(*) FROM usuarios;
-- SET session_replication_role = 'origin'; -- Reabilita RLS

-- 5. Contar com RLS ativo (o que o gestor deveria ver)
SELECT 'COLABORADORES QUE VEJ0' as info, count(*) FROM colaboradores;
SELECT 'USUARIOS QUE VEJO' as info, count(*) FROM usuarios;
SELECT 'VIEW COMPLETA QUE VEJO' as info, count(*) FROM vw_colaboradores_completos;

-- 6. Ver detalhes dos colaboradores que estou vendo
SELECT * FROM vw_colaboradores_completos;

-- 7. Listar TODOS os usuários por tipo (o que o gestor deveria ver)
SELECT 
    tipo_usuario,
    ativo,
    COUNT(*) as total
FROM usuarios
GROUP BY tipo_usuario, ativo
ORDER BY tipo_usuario, ativo;

-- 8. Ver gestores no sistema
SELECT 
    id,
    nome,
    email,
    tipo_usuario,
    ativo,
    data_registro
FROM usuarios
WHERE tipo_usuario IN ('gestor', 'admin')
ORDER BY data_registro DESC;

-- 9. Ver colaboradores no sistema  
SELECT 
    id,
    nome,
    email,
    tipo_usuario,
    ativo,
    data_registro
FROM usuarios
WHERE tipo_usuario = 'colaborador'
ORDER BY data_registro DESC;

-- =====================================================
-- RESULTADO ESPERADO:
-- =====================================================
-- Se "sou_gestor_visivel" = TRUE:
--   - Você deveria ver TODOS os colaboradores
--   - Se vê 0, o problema está nas policies ou nos dados
--
-- Se "sou_gestor_visivel" = FALSE:
--   - Seu registro em usuarios não existe OU
--   - Seu tipo_usuario não é 'gestor' nem 'admin' OU
--   - Você não está autenticado (auth.uid() é NULL)
--
-- SOLUÇÃO:
-- Execute o script fix_gestor_sessao.sql se necessário
