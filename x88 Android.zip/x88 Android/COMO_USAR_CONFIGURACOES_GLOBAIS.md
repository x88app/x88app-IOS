# Configurações Globais - Guia de Implementação

## O Problema Resolvido

Antes: Cada gestor tinha suas próprias configurações (email_suporte, WhatsApp, etc.) na tabela `usuarios`.  
Agora: **TODAS as contas de gestor compartilham as mesmas configurações** através da tabela `configuracoes_globais`.

## Como Funciona

```
┌─────────────────────────────────────────────────────────────────┐
│                    TABELA: configuracoes_globais                │
│                     (apenas UMA linha existe)                   │
├─────────────────────────────────────────────────────────────────┤
│  email_suporte     │  telefone_suporte  │  whatsapp_suporte    │
│  usar_whatsapp     │  nome_empresa      │  logo_url            │
│  cor_primaria      │  taxa_juros_padrao │  limite_padrao       │
└─────────────────────────────────────────────────────────────────┘
                              ▲
           ┌──────────────────┼──────────────────┐
           │                  │                  │
      ┌────┴────┐        ┌────┴────┐        ┌────┴────┐
      │ Gestor 1│        │ Gestor 2│        │ Gestor 3│
      │ (edita) │        │ (edita) │        │ (edita) │
      └─────────┘        └─────────┘        └─────────┘
                              │
           ┌──────────────────┼──────────────────┐
           │                  │                  │
      ┌────┴────┐        ┌────┴────┐        ┌────┴────┐
      │ Colab A │        │ Colab B │        │ Colab C │
      │  (vê)   │        │  (vê)   │        │  (vê)   │
      └─────────┘        └─────────┘        └─────────┘
```

**Resultado:** Qualquer gestor que alterar o email de suporte, TODOS os colaboradores verão a mudança!

---

## Passo 1: Executar a Migration no Supabase

Acesse o Supabase > SQL Editor e execute o arquivo:

```
MIGRATION_CONFIGURACOES_GLOBAIS.sql
```

Isso irá:
- ✅ Criar a tabela `configuracoes_globais`
- ✅ Migrar dados existentes do primeiro gestor
- ✅ Configurar políticas RLS
- ✅ Habilitar realtime
- ✅ Criar funções auxiliares

---

## Passo 2: Usar no App Gestor

No seu componente de Configurações do Gestor, use o hook:

```tsx
import { useConfiguracoesGlobais } from '../hooks/useConfiguracoesGlobais'

function ConfiguracoesPage() {
  const { config, isLoading, isSaving, updateConfig } = useConfiguracoesGlobais()
  
  const handleSalvar = async () => {
    const sucesso = await updateConfig({
      email_suporte: 'novo@email.com',
      whatsapp_suporte: '+351912345678',
      usar_whatsapp_suporte: true,
      nome_empresa: 'Minha Empresa'
    })
    
    if (sucesso) {
      alert('Configurações salvas!')
    }
  }

  return (
    <div>
      <input 
        value={config.email_suporte || ''} 
        onChange={(e) => /* ... */}
      />
      <button onClick={handleSalvar} disabled={isSaving}>
        Salvar
      </button>
    </div>
  )
}
```

---

## Passo 3: Usar no App Colaborador

No app colaborador, use o hook para **ler** as configurações:

```tsx
import { useConfiguracoesGlobais } from '../hooks/useConfiguracoesGlobais'

function SuportePage() {
  const { 
    config, 
    isLoading, 
    handleContactEmail, 
    handleContactWhatsapp 
  } = useConfiguracoesGlobais()

  if (isLoading) return <Loading />

  return (
    <div>
      <h2>Suporte</h2>
      
      {config.email_suporte && (
        <button onClick={handleContactEmail}>
          📧 {config.email_suporte}
        </button>
      )}
      
      {config.whatsapp_suporte && config.usar_whatsapp_suporte && (
        <button onClick={handleContactWhatsapp}>
          💬 WhatsApp
        </button>
      )}
    </div>
  )
}
```

---

## Passo 4: Substituir useGestorEmail (Opcional)

O hook `useGestorEmail` já foi atualizado para buscar da tabela global.  
Mas você pode migrar gradualmente para usar `useConfiguracoesGlobais` que é mais completo.

**Antes:**
```tsx
const { gestorEmail, handleContactEmail } = useGestorEmail()
```

**Depois:**
```tsx
const { config, handleContactEmail } = useConfiguracoesGlobais()
const gestorEmail = config.email_suporte
```

---

## Campos Disponíveis

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `email_suporte` | string | Email de suporte exibido para colaboradores |
| `telefone_suporte` | string | Telefone de suporte |
| `whatsapp_suporte` | string | Número WhatsApp (pode ser diferente do telefone) |
| `usar_whatsapp_suporte` | boolean | Se deve usar WhatsApp como canal principal |
| `nome_empresa` | string | Nome da empresa |
| `logo_url` | string | URL do logo da empresa |
| `cor_primaria` | string | Cor principal da marca (hex) |
| `taxa_juros_padrao` | number | Taxa de juros padrão para novos colaboradores |
| `limite_padrao` | number | Limite de adiantamento padrão |

---

## Realtime (Atualização Automática)

Os hooks já estão configurados para receber atualizações em tempo real.  
Se o Gestor 1 alterar o email, o Gestor 2 e todos os colaboradores verão a mudança automaticamente!

---

## Resumo

✅ **Uma tabela global** = configurações unificadas  
✅ **Qualquer gestor edita** = todos veem a mudança  
✅ **Realtime habilitado** = atualizações instantâneas  
✅ **Hooks prontos** = fácil de implementar  
