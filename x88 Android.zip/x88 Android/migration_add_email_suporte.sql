-- =====================================================
-- MIGRATION: Adicionar campo email_suporte na tabela usuarios
-- Descrição: Permite que gestores configurem um e-mail de suporte
--            que será exibido no app do colaborador
-- =====================================================

-- Adicionar coluna email_suporte na tabela usuarios
ALTER TABLE usuarios 
ADD COLUMN IF NOT EXISTS email_suporte VARCHAR(255);

-- Comentário explicativo
COMMENT ON COLUMN usuarios.email_suporte IS 'E-mail de suporte configurado pelo gestor, exibido no app do colaborador';
