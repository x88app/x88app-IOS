# 🔧 SOLUÇÃO: Gestor Ver TODOS os Colaboradores

## 📋 Problema Identificado

O app do gestor está mostrando **0 colaboradores** quando deveria mostrar **2** (ou quantos existirem no total).

### Causa Raiz

As RLS policies no Supabase têm uma **dependência circular**:
- A policy "Gestores podem ver todos usuários" faz uma subquery na própria tabela `usuarios`
- Isso pode falhar dependendo da ordem de avaliação das policies
- Resultado: o gestor não consegue "se reconhecer" como gestor, então as policies bloqueiam tudo

## ✅ Solução em 3 Passos

### Passo 1: Diagnóstico

No **Supabase SQL Editor**, execute (logado como gestor):

```sql
-- Verifique se você está autenticado
SELECT auth.uid() as meu_id;

-- Verifique se é reconhecido como gestor
SELECT EXISTS (
    SELECT 1 FROM usuarios 
    WHERE id = auth.uid() 
    AND tipo_usuario IN ('gestor', 'admin')
) AS sou_gestor_reconhecido;
```

**Resultado esperado:**
- `meu_id`: deve retornar um UUID
- `sou_gestor_reconhecido`: deve ser `TRUE`

Se `sou_gestor_reconhecido` = `FALSE`, execute o Passo 2.

### Passo 2: Correção das Policies

Execute o script **FIX_GESTOR_VER_TODOS.sql** no Supabase SQL Editor:

```sql
-- PASSO 1: Remover policies problemáticas
DROP POLICY IF EXISTS "Colaboradores podem ver próprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Gestores podem ver todos usuários" ON usuarios;

-- PASSO 2: Criar policies corrigidas

-- Qualquer usuário vê seu próprio perfil
CREATE POLICY "Usuarios veem proprio perfil"
    ON usuarios FOR SELECT
    USING (auth.uid() = id);

-- Gestores veem TODOS os usuários
CREATE POLICY "Gestores veem todos usuarios"
    ON usuarios FOR SELECT
    USING (
        (
            SELECT tipo_usuario 
            FROM usuarios 
            WHERE id = auth.uid()
        ) IN ('gestor', 'admin')
    );
```

### Passo 3: Verificação

Ainda no SQL Editor (logado como gestor):

```sql
-- Deve retornar TRUE agora
SELECT EXISTS (
    SELECT 1 FROM usuarios 
    WHERE id = auth.uid() 
    AND tipo_usuario IN ('gestor', 'admin')
) AS sou_gestor_reconhecido;

-- Deve retornar a contagem TOTAL de colaboradores
SELECT COUNT(*) as total_colaboradores FROM vw_colaboradores_completos;

-- Deve retornar TODOS os usuários
SELECT 
    tipo_usuario,
    COUNT(*) as total
FROM usuarios
GROUP BY tipo_usuario;
```

**Resultado esperado:**
- `sou_gestor_reconhecido`: `TRUE`
- `total_colaboradores`: `2` (ou o número real de colaboradores)
- Deve listar gestores e colaboradores separadamente

### Passo 4: Teste no App

1. Faça logout do app do gestor
2. Faça login novamente
3. Verifique a tela inicial (Home)
4. O card "Colaboradores" deve mostrar o número correto

## 🎯 Como Funciona Agora

### Para Gestores
✅ **TODOS** os gestores veem **TODOS** os colaboradores  
✅ Não importa qual gestor está logado  
✅ Se existem 5 colaboradores, TODOS os gestores veem 5

### Para Colaboradores
✅ Cada colaborador vê apenas seus próprios dados  
✅ Colaborador A não vê os dados do Colaborador B

## 🔍 Troubleshooting

### Se ainda mostrar 0 colaboradores:

#### 1. Verifique se o gestor existe na tabela usuarios

```sql
SELECT * FROM usuarios WHERE email = 'seu_email@gestor.com';
```

Se não retornar nada, o usuário não foi criado corretamente.

#### 2. Verifique se o tipo_usuario está correto

```sql
SELECT id, nome, email, tipo_usuario 
FROM usuarios 
WHERE id = auth.uid();
```

Se `tipo_usuario` não for `'gestor'` ou `'admin'`, corrija:

```sql
UPDATE usuarios 
SET tipo_usuario = 'gestor', ativo = TRUE
WHERE id = auth.uid();
```

#### 3. Verifique se há colaboradores reais

```sql
-- Como superuser ou com RLS desabilitado temporariamente
SELECT COUNT(*) FROM colaboradores;
```

#### 4. Verifique as policies ativas

```sql
SELECT 
    schemaname, 
    tablename, 
    policyname, 
    cmd
FROM pg_policies
WHERE tablename IN ('usuarios', 'colaboradores')
ORDER BY tablename, policyname;
```

## 📊 Arquitetura da Solução

```
┌─────────────────────────────────────────────┐
│         APP GESTOR (Frontend)               │
│  ColaboradoresContext.tsx                   │
│  - Faz query: vw_colaboradores_completos    │
└─────────────────┬───────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────┐
│         SUPABASE (Backend)                  │
│                                             │
│  View: vw_colaboradores_completos           │
│    │                                        │
│    ├─► JOIN colaboradores ◄─┐              │
│    │         (RLS: gestor vê tudo)         │
│    │                         │              │
│    └─► JOIN usuarios    ─────┘              │
│              (RLS: gestor vê tudo)          │
│                                             │
│  Policy: "Gestores veem todos usuarios"    │
│  - Verifica: tipo_usuario IN ('gestor')    │
│  - Permite: SELECT em TODAS as linhas      │
│                                             │
│  Policy: "Colaboradores veem próprios dados"│
│  - Verifica: usuario_id = auth.uid()       │
│    OU gestor vê tudo                       │
└─────────────────────────────────────────────┘
```

## ✅ Checklist Final

- [ ] Executei `FIX_GESTOR_VER_TODOS.sql`
- [ ] `sou_gestor_reconhecido` retorna `TRUE`
- [ ] `SELECT COUNT(*) FROM vw_colaboradores_completos` retorna o número correto
- [ ] Fiz logout e login no app do gestor
- [ ] O app mostra o número correto de colaboradores

## 📝 Notas Importantes

1. **Todos os gestores veem tudo**: Isso é o comportamento esperado
2. **Colaboradores não veem outros colaboradores**: Cada um vê apenas seus dados
3. **A policy usa subquery**: É necessário para verificar o tipo_usuario
4. **Não há gestor "dono"**: Não existe conceito de gestor A vs gestor B vendo coisas diferentes

## 🚀 Próximos Passos (Opcional)

Se você quiser melhorar a performance e evitar subqueries nas policies, pode usar **JWT claims**:

1. Adicionar `tipo_usuario` ao `app_metadata` do JWT
2. Modificar policies para usar `auth.jwt()`
3. Eliminar subqueries e melhorar performance

Mas isso é opcional - a solução atual funciona perfeitamente!
