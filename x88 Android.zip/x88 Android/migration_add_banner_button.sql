-- =====================================================
-- MIGRAÇÃO: Adicionar campos de botão nos banners/cards
-- Data: 2025-01-06
-- Descrição: Adiciona nome_botao, link_botao e usar_whatsapp
-- =====================================================

-- Adiciona campo para o nome do botão (ex: "Assine Já", "Fale Conosco")
ALTER TABLE banners ADD COLUMN IF NOT EXISTS nome_botao VARCHAR(100);

-- Adiciona campo para o link do botão
ALTER TABLE banners ADD COLUMN IF NOT EXISTS link_botao TEXT;

-- Adiciona campo para indicar se deve abrir WhatsApp ao invés do link
ALTER TABLE banners ADD COLUMN IF NOT EXISTS usar_whatsapp BOOLEAN DEFAULT FALSE;

-- Comentários
COMMENT ON COLUMN banners.nome_botao IS 'Texto exibido no botão do card (ex: Assine Já, Fale Conosco)';
COMMENT ON COLUMN banners.link_botao IS 'URL para onde o botão redireciona';
COMMENT ON COLUMN banners.usar_whatsapp IS 'Se true, abre WhatsApp padrão ao invés do link_botao';
