-- =====================================================
-- CORRIGIR TODAS AS PERMISSÕES PARA GESTORES
-- Script completo para permitir acesso total aos gestores
-- =====================================================

-- =====================================================
-- 1. CRIAR FUNÇÃO AUXILIAR (evita recursão)
-- =====================================================

CREATE OR REPLACE FUNCTION is_gestor()
RETURNS BOOLEAN AS $$
DECLARE
    user_type TEXT;
BEGIN
    SELECT tipo_usuario INTO user_type
    FROM usuarios
    WHERE id = auth.uid()
    LIMIT 1;
    
    RETURN user_type = 'gestor';
EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- =====================================================
-- 2. REMOVER TODAS AS POLÍTICAS EXISTENTES
-- =====================================================

-- Políticas de usuarios
DROP POLICY IF EXISTS "Gestores veem todos usuários" ON usuarios;
DROP POLICY IF EXISTS "Usuários veem próprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Usuários atualizam próprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Permitir inserção de novos usuários" ON usuarios;

-- Políticas de colaboradores
DROP POLICY IF EXISTS "Gestores veem todos colaboradores" ON colaboradores;
DROP POLICY IF EXISTS "Gestores atualizam colaboradores" ON colaboradores;
DROP POLICY IF EXISTS "Usuários veem próprios dados de colaborador" ON colaboradores;
DROP POLICY IF EXISTS "Usuários atualizam próprios dados de colaborador" ON colaboradores;
DROP POLICY IF EXISTS "Permitir inserção de colaboradores" ON colaboradores;

-- Políticas de solicitações
DROP POLICY IF EXISTS "Gestores veem todas solicitações" ON solicitacoes;
DROP POLICY IF EXISTS "Gestores atualizam solicitações" ON solicitacoes;
DROP POLICY IF EXISTS "Colaboradores veem próprias solicitações" ON solicitacoes;
DROP POLICY IF EXISTS "Colaboradores criam solicitações" ON solicitacoes;
DROP POLICY IF EXISTS "Colaboradores atualizam próprias solicitações pendentes" ON solicitacoes;

-- Políticas de notificações
DROP POLICY IF EXISTS "Usuários veem próprias notificações" ON notificacoes;
DROP POLICY IF EXISTS "Sistema insere notificações" ON notificacoes;
DROP POLICY IF EXISTS "Usuários atualizam próprias notificações" ON notificacoes;
DROP POLICY IF EXISTS "Usuários deletam próprias notificações" ON notificacoes;

-- Políticas de carteira_gestor
DROP POLICY IF EXISTS "Gestores veem própria carteira" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores atualizam própria carteira" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores podem inserir carteira" ON carteira_gestor;

-- Políticas de transacoes_carteira
DROP POLICY IF EXISTS "Gestores veem próprias transações" ON transacoes_carteira;
DROP POLICY IF EXISTS "Sistema insere transações" ON transacoes_carteira;

-- Políticas de banners
DROP POLICY IF EXISTS "Todos veem banners ativos" ON banners;
DROP POLICY IF EXISTS "Gestores gerenciam banners" ON banners;

-- Políticas de cards_anuncio
DROP POLICY IF EXISTS "Todos veem cards ativos" ON cards_anuncio;
DROP POLICY IF EXISTS "Gestores gerenciam cards" ON cards_anuncio;

-- =====================================================
-- 3. CRIAR NOVAS POLÍTICAS PARA GESTORES
-- =====================================================

-- USUARIOS
CREATE POLICY "Gestores veem todos usuários"
    ON usuarios FOR SELECT
    USING (is_gestor() OR auth.uid() = id);

CREATE POLICY "Usuários atualizam próprio perfil"
    ON usuarios FOR UPDATE
    USING (auth.uid() = id);

CREATE POLICY "Permitir registro de usuários"
    ON usuarios FOR INSERT
    WITH CHECK (true);

-- COLABORADORES
CREATE POLICY "Gestores veem todos colaboradores"
    ON colaboradores FOR SELECT
    USING (is_gestor() OR usuario_id = auth.uid());

CREATE POLICY "Gestores atualizam todos colaboradores"
    ON colaboradores FOR UPDATE
    USING (is_gestor() OR usuario_id = auth.uid());

CREATE POLICY "Permitir criação de colaboradores"
    ON colaboradores FOR INSERT
    WITH CHECK (true);

-- SOLICITAÇÕES
CREATE POLICY "Gestores veem todas solicitações"
    ON solicitacoes FOR SELECT
    USING (
        is_gestor() 
        OR 
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE colaboradores.id = solicitacoes.colaborador_id 
            AND colaboradores.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Gestores atualizam todas solicitações"
    ON solicitacoes FOR UPDATE
    USING (
        is_gestor() 
        OR 
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE colaboradores.id = solicitacoes.colaborador_id 
            AND colaboradores.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Colaboradores criam solicitações"
    ON solicitacoes FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE colaboradores.id = colaborador_id 
            AND colaboradores.usuario_id = auth.uid()
        )
    );

-- NOTIFICAÇÕES
CREATE POLICY "Usuários veem próprias notificações"
    ON notificacoes FOR SELECT
    USING (usuario_id = auth.uid());

CREATE POLICY "Sistema cria notificações"
    ON notificacoes FOR INSERT
    WITH CHECK (true);

CREATE POLICY "Usuários atualizam notificações"
    ON notificacoes FOR UPDATE
    USING (usuario_id = auth.uid());

CREATE POLICY "Usuários deletam notificações"
    ON notificacoes FOR DELETE
    USING (usuario_id = auth.uid());

-- CARTEIRA GESTOR
CREATE POLICY "Gestores veem própria carteira"
    ON carteira_gestor FOR SELECT
    USING (gestor_id = auth.uid() OR is_gestor());

CREATE POLICY "Gestores atualizam própria carteira"
    ON carteira_gestor FOR UPDATE
    USING (gestor_id = auth.uid());

CREATE POLICY "Gestores criam carteira"
    ON carteira_gestor FOR INSERT
    WITH CHECK (gestor_id = auth.uid());

-- TRANSAÇÕES CARTEIRA
CREATE POLICY "Gestores veem transações da carteira"
    ON transacoes_carteira FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM carteira_gestor 
            WHERE carteira_gestor.id = transacoes_carteira.carteira_id 
            AND carteira_gestor.gestor_id = auth.uid()
        )
    );

CREATE POLICY "Sistema insere transações"
    ON transacoes_carteira FOR INSERT
    WITH CHECK (true);

-- BANNERS
CREATE POLICY "Todos veem banners ativos"
    ON banners FOR SELECT
    USING (ativo = true OR is_gestor());

CREATE POLICY "Gestores gerenciam banners"
    ON banners FOR ALL
    USING (is_gestor())
    WITH CHECK (is_gestor());

-- CARDS ANÚNCIO
CREATE POLICY "Todos veem cards ativos"
    ON cards_anuncio FOR SELECT
    USING (ativo = true OR is_gestor());

CREATE POLICY "Gestores gerenciam cards"
    ON cards_anuncio FOR ALL
    USING (is_gestor())
    WITH CHECK (is_gestor());

-- =====================================================
-- 4. VERIFICAR SE O RLS ESTÁ ATIVADO
-- =====================================================

ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE colaboradores ENABLE ROW LEVEL SECURITY;
ALTER TABLE solicitacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE notificacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE carteira_gestor ENABLE ROW LEVEL SECURITY;
ALTER TABLE transacoes_carteira ENABLE ROW LEVEL SECURITY;
ALTER TABLE banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE cards_anuncio ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- 5. TESTAR A FUNÇÃO
-- =====================================================

DO $$
DECLARE
    total_usuarios INTEGER;
    total_colaboradores INTEGER;
    total_solicitacoes INTEGER;
BEGIN
    -- Contar registros
    SELECT COUNT(*) INTO total_usuarios FROM usuarios;
    SELECT COUNT(*) INTO total_colaboradores FROM colaboradores;
    SELECT COUNT(*) INTO total_solicitacoes FROM solicitacoes;
    
    RAISE NOTICE '========================================';
    RAISE NOTICE '✅ PERMISSÕES CONFIGURADAS COM SUCESSO!';
    RAISE NOTICE '========================================';
    RAISE NOTICE 'Total de usuários: %', total_usuarios;
    RAISE NOTICE 'Total de colaboradores: %', total_colaboradores;
    RAISE NOTICE 'Total de solicitações: %', total_solicitacoes;
    RAISE NOTICE '========================================';
    RAISE NOTICE 'Gestores agora podem:';
    RAISE NOTICE '  ✓ Ver TODOS os usuários';
    RAISE NOTICE '  ✓ Ver TODOS os colaboradores';
    RAISE NOTICE '  ✓ Ver TODAS as solicitações';
    RAISE NOTICE '  ✓ Atualizar solicitações';
    RAISE NOTICE '  ✓ Gerenciar banners e cards';
    RAISE NOTICE '  ✓ Ver transações da carteira';
    RAISE NOTICE '========================================';
END $$;
