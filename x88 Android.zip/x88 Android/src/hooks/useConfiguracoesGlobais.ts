import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

export interface ConfiguracoesGlobais {
  email_suporte: string | null
  telefone_suporte: string | null
  whatsapp_suporte: string | null
  usar_whatsapp_suporte: boolean
  nome_empresa: string | null
  logo_url: string | null
  cor_primaria: string
}

const defaultConfig: ConfiguracoesGlobais = {
  email_suporte: null,
  telefone_suporte: null,
  whatsapp_suporte: null,
  usar_whatsapp_suporte: false,
  nome_empresa: null,
  logo_url: null,
  cor_primaria: '#22c55e'
}

let cachedConfig: ConfiguracoesGlobais | null = null
let isFetching = false
let fetchPromise: Promise<ConfiguracoesGlobais> | null = null

const fetchConfigFromDB = async (): Promise<ConfiguracoesGlobais> => {
  try {
    const { data, error } = await supabase
      .from('configuracoes_globais')
      .select('*')
      .limit(1)
      .maybeSingle()

    if (error) {
      console.error('Erro ao buscar configurações globais:', error)
      return defaultConfig
    }

    if (data) {
      return {
        email_suporte: data.email_suporte,
        telefone_suporte: data.telefone_suporte,
        whatsapp_suporte: data.whatsapp_suporte,
        usar_whatsapp_suporte: data.usar_whatsapp_suporte || false,
        nome_empresa: data.nome_empresa,
        logo_url: data.logo_url,
        cor_primaria: data.cor_primaria || '#22c55e'
      }
    }

    return defaultConfig
  } catch (error) {
    console.error('Erro ao buscar configurações globais:', error)
    return defaultConfig
  }
}

export const useConfiguracoesGlobais = () => {
  const [config, setConfig] = useState<ConfiguracoesGlobais>(cachedConfig || defaultConfig)
  const [isLoading, setIsLoading] = useState(!cachedConfig)

  useEffect(() => {
    if (cachedConfig) {
      setConfig(cachedConfig)
      setIsLoading(false)
      return
    }

    if (isFetching && fetchPromise) {
      fetchPromise.then(data => {
        setConfig(data)
        setIsLoading(false)
      })
      return
    }

    isFetching = true
    setIsLoading(true)
    fetchPromise = fetchConfigFromDB()
    
    fetchPromise.then(data => {
      cachedConfig = data
      isFetching = false
      setConfig(data)
      setIsLoading(false)
    })
  }, [])

  // Subscrever mudanças em tempo real
  useEffect(() => {
    const channel = supabase
      .channel('configuracoes_globais_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'configuracoes_globais' },
        (payload) => {
          console.log('Configurações globais atualizadas:', payload)
          if (payload.new) {
            const newConfig = payload.new as any
            const updatedConfig: ConfiguracoesGlobais = {
              email_suporte: newConfig.email_suporte,
              telefone_suporte: newConfig.telefone_suporte,
              whatsapp_suporte: newConfig.whatsapp_suporte,
              usar_whatsapp_suporte: newConfig.usar_whatsapp_suporte || false,
              nome_empresa: newConfig.nome_empresa,
              logo_url: newConfig.logo_url,
              cor_primaria: newConfig.cor_primaria || '#22c55e'
            }
            cachedConfig = updatedConfig
            setConfig(updatedConfig)
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  const handleContactEmail = () => {
    if (config.email_suporte) {
      window.open(`mailto:${config.email_suporte}`, '_blank')
    }
  }

  const handleContactWhatsapp = () => {
    const numero = config.whatsapp_suporte || config.telefone_suporte
    if (numero) {
      const numeroLimpo = numero.replace(/\D/g, '')
      window.open(`https://wa.me/${numeroLimpo}`, '_blank')
    }
  }

  const handleContactPhone = () => {
    if (config.telefone_suporte) {
      window.open(`tel:${config.telefone_suporte}`, '_blank')
    }
  }

  return { 
    config, 
    isLoading,
    handleContactEmail, 
    handleContactWhatsapp,
    handleContactPhone
  }
}

// Função para invalidar cache (usar após atualizações)
export const invalidateConfigCache = () => {
  cachedConfig = null
  isFetching = false
  fetchPromise = null
}
