import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

const VAPID_PUBLIC_KEY = 'BFltCIRi-zRJJBRhmm-ZeVNmXAL_n724JUclU9b8OMbxmWU8DiMfq5ftEUj75OjNSyyP9kJID1PW5QTGIjOf0RA';

export const useWebPush = () => {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<PushSubscription | null>(null);

  useEffect(() => {
    if (!user) return;

    const registerPush = async () => {
      try {
        // 1. Verifica suporte
        if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
          console.log('Push Notifications não suportadas neste navegador');
          return;
        }

        // 2. Aguarda o Service Worker estar pronto
        const registration = await navigator.serviceWorker.ready;

        // 3. Verifica se já existe inscrição
        let sub = await registration.pushManager.getSubscription();

        // 4. Se não existe, cria uma nova
        if (!sub) {
          sub = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
          });
        }

        setSubscription(sub);

        // 5. Salva no banco de dados (se mudou ou é novo)
        if (sub) {
          // Serializa para salvar no DB
          const subJson = JSON.parse(JSON.stringify(sub));
          
          const { error } = await supabase
            .from('usuarios')
            .update({ web_push_subscription: subJson })
            .eq('id', user.id);

          if (error) console.error('Erro ao salvar inscrição Web Push:', error);
          else console.log('Inscrição Web Push salva com sucesso!');
        }

      } catch (error) {
        console.error('Erro ao registrar Web Push:', error);
      }
    };

    registerPush();
  }, [user]);

  return { subscription };
};

// Utilitário para converter a chave VAPID
function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
