import { useState, useCallback, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  isLoading?: boolean
}

const STORAGE_KEY_PREFIX = 'x88_chat_history_'
const MAX_MESSAGES = 50

export function useChat() {
  const { user } = useAuth()
  
  // Chave única por usuário
  const getStorageKey = useCallback(() => {
    return user?.id ? `${STORAGE_KEY_PREFIX}${user.id}` : null
  }, [user?.id])

  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Carregar mensagens quando o usuário mudar
  useEffect(() => {
    const storageKey = getStorageKey()
    if (!storageKey) {
      setMessages([])
      return
    }
    
    try {
      const stored = localStorage.getItem(storageKey)
      if (stored) {
        const parsed = JSON.parse(stored)
        setMessages(parsed.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        })))
      } else {
        setMessages([])
      }
    } catch (e) {
      console.error('Erro ao carregar histórico do chat:', e)
      setMessages([])
    }
  }, [getStorageKey])

  const saveMessages = useCallback((msgs: ChatMessage[]) => {
    const storageKey = getStorageKey()
    if (!storageKey) return
    
    try {
      const toStore = msgs.slice(-MAX_MESSAGES).map(msg => ({
        ...msg,
        timestamp: msg.timestamp.toISOString()
      }))
      localStorage.setItem(storageKey, JSON.stringify(toStore))
    } catch (e) {
      console.error('Erro ao salvar histórico:', e)
    }
  }, [getStorageKey])

  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim() || isLoading) return

    setError(null)
    
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: content.trim(),
      timestamp: new Date()
    }

    const loadingMessage: ChatMessage = {
      id: `loading-${Date.now()}`,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isLoading: true
    }

    setMessages(prev => {
      const updated = [...prev, userMessage, loadingMessage]
      return updated
    })
    setIsLoading(true)

    try {
      // Preparar histórico para enviar (últimas 10 mensagens para contexto)
      const historyForApi = messages
        .slice(-10)
        .filter(m => !m.isLoading)
        .map(m => ({
          role: m.role,
          content: m.content
        }))
      
      historyForApi.push({ role: 'user', content: content.trim() })

      const { data, error: fnError } = await supabase.functions.invoke('chat-ai', {
        body: {
          messages: historyForApi,
          userId: user?.id
        }
      })

      if (fnError) throw fnError
      if (!data.success) throw new Error(data.error)

      // Simular delay de digitação baseado no tamanho da resposta
      // Uma pessoa digita ~40 palavras/min = ~200 chars/min = ~3.3 chars/segundo
      // Vamos usar ~25 chars/segundo para parecer mais natural
      const responseLength = data.response?.length || 0
      const baseDelay = 1500 // 1.5s mínimo
      const charDelay = responseLength * 40 // ~40ms por caractere
      const typingDelay = Math.min(baseDelay + charDelay, 12000) // Entre 1.5s e 12s
      await new Promise(resolve => setTimeout(resolve, typingDelay))

      const assistantMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.response,
        timestamp: new Date()
      }

      setMessages(prev => {
        const updated = prev
          .filter(m => !m.isLoading)
          .concat(assistantMessage)
        saveMessages(updated)
        return updated
      })

    } catch (err: any) {
      console.error('Erro ao enviar mensagem:', err)
      setError(err.message || 'Erro ao processar mensagem')
      
      setMessages(prev => {
        const updated = prev.filter(m => !m.isLoading)
        const errorMessage: ChatMessage = {
          id: `error-${Date.now()}`,
          role: 'assistant',
          content: 'Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente.',
          timestamp: new Date()
        }
        const withError = [...updated, errorMessage]
        saveMessages(withError)
        return withError
      })
    } finally {
      setIsLoading(false)
    }
  }, [messages, isLoading, user, saveMessages])

  const clearHistory = useCallback(() => {
    setMessages([])
    const storageKey = getStorageKey()
    if (storageKey) {
      localStorage.removeItem(storageKey)
    }
  }, [getStorageKey])

  return {
    messages,
    isLoading,
    error,
    sendMessage,
    clearHistory
  }
}
