import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

let cachedPhone: string | null = null
let isFetching = false
let fetchPromise: Promise<string | null> | null = null

const fetchGestorPhoneFromDB = async (): Promise<string | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return null

    const { data: colaboradorData } = await supabase
      .from('colaboradores')
      .select('gestor_id')
      .eq('usuario_id', user.id)
      .single()

    if (colaboradorData?.gestor_id) {
      const { data: gestorData } = await supabase
        .from('usuarios')
        .select('telefone')
        .eq('id', colaboradorData.gestor_id)
        .single()

      if (gestorData?.telefone) {
        return gestorData.telefone
      }
    }

    const { data: adminData } = await supabase
      .from('usuarios')
      .select('telefone')
      .eq('tipo_usuario', 'gestor')
      .eq('ativo', true)
      .limit(1)
      .maybeSingle()

    return adminData?.telefone || null
  } catch (error) {
    console.error('Erro ao buscar telefone do gestor:', error)
    return null
  }
}

export const useGestorPhone = () => {
  const [gestorPhone, setGestorPhone] = useState<string | null>(cachedPhone)

  useEffect(() => {
    if (cachedPhone) {
      setGestorPhone(cachedPhone)
      return
    }

    if (isFetching && fetchPromise) {
      fetchPromise.then(phone => {
        setGestorPhone(phone)
      })
      return
    }

    isFetching = true
    fetchPromise = fetchGestorPhoneFromDB()
    
    fetchPromise.then(phone => {
      cachedPhone = phone
      isFetching = false
      setGestorPhone(phone)
    })
  }, [])

  const handleContactSupport = () => {
    if (gestorPhone) {
      const cleanPhone = gestorPhone.replace(/\D/g, '')
      window.open(`https://wa.me/${cleanPhone}`, '_blank')
    }
  }

  return { gestorPhone, handleContactSupport }
}
