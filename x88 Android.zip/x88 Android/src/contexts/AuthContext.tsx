import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { supabase } from '../lib/supabase'
import { preloadImages } from '../lib/imageCache'

interface User {
  id: string
  name: string
  email: string
  phone: string
  nif: string
  interestRate: number
  status: 'ativo' | 'inativo' | 'pendente'
  avatarUrl: string | null
  bankDetails: {
    iban: string
    bankHolderName: string
    swiftBic: string
    mbwayPhone: string
    preferredMethod: string
    wallet: string
  }
  preferences: {
    notifications: {
      email: boolean
      push: boolean
      sms: boolean
      types: {
        approved: boolean
        rejected: boolean
        payment: boolean
        promotions: boolean
      }
      sound: boolean
    }
    security: {
      twoFactor: boolean
      biometrics: boolean
      loginNotify: boolean
    }
  }
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  register: (name: string, email: string, phone: string, nif: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => void
  updateBankDetails: (bankDetails: User['bankDetails']) => Promise<{ success: boolean; error?: string }>
  updatePersonalData: (data: Partial<Pick<User, 'name' | 'email' | 'phone' | 'nif'>>) => Promise<{ success: boolean; error?: string }>
  updatePreferences: (preferences: Partial<User['preferences']>) => Promise<{ success: boolean; error?: string }>
  updatePassword: (newPassword: string) => Promise<{ success: boolean; error?: string }>
  updateAvatar: (file: File | null) => Promise<{ success: boolean; url?: string; error?: string }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [hasInitialized, setHasInitialized] = useState(false)

  useEffect(() => {
    // Só faz a verificação inicial uma vez
    if (!hasInitialized) {
      checkUser()
      setHasInitialized(true)
    }

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT') {
        setUser(null)
        setIsLoading(false)
      } else if (session?.user && event === 'SIGNED_IN') {
        // Só carrega dados em login explícito, não em INITIAL_SESSION
        loadUserData(session.user.id).catch(error => {
          console.error('Erro ao carregar dados no AuthStateChange:', error)
        })
      } else if (event === 'TOKEN_REFRESHED' || event === 'INITIAL_SESSION') {
        // Não recarregar dados no refresh do token ou sessão inicial
        // checkUser já cuida da sessão inicial
      }
    })

    return () => subscription.unsubscribe()
  }, [hasInitialized])

  // Monitorar mudanças de status em tempo real
  useEffect(() => {
    if (!user) return

    const channel = supabase
      .channel('status-check')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'colaboradores',
          filter: `usuario_id=eq.${user.id}`
        },
        async (payload) => {
          if (payload.new.status === 'inativo') {
            await logout()
            window.location.href = '/auth/login'
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [user])

  const checkUser = async () => {
    try {
      // Timeout de segurança para não travar na tela de carregamento
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 10000))
      
      const sessionPromise = async () => {
        const { data: { session } } = await supabase.auth.getSession()
        if (session?.user) {
          await loadUserData(session.user.id)
        }
      }

      await Promise.race([sessionPromise(), timeoutPromise])
    } catch (error) {
      console.error('Erro ao verificar usuário:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const loadUserData = async (userId: string) => {
    try {
      const { data: userData, error: userError } = await supabase
        .from('usuarios')
        .select('*')
        .eq('id', userId)
        .single()

      if (userError) throw userError

      const { data: colaboradorData, error: colaboradorError } = await supabase
        .from('colaboradores')
        .select('*')
        .eq('usuario_id', userId)
        .single()

      if (colaboradorError) {
        console.log('Usuário não é colaborador ou dados ainda não criados')
      }

      if (colaboradorData?.status === 'inativo') {
        let errorMessage = 'Conta inativa. Entre em contato com o suporte.'

        try {
          // Buscar WhatsApp global das configurações
          const { data: configGlobal } = await supabase
            .from('configuracoes_globais')
            .select('whatsapp_suporte')
            .limit(1)
            .maybeSingle()

          if (configGlobal?.whatsapp_suporte) {
            errorMessage += `|WHATSAPP:${configGlobal.whatsapp_suporte}`
          }
        } catch (err) {
          console.error('Erro ao buscar WhatsApp global:', err)
        }

        await supabase.auth.signOut()
        setUser(null)
        throw new Error(errorMessage)
      }

      const mappedUser: User = {
        id: userData.id,
        name: userData.nome,
        email: userData.email,
        phone: userData.telefone,
        nif: userData.nif,
        interestRate: colaboradorData?.taxa_juros || 10,
        status: colaboradorData?.status || 'pendente',
        avatarUrl: userData.foto_perfil || null,
        bankDetails: {
          iban: colaboradorData?.iban || '',
          bankHolderName: colaboradorData?.nome_titular_banco || userData.nome,
          swiftBic: colaboradorData?.swift_bic || '',
          mbwayPhone: colaboradorData?.telefone_mbway || userData.telefone,
          preferredMethod: colaboradorData?.metodo_pagamento_preferido || 'mbway',
          wallet: colaboradorData?.carteira_lightning || ''
        },
        preferences: userData.preferencias || {
          notifications: {
            email: true,
            push: true,
            sms: false,
            types: {
              approved: true,
              rejected: true,
              payment: true,
              promotions: false
            },
            sound: true
          },
          security: {
            twoFactor: false,
            biometrics: true,
            loginNotify: true
          }
        }
      }

      setUser(mappedUser)
    } catch (error) {
      console.error('Erro ao carregar dados do usuário:', error)
      throw error
    }
  }

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      })

      if (error) {
        return { success: false, error: error.message }
      }

      if (data.user) {
        await loadUserData(data.user.id)
        
        // Pré-carregar banners em background após login
        supabase
          .from('banners')
          .select('imagem_url')
          .eq('ativo', true)
          .then(({ data: banners }) => {
            if (banners) {
              const urls = banners.map(b => b.imagem_url).filter(Boolean)
              preloadImages(urls)
            }
          })
        
        return { success: true }
      }

      return { success: false, error: 'Usuário não encontrado' }
    } catch (error: any) {
      console.error('Erro no login:', error)
      return { success: false, error: error.message || 'Erro ao fazer login' }
    }
  }

  const register = async (
    name: string, 
    email: string, 
    phone: string, 
    nif: string, 
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      })

      if (authError) {
        return { success: false, error: authError.message }
      }

      if (!authData.user) {
        return { success: false, error: 'Erro ao criar usuário' }
      }

      const { error: userError } = await supabase
        .from('usuarios')
        .insert([
          {
            id: authData.user.id,
            nome: name,
            email: email,
            telefone: phone,
            nif: nif,
            senha_hash: 'gerenciado-pelo-supabase-auth',
            tipo_usuario: 'colaborador',
            ativo: true
          }
        ])

      if (userError) {
        console.error('Erro ao criar registro na tabela usuarios:', userError)
        await supabase.auth.signOut()
        return { success: false, error: 'Erro ao registrar dados do usuário' }
      }

      const { error: colaboradorError } = await supabase
        .from('colaboradores')
        .insert([
          {
            usuario_id: authData.user.id,
            status: 'ativo',
            limite_total: 1000.00,
            limite_disponivel: 1000.00,
            taxa_juros: 10.00,
            total_adiantamentos: 0,
            data_registro: new Date().toISOString(),
            telefone_mbway: phone,
            metodo_pagamento_preferido: 'mbway'
          }
        ])

      if (colaboradorError) {
        console.error('Erro ao criar registro de colaborador:', colaboradorError)
      }

      await loadUserData(authData.user.id)
      return { success: true }
    } catch (error) {
      console.error('Erro no registro:', error)
      return { success: false, error: 'Erro ao registrar usuário' }
    }
  }

  const logout = async () => {
    try {
      await supabase.auth.signOut()
      setUser(null)
    } catch (error) {
      console.error('Erro ao fazer logout:', error)
    }
  }

  const updateBankDetails = async (bankDetails: User['bankDetails']): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Usuário não autenticado' }

    try {
      const { error } = await supabase
        .from('colaboradores')
        .update({
          iban: bankDetails.iban,
          nome_titular_banco: bankDetails.bankHolderName,
          swift_bic: bankDetails.swiftBic,
          telefone_mbway: bankDetails.mbwayPhone,
          metodo_pagamento_preferido: bankDetails.preferredMethod,
          carteira_lightning: bankDetails.wallet
        })
        .eq('usuario_id', user.id)

      if (error) throw error

      const updatedUser = { ...user, bankDetails }
      setUser(updatedUser)
      return { success: true }
    } catch (error: any) {
      console.error('Erro ao atualizar dados bancários:', error)
      return { success: false, error: error.message }
    }
  }

  const updatePersonalData = async (data: Partial<Pick<User, 'name' | 'email' | 'phone' | 'nif'>>): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Usuário não autenticado' }

    try {
      const updates: any = {}
      if (data.name) updates.nome = data.name
      if (data.email) updates.email = data.email
      if (data.phone) updates.telefone = data.phone
      if (data.nif) updates.nif = data.nif

      const { error } = await supabase
        .from('usuarios')
        .update(updates)
        .eq('id', user.id)

      if (error) throw error

      if (data.email && data.email !== user.email) {
         const { error: authError } = await supabase.auth.updateUser({ email: data.email })
         if (authError) console.error('Erro ao atualizar email de auth:', authError)
      }

      setUser({ ...user, ...data })
      return { success: true }
    } catch (error: any) {
      console.error('Erro ao atualizar dados pessoais:', error)
      return { success: false, error: error.message }
    }
  }

  const updatePreferences = async (preferences: Partial<User['preferences']>): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'Usuário não autenticado' }

    try {
      const newPreferences = { ...user.preferences, ...preferences }
      
      if (preferences.notifications) {
        newPreferences.notifications = { 
          ...user.preferences.notifications, 
          ...preferences.notifications,
          types: {
             ...user.preferences.notifications.types,
             ...(preferences.notifications.types || {})
          }
        }
      }
      
      if (preferences.security) {
        newPreferences.security = { ...user.preferences.security, ...preferences.security }
      }

      const { error } = await supabase
        .from('usuarios')
        .update({ preferencias: newPreferences })
        .eq('id', user.id)

      if (error) throw error

      setUser({ ...user, preferences: newPreferences })
      return { success: true }
    } catch (error: any) {
      console.error('Erro ao atualizar preferências:', error)
      return { success: false, error: error.message }
    }
  }

  const updatePassword = async (newPassword: string): Promise<{ success: boolean; error?: string }> => {
     try {
       const { error } = await supabase.auth.updateUser({ password: newPassword })
       if (error) throw error
       return { success: true }
     } catch (error: any) {
       console.error('Erro ao atualizar senha:', error)
       return { success: false, error: error.message }
     }
  }

  const updateAvatar = async (file: File | null): Promise<{ success: boolean; url?: string; error?: string }> => {
    if (!user) return { success: false, error: 'Usuário não autenticado' }

    try {
      // Deletar avatar antigo se existir
      await supabase.storage.from('avatars').remove([`${user.id}/avatar.jpg`, `${user.id}/avatar.png`, `${user.id}/avatar.jpeg`, `${user.id}/avatar.webp`])

      // Se file é null, apenas remove a foto
      if (!file) {
        const { error: dbError } = await supabase
          .from('usuarios')
          .update({ foto_perfil: null })
          .eq('id', user.id)

        if (dbError) throw dbError

        setUser({ ...user, avatarUrl: undefined })
        return { success: true }
      }

      const fileExt = file.name.split('.').pop()
      const fileName = `${user.id}/avatar.${fileExt}`

      // Upload do novo avatar
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { upsert: true })

      if (uploadError) throw uploadError

      // Obter URL pública
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName)

      // Atualizar no banco de dados
      const { error: dbError } = await supabase
        .from('usuarios')
        .update({ foto_perfil: publicUrl })
        .eq('id', user.id)

      if (dbError) throw dbError

      // Atualizar estado local
      setUser({ ...user, avatarUrl: publicUrl })

      return { success: true, url: publicUrl }
    } catch (error: any) {
      console.error('Erro ao atualizar avatar:', error)
      return { success: false, error: error.message }
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
        updateBankDetails,
        updatePersonalData,
        updatePreferences,
        updatePassword,
        updateAvatar
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}
