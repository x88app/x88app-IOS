import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useNotifications } from './NotificationsContext'
import { supabase } from '../lib/supabase'
import { useAuth } from './AuthContext'
import { useQuery } from '@tanstack/react-query'

export interface Request {
  id: string
  amount: number
  paymentMethod: 'mbway' | 'iban' | 'satoshi'
  status: 'pending' | 'processing' | 'approved' | 'paid' | 'rejected' | 'verifying' | 'canceled'
  date: string
  netAmount: number
  accountDetails?: string
  createdAt: number
  progressStep: number
  currency?: 'EUR' | 'SATS'
  lightningAddress?: string
  paymentDate?: string
  descontado?: boolean
  dataDesconto?: string
}

export interface Banner {
  id: string
  imagem_url: string
  titulo: string
}

interface RequestsContextType {
  requests: Request[]
  banners: Banner[]
  isLoadingBanners: boolean
  isLoadingRequests: boolean
  addRequest: (request: Omit<Request, 'id' | 'createdAt' | 'progressStep'>) => Promise<Request | null>
  getRequestById: (id: string) => Request | undefined
  getPendingRequests: () => Request[]
  getApprovedRequests: () => Request[]
  updateRequest: (id: string, updates: Partial<Request>) => Promise<void>
}

const RequestsContext = createContext<RequestsContextType | undefined>(undefined)

const mapStatus = (status: string): Request['status'] => {
  const s = status.toLowerCase()
  if (s === 'pendente') return 'pending'
  if (s === 'aprovado') return 'approved'
  if (s === 'pago') return 'paid'
  if (s === 'rejeitado') return 'rejected'
  if (s === 'cancelado') return 'canceled'
  if (s === 'processando') return 'processing'
  if (s === 'verificando') return 'verifying'
  return s as Request['status']
}

const mapStatusToDb = (status: Request['status']): string => {
  if (status === 'pending') return 'pendente'
  if (status === 'approved') return 'aprovado'
  if (status === 'paid') return 'pago'
  if (status === 'rejected') return 'rejeitado'
  if (status === 'canceled') return 'cancelado'
  if (status === 'processing') return 'processando'
  if (status === 'verifying') return 'verificando'
  return status
}

export function RequestsProvider({ children }: { children: ReactNode }) {
  const { addNotification } = useNotifications()
  const { user } = useAuth()
  const [requests, setRequests] = useState<Request[]>([])
  const [isLoadingRequests, setIsLoadingRequests] = useState(true)
  const [hasLoadedOnce, setHasLoadedOnce] = useState(false)

  const { data: banners = [], isLoading: isLoadingBanners, refetch: refetchBanners } = useQuery(
    ['banners'],
    async () => {
      console.log('Buscando banners do Supabase...')
      const { data, error } = await supabase
        .from('banners')
        .select('*')
        .eq('ativo', true)
        .eq('tipo', 'carousel')
        .order('ordem', { ascending: true })

      if (error) {
        console.error('Erro ao buscar banners:', error)
        throw error
      }
      
      console.log('Banners encontrados:', data?.length || 0)
      
      // Pré-carregar imagens dos banners
      if (data && data.length > 0) {
        data.forEach((banner: Banner) => {
          if (banner.imagem_url) {
            const img = new Image()
            img.src = banner.imagem_url
          }
        })
      }
      
      return data as Banner[]
    },
    {
      staleTime: 0, // Sem cache - sempre buscar dados frescos no realtime
      cacheTime: 1000 * 60 * 5, // 5 minutos
      refetchOnWindowFocus: true,
      refetchOnMount: 'always',
      retry: 3,
      retryDelay: 1000
    }
  )

  // Recarregar banners quando usuário logar
  useEffect(() => {
    if (user) {
      refetchBanners()
    }
  }, [user, refetchBanners])

  // Realtime para banners - atualiza imediatamente quando gestor faz alterações
  useEffect(() => {
    const channel = supabase
      .channel('banners-carousel-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'banners'
        },
        () => {
          console.log('Mudança detectada nos banners carousel - atualizando...')
          refetchBanners()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [refetchBanners])

  useEffect(() => {
    if (user) {
      // Só mostra loading na primeira vez
      if (!hasLoadedOnce) {
        setIsLoadingRequests(true)
      }
      
      loadRequests().finally(() => {
        setIsLoadingRequests(false)
        setHasLoadedOnce(true)
      })
      
      const channel = supabase
        .channel('solicitacoes-changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'solicitacoes'
          },
          () => {
            loadRequests()
          }
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    }
  }, [user])

  const loadRequests = async () => {
    if (!user) return

    try {
      const { data: colaboradorData } = await supabase
        .from('colaboradores')
        .select('id')
        .eq('usuario_id', user.id)
        .single()

      if (!colaboradorData) return

      const { data, error } = await supabase
        .from('solicitacoes')
        .select('*')
        .eq('colaborador_id', colaboradorData.id)
        .order('data_solicitacao', { ascending: false })

      if (error) {
        console.error('Erro ao carregar solicitações:', error)
        return
      }

      const mappedRequests: Request[] = (data || []).map(item => ({
        id: item.id,
        amount: Number(item.valor_solicitado),
        paymentMethod: item.metodo_pagamento as 'mbway' | 'iban' | 'satoshi',
        status: mapStatus(item.status),
        date: item.data_solicitacao,
        netAmount: Number(item.valor_liquido),
        accountDetails: item.detalhes_conta || item.iban_pagamento || item.mbway_pagamento,
        createdAt: new Date(item.data_solicitacao).getTime(),
        progressStep: item.etapa_progresso,
        currency: item.moeda as 'EUR' | 'SATS',
        lightningAddress: item.lightning_address,
        paymentDate: item.data_pagamento,
        descontado: item.descontado || false,
        dataDesconto: item.data_desconto
      }))

      setRequests(mappedRequests)
    } catch (error) {
      console.error('Erro ao carregar solicitações:', error)
    }
  }

  const addRequest = async (request: Omit<Request, 'id' | 'createdAt' | 'progressStep'>): Promise<Request | null> => {
    if (!user) return null

    try {
      const { data: colaboradorData } = await supabase
        .from('colaboradores')
        .select('id, taxa_juros')
        .eq('usuario_id', user.id)
        .single()

      if (!colaboradorData) return null

      const taxaJuros = colaboradorData.taxa_juros || 10
      const valorJuros = (request.amount * taxaJuros) / 100
      const valorADescontar = request.amount + valorJuros // Nova lógica: valor solicitado + taxa

      const { data, error } = await supabase
        .from('solicitacoes')
        .insert([
          {
            colaborador_id: colaboradorData.id,
            valor_solicitado: request.amount,
            valor_liquido: valorADescontar, // Agora armazena o valor a descontar (amount + taxa)
            moeda: request.currency || 'EUR',
            metodo_pagamento: request.paymentMethod,
            detalhes_conta: request.accountDetails,
            iban_pagamento: request.paymentMethod === 'iban' ? request.accountDetails : null,
            mbway_pagamento: request.paymentMethod === 'mbway' ? request.accountDetails : null,
            lightning_address: request.lightningAddress,
            status: request.status === 'verifying' ? 'verificando' : 'pendente',
            etapa_progresso: 0,
            taxa_juros_aplicada: taxaJuros,
            valor_juros: valorJuros,
            data_solicitacao: new Date().toISOString()
          }
        ])
        .select()
        .single()

      if (error) {
        console.error('Erro ao criar solicitação:', error)
        return null
      }

      const newRequest: Request = {
        id: data.id,
        amount: request.amount,
        paymentMethod: request.paymentMethod,
        status: request.status || 'pending',
        date: data.data_solicitacao,
        netAmount: valorADescontar, // Valor a descontar do salário
        accountDetails: request.accountDetails,
        createdAt: new Date(data.data_solicitacao).getTime(),
        progressStep: 0,
        currency: request.currency,
        lightningAddress: request.lightningAddress,
        paymentDate: undefined
      }

      setRequests(prev => [newRequest, ...prev])
      return newRequest
    } catch (error) {
      console.error('Erro ao adicionar solicitação:', error)
      return null
    }
  }

  const getRequestById = (id: string) => {
    return requests.find((req) => req.id === id)
  }

  const getPendingRequests = () => {
    return requests.filter((req) => req.status === 'pending' || req.status === 'processing' || req.status === 'verifying')
  }

  const getApprovedRequests = () => {
    return requests.filter((req) => req.status === 'approved' || req.status === 'paid')
  }

  const updateRequest = async (id: string, updates: Partial<Request>) => {
    // Optimistic update
    setRequests((prev) =>
      prev.map((req) => (req.id === id ? { ...req, ...updates } : req))
    )

    try {
      const dbUpdates: any = {}
      
      if (updates.status) {
        dbUpdates.status = mapStatusToDb(updates.status)
      }
      
      // Add other field mappings if necessary
      
      if (Object.keys(dbUpdates).length > 0) {
        const { error } = await supabase
          .from('solicitacoes')
          .update(dbUpdates)
          .eq('id', id)

        if (error) {
          console.error('Erro ao atualizar solicitação:', error)
          // Revert optimistic update could go here
          // For now, we reload to ensure consistency
          loadRequests()
        }
      }
    } catch (error) {
      console.error('Erro na atualização:', error)
      loadRequests()
    }
  }

  return (
    <RequestsContext.Provider
      value={{
        requests,
        banners,
        isLoadingBanners,
        isLoadingRequests,
        addRequest,
        getRequestById,
        getPendingRequests,
        getApprovedRequests,
        updateRequest,
      }}
    >
      {children}
    </RequestsContext.Provider>
  )
}

export function useRequests() {
  const context = useContext(RequestsContext)
  if (context === undefined) {
    throw new Error('useRequests deve ser usado dentro de um RequestsProvider')
  }
  return context
}
