import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './styles/index.css'
import { registerSW } from 'virtual:pwa-register'

// Registrar Service Worker para PWA (apenas em produção)
const isProduction = import.meta.env.PROD

const updateSW = registerSW({
  onNeedRefresh() {
    console.log('🔄 Nova versão disponível!')
    // Em produção, atualiza automaticamente. Em dev, apenas loga.
    if (isProduction) {
      updateSW(true)
    }
  },
  onOfflineReady() {
    console.log('✅ App pronto para funcionar offline!')
  },
  onRegistered(registration) {
    console.log('✅ Service Worker registrado!')
    // Verifica atualizações a cada hora (apenas em produção)
    if (registration && isProduction) {
      setInterval(() => {
        registration.update()
      }, 60 * 60 * 1000)
    }
  },
  onRegisterError(error) {
    console.error('❌ Erro ao registrar Service Worker:', error)
  }
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
