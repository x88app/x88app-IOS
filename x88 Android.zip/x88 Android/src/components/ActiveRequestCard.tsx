import { useEffect, useState, useRef } from 'react'
import { Request } from '../contexts/RequestsContext'
import { RequestProgress } from './RequestProgress'
import { X } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'

interface Props {
  request: Request
  onCancel: (id: string) => void
}

export const ActiveRequestCard = ({ request, onCancel }: Props) => {
  const { formatCurrency } = useLanguage()
  const [displayStep, setDisplayStep] = useState(0)
  const [displayStatus, setDisplayStatus] = useState<Request['status']>(request.status)
  const prevStatus = useRef(request.status)

  useEffect(() => {
    // Initial setup and state transitions
    const handleStatusChange = () => {
      if (request.status === 'pending') {
        // Show Step 0 briefly if very new, otherwise Step 1 (Em Análise)
        const createdAt = request.createdAt
        const now = Date.now()
        // If less than 2s old, show Step 0 then Step 1
        if (now - createdAt < 2000) {
          setDisplayStep(0)
          const timer = setTimeout(() => setDisplayStep(1), 2000)
          return () => clearTimeout(timer)
        } else {
          // Otherwise show Step 1 immediately
          setDisplayStep(1)
          setDisplayStatus('pending')
        }
      } else if (request.status === 'approved') {
        // If transitioning from pending to approved
        if (prevStatus.current === 'pending' || prevStatus.current === 'processing') {
          // Show Processando (Step 2)
          setDisplayStep(2)
          setDisplayStatus('processing')
          
          // Wait 3 seconds then show Aprovado (Step 3)
          const timer = setTimeout(() => {
            setDisplayStep(3)
            setDisplayStatus('approved')
          }, 3000)
          return () => clearTimeout(timer)
        } else {
          // Already approved (e.g. page reload)
          setDisplayStep(3)
          setDisplayStatus('approved')
        }
      } else if (request.status === 'paid') {
        // Show Transferido (Step 4)
        setDisplayStep(4)
        setDisplayStatus('paid')
        // Note: The card visibility is controlled by the parent (Home)
        // which keeps it visible for 15s after payment
      } else if (request.status === 'rejected') {
          setDisplayStatus('rejected')
          setDisplayStep(3) // Using step 3 slot for rejected/approved
      }
    }

    const cleanup = handleStatusChange()
    prevStatus.current = request.status
    return cleanup
  }, [request.status, request.createdAt])

  return (
    <div className={`card border-2 ${
      request.currency === 'SATS' 
        ? 'border-[#E69F39]/30 bg-[#E69F39]/5'
        : 'border-[#00d749]/30 bg-[#00d749]/5'
    }`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full animate-blink ${
            request.currency === 'SATS' 
              ? 'bg-[#E69F39]' 
              : 'bg-[#00d749]'
          }`}></div>
          <h3 className="text-lg font-bold text-black dark:text-white">
            Solicitação em Andamento
          </h3>
        </div>
        {/* Only show cancel button if pending or approved (before payment) */}
        {(displayStatus === 'pending' || displayStatus === 'approved' || displayStatus === 'processing') && (
          <button
            onClick={() => onCancel(request.id)}
            className="p-2 hover:bg-red-100 dark:hover:bg-red-900/20 rounded-full transition-colors"
            title="Cancelar solicitação"
          >
            <X className="w-5 h-5 text-red-600" />
          </button>
        )}
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">Valor Solicitado</p>
            <p className={`text-3xl font-bold ${
              request.currency === 'SATS' 
                ? 'text-[#E69F39]' 
                : 'text-[#00d749]'
            }`}>
              {request.currency === 'SATS' 
                ? `${request.amount} sats` 
                : formatCurrency(request.amount)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-neutral-600 dark:text-neutral-400">A Descontar</p>
            <p className="text-2xl font-bold text-red-600">
              {request.currency === 'SATS' 
                ? `${Math.round(request.netAmount)} sats` 
                : formatCurrency(request.netAmount)}
            </p>
          </div>
        </div>

        <RequestProgress 
          currentStep={displayStep} 
          status={displayStatus}
          currency={request.currency}
        />
      </div>
    </div>
  )
}
