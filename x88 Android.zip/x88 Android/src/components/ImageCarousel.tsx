import { useState, useEffect } from 'react'
import { useRequests } from '../contexts/RequestsContext'
import { loadImageWithCache, preloadImages, getMemoryCachedImage } from '../lib/imageCache'

interface ImageCarouselProps {
  onHasBanners?: (hasBanners: boolean) => void
}

// Função para obter cache inicial de forma síncrona
const getInitialCache = (banners: any[]) => {
  const urls: Record<string, string> = {}
  const loaded: Record<string, boolean> = {}
  banners.forEach(banner => {
    if (banner.imagem_url) {
      const memCached = getMemoryCachedImage(banner.imagem_url)
      if (memCached) {
        urls[banner.id] = memCached
        loaded[banner.id] = true
      }
    }
  })
  return { urls, loaded }
}

export const ImageCarousel = ({ onHasBanners }: ImageCarouselProps) => {
  const { banners, isLoadingBanners } = useRequests()
  
  // Inicializar estados já com cache em memória
  const [currentIndex, setCurrentIndex] = useState(0)
  const [cachedUrls, setCachedUrls] = useState<Record<string, string>>(() => getInitialCache(banners).urls)
  const [imagesLoaded, setImagesLoaded] = useState<Record<string, boolean>>(() => getInitialCache(banners).loaded)

  // Atualizar cache quando banners mudam (incluindo novos banners em tempo real)
  useEffect(() => {
    const { urls, loaded } = getInitialCache(banners)
    
    // Verificar se há novos banners que não estão no cache
    const currentBannerIds = banners.map(b => b.id)
    const cachedBannerIds = Object.keys(cachedUrls)
    const hasNewBanners = currentBannerIds.some(id => !cachedBannerIds.includes(id))
    
    if (hasNewBanners) {
      console.log('Novos banners detectados em tempo real!')
      // Resetar para mostrar o primeiro banner (que pode ser novo)
      setCurrentIndex(0)
    }
    
    if (Object.keys(urls).length > 0) {
      setCachedUrls(prev => ({ ...prev, ...urls }))
      setImagesLoaded(prev => ({ ...prev, ...loaded }))
    }
  }, [banners])

  // Verificar se já temos imagens em cache na memória
  const hasMemoryCache = banners.length > 0 && banners.some(b => cachedUrls[b.id] || getMemoryCachedImage(b.imagem_url))

  useEffect(() => {
    if (!isLoadingBanners) {
      const hasBanners = banners.length > 0
      if (onHasBanners) onHasBanners(hasBanners)
      localStorage.setItem('x88_has_banners', String(hasBanners))
      
      // Pré-carregar todas as imagens com cache
      const urls = banners.map(b => b.imagem_url).filter(Boolean)
      preloadImages(urls)
      
      // Carregar cada imagem individualmente com cache (apenas as que não estão em cache)
      banners.forEach(async (banner) => {
        if (banner.imagem_url && !cachedUrls[banner.id]) {
          try {
            const url = await loadImageWithCache(banner.imagem_url)
            setCachedUrls(prev => ({ ...prev, [banner.id]: url }))
            setImagesLoaded(prev => ({ ...prev, [banner.id]: true }))
          } catch {
            setImagesLoaded(prev => ({ ...prev, [banner.id]: true }))
          }
        }
      })
    }
  }, [banners, isLoadingBanners, onHasBanners])

  useEffect(() => {
    if (banners.length === 0) return

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % banners.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [banners])

  const firstBannerLoaded = banners.length > 0 && (imagesLoaded[banners[0]?.id] || cachedUrls[banners[0]?.id])

  // Não mostrar loading se já temos cache em memória
  if (isLoadingBanners || (banners.length > 0 && !firstBannerLoaded && !hasMemoryCache)) {
    return (
      <div className="absolute inset-0 bg-gradient-to-b from-neutral-800 to-black">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin" />
        </div>
      </div>
    )
  }

  // Fallback visual se não houver banners
  if (banners.length === 0) {
    return null
  }

  // Pegar a URL do primeiro banner em cache para usar como background inicial
  const firstBannerUrl = cachedUrls[banners[0]?.id] || banners[0]?.imagem_url

  return (
    <div 
      className="absolute inset-0 overflow-hidden"
      style={firstBannerUrl ? { backgroundImage: `url(${firstBannerUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' } : { backgroundColor: '#000' }}
    >
      {banners.map((banner, index) => {
        const isActive = index === currentIndex
        const imgSrc = cachedUrls[banner.id] || banner.imagem_url

        return (
          <div
            key={banner.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              isActive ? 'opacity-100 z-10' : 'opacity-0 z-0'
            }`}
          >
            {/* Background desfocado para preencher a tela */}
            <div className="absolute inset-0">
               <img
                src={imgSrc}
                alt=""
                className="w-full h-full object-cover opacity-50 blur-xl scale-110"
              />
            </div>

            {/* Imagem principal - mantém proporção */}
            <div className="absolute inset-0">
              <img
                src={imgSrc}
                alt={banner.titulo || `Banner ${index + 1}`}
                className="w-full h-full object-contain object-top"
                loading="eager"
              />
            </div>
            
            {/* Overlay sutil */}
            <div className="absolute inset-0 bg-black/10 pointer-events-none" />
          </div>
        )
      })}
    </div>
  )
}
