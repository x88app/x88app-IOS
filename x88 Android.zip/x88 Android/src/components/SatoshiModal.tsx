import { useState, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { X, Copy, Share2, Edit2, Check } from 'lucide-react'
import { QRCodeSVG } from 'qrcode.react'
import { useRequests } from '../contexts/RequestsContext'

interface SatoshiModalProps {
  isOpen: boolean
  onClose: () => void
}

const SatoshiModal = ({ isOpen, onClose }: SatoshiModalProps) => {
  const { addRequest } = useRequests()
  const [lightningAddress, setLightningAddress] = useState('')
  const [inputValue, setInputValue] = useState('')
  const [isEditing, setIsEditing] = useState(false)
  const [copied, setCopied] = useState(false)
  const [isAnimating, setIsAnimating] = useState(false)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [showAmountInput, setShowAmountInput] = useState(false)
  const [receivedAmount, setReceivedAmount] = useState('')

  useEffect(() => {
    const saved = localStorage.getItem('lightningAddress')
    if (saved) {
      setLightningAddress(saved)
    }
  }, [])

  useEffect(() => {
    if (isOpen) {
      setIsAnimating(true)
      // Marcar que o QR Code foi aberto
      if (lightningAddress) {
        const pendingQR = {
          timestamp: Date.now(),
          lightningAddress: lightningAddress
        }
        localStorage.setItem('pendingSatoshiQRCode', JSON.stringify(pendingQR))
      }
    }
  }, [isOpen, lightningAddress])

  const handleSave = () => {
    if (inputValue.trim()) {
      localStorage.setItem('lightningAddress', inputValue.trim())
      setLightningAddress(inputValue.trim())
      setInputValue('')
      setIsEditing(false)
    }
  }

  const handleEdit = () => {
    setIsEditing(true)
    setInputValue(lightningAddress)
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(lightningAddress)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Erro ao copiar:', err)
    }
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Minha Carteira Lightning',
          text: `Envie Bitcoin para: ${lightningAddress}`
        })
      } catch (err) {
        console.error('Erro ao compartilhar:', err)
      }
    } else {
      handleCopy()
    }
  }

  const handleCloseAttempt = () => {
    // Só pergunta se recebeu valor se tiver endereço cadastrado e QR Code foi mostrado
    if (lightningAddress && !isEditing) {
      setShowConfirmDialog(true)
    } else {
      onClose()
    }
  }

  const handleNoReceived = () => {
    // Remover o QR Code pendente para não perguntar novamente
    localStorage.removeItem('pendingSatoshiQRCode')
    setShowConfirmDialog(false)
    setShowAmountInput(false)
    setReceivedAmount('')
    onClose()
  }

  const handleYesReceived = () => {
    setShowAmountInput(true)
  }

  const handleConfirmAmount = () => {
    const amount = parseInt(receivedAmount)
    if (amount && amount > 0) {
      // Criar uma solicitação já marcada como paga
      addRequest({
        amount,
        paymentMethod: 'satoshi',
        status: 'verifying',
        date: new Date().toISOString(),
        netAmount: amount, // Valor recebido é o valor líquido (já sem taxa)
        currency: 'SATS',
        lightningAddress,
      })
      
      // Limpar o QR Code pendente
      localStorage.removeItem('pendingSatoshiQRCode')
      
      // Fechar tudo
      setShowConfirmDialog(false)
      setShowAmountInput(false)
      setReceivedAmount('')
      onClose()
    }
  }

  if (!isOpen) return null

  const modalContent = (
    <>
      <div className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 transition-opacity duration-700 ${
        isAnimating ? 'opacity-100' : 'opacity-0'
      }`}>
        <div className={`bg-white dark:bg-neutral-900 rounded-3xl w-full max-w-md shadow-2xl transition-all duration-700 ${
          isAnimating ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
        {/* Header */}
        <div className="bg-[#E69F39] text-white p-6 rounded-t-3xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 flex items-center justify-center">
              <img 
                src="/logos/BITCOIN.png" 
                alt="Bitcoin"
                className="w-12 h-12"
              />
            </div>
            <div>
              <h2 className="text-xl font-bold">Receber Satoshi</h2>
              <p className="text-sm opacity-90">Lightning Network</p>
            </div>
          </div>
          <button
            onClick={handleCloseAttempt}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {!lightningAddress || isEditing ? (
            // Form para adicionar/editar Lightning Address
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                  Lightning Address
                </label>
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="usuario@walletofsatoshi.com"
                  className="w-full px-4 py-3 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F7931A] text-black dark:text-white"
                />
                <p className="text-xs text-neutral-500 mt-2">
                  Cole sua Lightning Address do Wallet of Satoshi, Blink, Phoenix ou outra carteira
                </p>
              </div>

              <div className="flex gap-3">
                {isEditing && (
                  <button
                    onClick={() => {
                      setIsEditing(false)
                      setInputValue('')
                    }}
                    className="flex-1 py-3 px-4 bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 rounded-xl font-medium hover:bg-neutral-300 dark:hover:bg-neutral-700 transition-colors"
                  >
                    Cancelar
                  </button>
                )}
                <button
                  onClick={handleSave}
                  disabled={!inputValue.trim()}
                  className="flex-1 py-3 px-4 bg-gradient-to-r from-[#F7931A] to-[#FF8C00] text-white rounded-xl font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isEditing ? 'Atualizar' : 'Gerar QR Code'}
                </button>
              </div>
            </div>
          ) : (
            // Mostrar QR Code
            <div className="space-y-6">
              {/* QR Code */}
              <div className="bg-white p-4 rounded-2xl border-2 border-neutral-200 dark:border-neutral-700 flex justify-center relative">
                <QRCodeSVG
                  value={lightningAddress}
                  size={320}
                  level="H"
                  includeMargin={true}
                  className="rounded-xl w-full h-full"
                />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-white p-1.5 flex items-center justify-center">
                  <img 
                    src="/logos/BITCOIN.png" 
                    alt="Bitcoin"
                    className="w-full h-full rounded-full"
                  />
                </div>
              </div>

              {/* Lightning Address */}
              <div className="bg-neutral-50 dark:bg-neutral-800 p-4 rounded-xl">
                <p className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">
                  Sua Lightning Address
                </p>
                <p className="text-sm font-mono text-black dark:text-white break-all">
                  {lightningAddress}
                </p>
              </div>

              {/* Botões de Ação */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handleCopy}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 rounded-xl font-medium hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-5 h-5 text-[#00d749]" />
                      Copiado!
                    </>
                  ) : (
                    <>
                      <Copy className="w-5 h-5" />
                      Copiar
                    </>
                  )}
                </button>
                <button
                  onClick={handleShare}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 rounded-xl font-medium hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                >
                  <Share2 className="w-5 h-5" />
                  Compartilhar
                </button>
              </div>

              {/* Botão Editar */}
              <button
                onClick={handleEdit}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 border-2 border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-xl font-medium hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
              >
                <Edit2 className="w-5 h-5" />
                Alterar Endereço
              </button>
            </div>
          )}
        </div>
        </div>
      </div>

      {/* Dialog de Confirmação */}
      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[99999] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-sm shadow-2xl p-6">
            {!showAmountInput ? (
              <>
                <h3 className="text-xl font-bold text-black dark:text-white mb-4">
                  Você recebeu algum valor?
                </h3>
                <p className="text-neutral-600 dark:text-neutral-400 mb-6">
                  Confirme se recebeu algum pagamento em Satoshi
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={handleNoReceived}
                    className="flex-1 py-3 bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold rounded-xl hover:bg-neutral-300 dark:hover:bg-neutral-700 transition-colors"
                  >
                    Não
                  </button>
                  <button
                    onClick={handleYesReceived}
                    className="flex-1 py-3 bg-[#E69F39] text-white font-semibold rounded-xl hover:bg-[#d18f2f] transition-colors"
                  >
                    Sim
                  </button>
                </div>
              </>
            ) : (
              <>
                <h3 className="text-xl font-bold text-black dark:text-white mb-4">
                  Quanto você recebeu?
                </h3>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                    Valor em Satoshi
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-[#E69F39]">
                      ₿
                    </span>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={receivedAmount}
                      onChange={(e) => setReceivedAmount(e.target.value.replace(/\D/g, ''))}
                      className="w-full pl-12 pr-4 py-3 text-2xl font-bold border-2 border-neutral-200 dark:border-neutral-700 rounded-xl bg-white dark:bg-neutral-800 text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#E69F39]"
                      placeholder="0"
                      autoFocus
                    />
                  </div>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
                    Digite apenas o valor recebido
                  </p>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setShowAmountInput(false)
                      setReceivedAmount('')
                    }}
                    className="flex-1 py-3 bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold rounded-xl hover:bg-neutral-300 dark:hover:bg-neutral-700 transition-colors"
                  >
                    Voltar
                  </button>
                  <button
                    onClick={handleConfirmAmount}
                    disabled={!receivedAmount || parseInt(receivedAmount) === 0}
                    className="flex-1 py-3 bg-[#E69F39] text-white font-semibold rounded-xl hover:bg-[#d18f2f] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Confirmar
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  )

  return createPortal(modalContent, document.body)
}

export default SatoshiModal
