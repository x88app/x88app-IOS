import { X, ExternalLink, Rss } from 'lucide-react'
import { createPortal } from 'react-dom'
import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

interface FeedCard {
  id: string
  titulo: string
  imagem_url: string
  ativo: boolean
  tipo: string
  nome_botao?: string
  link_botao?: string
  usar_whatsapp?: boolean
  data_criacao: string
}

interface FeedPanelProps {
  isOpen: boolean
  onClose: () => void
  buttonPosition: { x: number; y: number }
}

export const FeedPanel = ({ isOpen, onClose, buttonPosition }: FeedPanelProps) => {
  const [isAnimating, setIsAnimating] = useState(false)
  const [shouldRender, setShouldRender] = useState(false)
  const [cards, setCards] = useState<FeedCard[]>([])
  const [loading, setLoading] = useState(true)
  const [gestorPhone, setGestorPhone] = useState<string | null>(null)

  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout>

    if (isOpen) {
      setShouldRender(true)
      fetchCards()
      fetchGestorPhone()
      timeoutId = setTimeout(() => setIsAnimating(true), 50)
    } else {
      setIsAnimating(false)
      timeoutId = setTimeout(() => setShouldRender(false), 700)
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId)
    }
  }, [isOpen])

  // Realtime para cards do feed - atualiza imediatamente quando gestor faz alterações
  useEffect(() => {
    const channel = supabase
      .channel('feed-cards-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'banners'
        },
        () => {
          console.log('Mudança detectada nos cards do feed - atualizando...')
          fetchCards()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  const fetchGestorPhone = async () => {
    try {
      // Buscar WhatsApp global das configurações
      const { data: configGlobal } = await supabase
        .from('configuracoes_globais')
        .select('whatsapp_suporte')
        .limit(1)
        .maybeSingle()

      if (configGlobal?.whatsapp_suporte) {
        setGestorPhone(configGlobal.whatsapp_suporte)
      }
    } catch (error) {
      console.error('Erro ao buscar WhatsApp global:', error)
    }
  }

  const fetchCards = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('banners')
        .select('*')
        .eq('ativo', true)
        .eq('tipo', 'popup')
        .order('ordem', { ascending: true })

      if (error) throw error
      setCards(data || [])
    } catch (error) {
      console.error('Erro ao buscar cards:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleButtonClick = (card: FeedCard) => {
    if (card.usar_whatsapp && gestorPhone) {
      const cleanPhone = gestorPhone.replace(/\D/g, '')
      window.open(`https://wa.me/${cleanPhone}`, '_blank')
    } else if (card.link_botao) {
      window.open(card.link_botao, '_blank')
    }
  }

  if (!shouldRender) return null

  const panelContent = (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-[9998] transition-opacity duration-700 ${
          isAnimating ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Panel */}
      <div
        style={{
          transformOrigin: isAnimating ? 'center top' : `${buttonPosition.x}px ${buttonPosition.y}px`,
        }}
        className={`fixed inset-x-0 top-0 bottom-0 z-[9999] bg-white dark:bg-neutral-900 flex flex-col transition-all duration-700 ease-out ${
          isAnimating
            ? 'opacity-100 scale-100 translate-y-0'
            : 'opacity-0 scale-50 -translate-y-full'
        }`}
      >
        {/* Header */}
        <div className="flex-shrink-0 flex items-center justify-between px-4 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Rss className="w-5 h-5 text-[#00d749]" />
            <h2 className="text-lg font-bold text-black dark:text-white">Feed</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="flex items-center justify-center h-40">
              <div className="w-8 h-8 border-3 border-[#00d749] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : cards.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center px-6 py-12">
              <div className="w-20 h-20 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mb-4">
                <Rss className="w-10 h-10 text-neutral-400" />
              </div>
              <h3 className="text-lg font-semibold text-neutral-800 dark:text-neutral-200 mb-2">
                Nenhuma novidade
              </h3>
              <p className="text-neutral-500 dark:text-neutral-400 text-sm">
                Não há anúncios ou novidades no momento. Volte mais tarde!
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {cards.map((card) => (
                <div
                  key={card.id}
                  className="bg-white dark:bg-neutral-800 rounded-2xl overflow-hidden shadow-md border border-neutral-200 dark:border-neutral-700"
                >
                  {/* Card Image */}
                  <div className="relative">
                    <img
                      src={card.imagem_url}
                      alt={card.titulo}
                      className="w-full h-auto object-contain"
                      loading="lazy"
                    />
                  </div>

                  {/* Card Content */}
                  {(card.titulo || card.nome_botao) && (
                    <div className="p-4">
                      {card.titulo && (
                        <h3 className="font-semibold text-black dark:text-white mb-3">
                          {card.titulo}
                        </h3>
                      )}
                      
                      {card.nome_botao && (
                        <button
                          onClick={() => handleButtonClick(card)}
                          className="w-full py-3 px-4 bg-[#0FB841] hover:bg-[#0da838] text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition-all"
                        >
                          {card.usar_whatsapp ? (
                            <img
                              src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
                              alt="WhatsApp"
                              className="w-5 h-5"
                            />
                          ) : (
                            <ExternalLink className="w-5 h-5" />
                          )}
                          {card.nome_botao}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  )

  return createPortal(panelContent, document.body)
}
