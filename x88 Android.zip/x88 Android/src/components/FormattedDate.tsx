import { useLanguage } from '../contexts/LanguageContext';

interface FormattedDateProps {
  date: string | number | Date;
  options?: Intl.DateTimeFormatOptions;
  className?: string;
}

export const FormattedDate = ({ date, options, className }: FormattedDateProps) => {
  const { formatDate } = useLanguage();
  return <span className={className}>{formatDate(date, options)}</span>;
};
