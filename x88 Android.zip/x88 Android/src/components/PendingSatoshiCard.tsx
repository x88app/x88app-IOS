import { useState, useEffect } from 'react'
import { X } from 'lucide-react'
import { createPortal } from 'react-dom'
import { useRequests } from '../contexts/RequestsContext'

export const PendingSatoshiCard = () => {
  const { addRequest } = useRequests()
  const [showCard, setShowCard] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [receivedAmount, setReceivedAmount] = useState('')
  const [lightningAddress, setLightningAddress] = useState('')

  useEffect(() => {
    checkPendingQRCode()
  }, [])

  const checkPendingQRCode = () => {
    const pending = localStorage.getItem('pendingSatoshiQRCode')
    if (pending) {
      try {
        const data = JSON.parse(pending)
        setLightningAddress(data.lightningAddress)
        setShowCard(true)
      } catch (error) {
        console.error('Erro ao verificar QR Code pendente:', error)
      }
    }
  }

  const handleNo = () => {
    localStorage.removeItem('pendingSatoshiQRCode')
    setShowCard(false)
    setShowModal(false)
    setReceivedAmount('')
  }

  const handleYes = () => {
    setShowModal(true)
  }

  const handleConfirm = () => {
    const amount = parseInt(receivedAmount)
    if (amount && amount > 0) {
      addRequest({
        amount,
        paymentMethod: 'satoshi',
        status: 'verifying',
        date: new Date().toISOString(),
        netAmount: amount,
        currency: 'SATS',
        lightningAddress,
      })

      localStorage.removeItem('pendingSatoshiQRCode')
      setShowCard(false)
      setShowModal(false)
      setReceivedAmount('')
    }
  }

  if (!showCard) return null

  return (
    <>
      <div className="card border-2 border-[#E69F39]/30 bg-[#E69F39]/5">
        <>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <img src="/logos/BITCOIN.png" alt="Bitcoin" className="w-6 h-6" />
              <h3 className="text-lg font-bold text-black dark:text-white">
                Recebeu Satoshi?
              </h3>
            </div>
          </div>
          
          <p className="text-neutral-600 dark:text-neutral-400 mb-4">
            Você abriu seu QR Code Lightning. Recebeu algum pagamento em Satoshi?
          </p>

          <div className="flex gap-3">
            <button
              onClick={handleNo}
              className="flex-1 py-3 bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold rounded-xl hover:bg-neutral-300 dark:hover:bg-neutral-700 transition-colors"
            >
              Não
            </button>
            <button
              onClick={handleYes}
              className="flex-1 py-3 bg-[#E69F39] text-white font-semibold rounded-xl hover:bg-[#d18f2f] transition-colors"
            >
              Sim
            </button>
          </div>
        </>
      </div>

      {/* Modal para digitar valor */}
      {showModal && createPortal(
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[99999] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-sm shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <img src="/logos/BITCOIN.png" alt="Bitcoin" className="w-6 h-6" />
                <h3 className="text-xl font-bold text-black dark:text-white">
                  Quanto recebeu?
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Valor em Satoshi
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-[#E69F39]">
                  ₿
                </span>
                <input
                  type="text"
                  inputMode="numeric"
                  value={receivedAmount}
                  onChange={(e) => setReceivedAmount(e.target.value.replace(/\D/g, ''))}
                  className="w-full pl-12 pr-4 py-3 text-2xl font-bold border-2 border-[#E69F39]/50 rounded-xl bg-white dark:bg-neutral-800 text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#E69F39]"
                  placeholder="0"
                  autoFocus
                />
              </div>
              <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
                Digite o valor que você recebeu
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowModal(false)
                  setReceivedAmount('')
                }}
                className="flex-1 py-3 bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 font-semibold rounded-xl hover:bg-neutral-300 dark:hover:bg-neutral-700 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirm}
                disabled={!receivedAmount || parseInt(receivedAmount) === 0}
                className="flex-1 py-3 bg-[#E69F39] text-white font-semibold rounded-xl hover:bg-[#d18f2f] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  )
}
