import { TrendingUp, Clock, CheckCircle, Euro, Zap, DollarSign } from 'lucide-react'
import { useRequests } from '../contexts/RequestsContext'
import { useLanguage } from '../contexts/LanguageContext'

export const StatsCarousel = () => {
  const { requests, getApprovedRequests } = useRequests()
  const { formatCurrency, language } = useLanguage()
  
  const approvedRequests = getApprovedRequests()
  const totalEuro = approvedRequests
    .filter(r => r.currency === 'EUR')
    .reduce((sum, r) => sum + r.amount, 0) // Soma valor recebido (amount)
  const totalSats = approvedRequests
    .filter(r => r.currency === 'SATS')
    .reduce((sum, r) => sum + r.amount, 0) // Soma valor recebido (amount)
  const pendingCount = requests.filter(r => r.status === 'pending').length
  const approvedCount = approvedRequests.length

  const cards = [
    {
      title: 'Total Aprovado',
      value: formatCurrency(totalEuro),
      icon: language === 'pt-BR' ? DollarSign : Euro,
      color: 'from-[#00d749] to-[#00c441]',
      textColor: 'text-white'
    },
    {
      title: 'Em Satoshi',
      value: `${Math.round(totalSats)} sats`,
      icon: Zap,
      color: 'from-orange-500 to-amber-600',
      textColor: 'text-white'
    },
    {
      title: 'Aprovadas',
      value: approvedCount,
      icon: CheckCircle,
      color: 'from-blue-500 to-cyan-600',
      textColor: 'text-white'
    },
    {
      title: 'Em Andamento',
      value: pendingCount,
      icon: Clock,
      color: 'from-purple-500 to-pink-600',
      textColor: 'text-white'
    },
    {
      title: 'Total Solicitações',
      value: requests.length,
      icon: TrendingUp,
      color: 'from-indigo-500 to-violet-600',
      textColor: 'text-white'
    }
  ]

  return (
    <div className="overflow-x-auto scrollbar-hide -mx-4 px-4">
      <div className="flex gap-4 pb-2">
        {cards.map((card, index) => {
          const Icon = card.icon
          return (
            <div
              key={index}
              className={`min-w-[280px] bg-gradient-to-br ${card.color} rounded-2xl p-6 shadow-lg`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 bg-white/20 rounded-xl backdrop-blur-sm`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <p className="text-white/90 text-sm font-medium mb-1">{card.title}</p>
                <p className={`text-3xl font-bold ${card.textColor}`}>
                  {card.value}
                </p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
