import React, { useEffect, useState } from 'react'

interface X88LogoProps {
  width?: number
  height?: number
  className?: string
  variant?: 'default' | 'white' | 'auto'
}

const X88Logo: React.FC<X88LogoProps> = ({ 
  width = 80, 
  height = 80, 
  className = '',
  variant = 'default'
}) => {
  const [isDark, setIsDark] = useState(false)

  useEffect(() => {
    if (variant === 'auto') {
      const checkDarkMode = () => {
        setIsDark(document.documentElement.classList.contains('dark'))
      }
      
      checkDarkMode()
      
      const observer = new MutationObserver(checkDarkMode)
      observer.observe(document.documentElement, { 
        attributes: true, 
        attributeFilter: ['class'] 
      })
      
      return () => observer.disconnect()
    }
  }, [variant])

  const getLogoSrc = () => {
    if (variant === 'white') {
      return '/logos/LOGOTIPO X88 WHITE PNG.fw.png'
    }
    if (variant === 'auto' && isDark) {
      return '/logos/LOGOTIPO X88 WHITE PNG.fw.png'
    }
    return '/logos/x88.png'
  }

  return (
    <img
      src={getLogoSrc()}
      alt="X88 Logo"
      width={width}
      height={height}
      className={className}
      style={{ 
        width: `${width}px`, 
        height: `${height}px`,
        objectFit: 'contain'
      }}
    />
  )
}

export default X88Logo
