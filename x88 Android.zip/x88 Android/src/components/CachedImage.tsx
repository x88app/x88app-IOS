import { useState, useEffect, memo } from 'react'
import { loadImageWithCache } from '../lib/imageCache'

interface CachedImageProps {
  src: string
  alt?: string
  className?: string
  fallback?: React.ReactNode
  onLoad?: () => void
  onError?: () => void
}

export const CachedImage = memo(({ 
  src, 
  alt = '', 
  className = '', 
  fallback,
  onLoad,
  onError 
}: CachedImageProps) => {
  const [imageSrc, setImageSrc] = useState<string>('')
  const [isLoading, setIsLoading] = useState(true)
  const [hasError, setHasError] = useState(false)

  useEffect(() => {
    if (!src) {
      setIsLoading(false)
      setHasError(true)
      return
    }

    let isMounted = true
    setIsLoading(true)
    setHasError(false)

    loadImageWithCache(src)
      .then((cachedUrl) => {
        if (isMounted) {
          setImageSrc(cachedUrl)
          setIsLoading(false)
          onLoad?.()
        }
      })
      .catch(() => {
        if (isMounted) {
          setHasError(true)
          setIsLoading(false)
          onError?.()
        }
      })

    return () => {
      isMounted = false
    }
  }, [src, onLoad, onError])

  if (isLoading) {
    return (
      <div className={`${className} bg-neutral-200 dark:bg-neutral-800 animate-pulse`} />
    )
  }

  if (hasError || !imageSrc) {
    return fallback ? <>{fallback}</> : (
      <div className={`${className} bg-neutral-200 dark:bg-neutral-800 flex items-center justify-center`}>
        <svg className="w-8 h-8 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      </div>
    )
  }

  return (
    <img 
      src={imageSrc} 
      alt={alt} 
      className={className}
      loading="eager"
    />
  )
})

CachedImage.displayName = 'CachedImage'
