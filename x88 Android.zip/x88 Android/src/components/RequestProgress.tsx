import { Check, Clock, CreditCard, TrendingUp, X } from 'lucide-react'

interface RequestProgressProps {
  currentStep: number
  status: 'pending' | 'processing' | 'approved' | 'paid' | 'rejected' | 'canceled' | 'verifying'
  currency?: string
}

export function RequestProgress({ currentStep, status, currency }: RequestProgressProps) {
  const color = currency === 'SATS' ? '#E69F39' : '#00d749'
  const steps = [
    { label: 'Solicitação Enviada', icon: Clock },
    { label: 'Em Análise', icon: TrendingUp },
    { label: 'Processando', icon: CreditCard },
    { label: status === 'rejected' ? 'Negado' : status === 'canceled' ? 'Cancelado' : 'Aprovado', icon: (status === 'rejected' || status === 'canceled') ? X : Check },
    { label: 'Transferido', icon: Check },
  ]

  return (
    <div className="w-full">
      {/* Barra de Progresso */}
      <div className="relative mb-6">
        <div className="h-2 bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-1000 ease-out relative"
            style={{ width: `${(currentStep / 4) * 100}%`, backgroundColor: color }}
          >
            {/* Animação de brilho */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
          </div>
        </div>
      </div>

      {/* Steps */}
      <div className="flex justify-between relative">
        {steps.map((step, index) => {
          const Icon = step.icon
          const isActive = index <= currentStep
          const isCurrent = index === currentStep

          return (
            <div key={index} className="flex flex-col items-center flex-1">
              <div className="relative w-14 h-14 flex items-center justify-center">
                {isCurrent && isActive && status !== 'rejected' && (
                  <div 
                    className="absolute inset-0 rounded-full border-[3px] border-transparent animate-spin-slow"
                    style={{ 
                      borderTopColor: color, 
                      borderRightColor: color, 
                      borderBottomColor: color 
                    }}
                  ></div>
                )}
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 ${
                    isActive && status === 'rejected' && index === 3
                      ? 'bg-red-600 text-white scale-110 animate-pulse'
                      : isActive && status === 'canceled' && index === 3
                      ? 'bg-gray-500 text-white scale-110'
                      : isActive
                      ? 'text-white scale-110'
                      : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-400'
                  }`}
                  style={isActive && !(isActive && (status === 'rejected' || status === 'canceled') && index === 3) ? { backgroundColor: color } : {}}
                >
                  <Icon className="w-5 h-5" />
                </div>
              </div>
              <p
                className={`text-xs mt-2 text-center transition-colors ${
                  isActive && status === 'rejected' && index === 3
                    ? 'text-red-600 font-semibold'
                    : isActive && status === 'canceled' && index === 3
                    ? 'text-gray-500 font-semibold'
                    : isActive
                    ? 'font-semibold'
                    : 'text-neutral-400'
                }`}
                style={isActive && !(isActive && (status === 'rejected' || status === 'canceled') && index === 3) ? { color: color } : {}}
              >
                {step.label}
              </p>
            </div>
          )
        })}
      </div>
    </div>
  )
}
