import { useState, useEffect } from 'react'
import { Zap, TrendingUp, Clock, Wallet, Gift } from 'lucide-react'

const cardsData = [
  {
    id: 1,
    icon: Zap,
    title: 'O que é X88?',
    description: 'Aplicativo para motoristas solicitarem adiantamentos de forma rápida e eficiente',
    bgColor: 'bg-white dark:bg-neutral-900',
    borderColor: 'border-[#00d749]/20',
    iconBg: 'bg-[#00d749]/10',
    iconColor: 'text-[#00d749]',
  },
  {
    id: 2,
    icon: Wallet,
    title: 'Adiantamento Instantâneo',
    description: 'Receba via MB Way ou IBAN em até 1 dia útil. Rápido e sem complicações',
    bgColor: 'bg-white dark:bg-neutral-900',
    borderColor: 'border-blue-500/20',
    iconBg: 'bg-blue-500/10',
    iconColor: 'text-blue-500',
  },
  {
    id: 3,
    icon: TrendingUp,
    title: 'Aumente seu Limite',
    description: 'Quanto mais você usa e paga em dia, maior seu limite de crédito disponível',
    bgColor: 'bg-white dark:bg-neutral-900',
    borderColor: 'border-purple-500/20',
    iconBg: 'bg-purple-500/10',
    iconColor: 'text-purple-500',
  },
  {
    id: 4,
    icon: Clock,
    title: 'Disponível 24/7',
    description: 'Solicite adiantamentos a qualquer hora, qualquer dia da semana',
    bgColor: 'bg-white dark:bg-neutral-900',
    borderColor: 'border-orange-500/20',
    iconBg: 'bg-orange-500/10',
    iconColor: 'text-orange-500',
  },
  {
    id: 5,
    icon: Gift,
    title: 'Benefícios Exclusivos',
    description: 'Cashback, descontos em combustível e manutenção para motoristas X88',
    bgColor: 'bg-white dark:bg-neutral-900',
    borderColor: 'border-pink-500/20',
    iconBg: 'bg-pink-500/10',
    iconColor: 'text-pink-500',
  },
]

export const BenefitsGallery = () => {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [touchStart, setTouchStart] = useState(0)
  const [touchEnd, setTouchEnd] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % cardsData.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return
    
    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % cardsData.length)
    }
    if (isRightSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex - 1 + cardsData.length) % cardsData.length)
    }

    setTouchStart(0)
    setTouchEnd(0)
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setTouchStart(e.clientX)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (touchStart) {
      setTouchEnd(e.clientX)
    }
  }

  const handleMouseUp = () => {
    if (!touchStart || !touchEnd) return
    
    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % cardsData.length)
    }
    if (isRightSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex - 1 + cardsData.length) % cardsData.length)
    }

    setTouchStart(0)
    setTouchEnd(0)
  }

  return (
    <div className="relative overflow-hidden">
      <div 
        className="relative h-40 cursor-grab active:cursor-grabbing"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {cardsData.map((card, index) => {
          const Icon = card.icon
          const isActive = index === currentIndex
          const isPrev = index === (currentIndex - 1 + cardsData.length) % cardsData.length
          const isNext = index === (currentIndex + 1) % cardsData.length

          let positionClass = 'translate-x-[120%] opacity-0'
          if (isActive) positionClass = 'translate-x-0 opacity-100 scale-100'
          else if (isPrev) positionClass = '-translate-x-[120%] opacity-0'
          else if (isNext) positionClass = 'translate-x-[120%] opacity-0'

          return (
            <div
              key={card.id}
              className={`absolute inset-0 transition-all duration-700 ease-in-out ${positionClass}`}
            >
              <div className={`${card.bgColor} ${card.borderColor} border-2 rounded-2xl p-6 h-full shadow-sm`}>
                <div className="flex items-start gap-4">
                  <div className={`${card.iconBg} p-3 rounded-xl`}>
                    <Icon className={`w-6 h-6 ${card.iconColor}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-black dark:text-white mb-2">{card.title}</h3>
                    <p className="text-neutral-600 dark:text-neutral-400 text-sm leading-relaxed">
                      {card.description}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="flex justify-center gap-2 mt-4">
        {cardsData.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-2 rounded-full transition-all duration-300 ${
              index === currentIndex ? 'w-8 bg-[#00d749]' : 'w-2 bg-neutral-300 dark:bg-neutral-700'
            }`}
            aria-label={`Ir para card ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
