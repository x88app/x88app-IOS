import { useState, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { X, Euro, CreditCard, Smartphone, Check, ChevronRight } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { useRequests } from '../contexts/RequestsContext'
import { useNotifications } from '../contexts/NotificationsContext'
import { useLanguage } from '../contexts/LanguageContext'
import { formatNextMondayDate } from '../lib/dateUtils'

interface NewRequestModalProps {
  isOpen: boolean
  onClose: () => void
}

export const NewRequestModal = ({ isOpen, onClose }: NewRequestModalProps) => {
  const { addRequest } = useRequests()
  const { addNotification } = useNotifications()
  const { user } = useAuth()
  const { currencySymbol, language, formatCurrency: globalFormatCurrency } = useLanguage()
  const isBR = language === 'pt-BR'
  
  const interestRate = user?.interestRate || 10
  const interestRateDecimal = interestRate / 100
  const discountMultiplier = 1 + interestRateDecimal

  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    amount: '',
    payoutMethod: 'MBWAY',
    satoshiAmount: '',
  })
  const [displayAmount, setDisplayAmount] = useState('')
  const [isConfirmed, setIsConfirmed] = useState(false)
  const [isAnimating, setIsAnimating] = useState(false)
  const [lightningAddress, setLightningAddress] = useState('')
  const [mbwayPhone, setMbwayPhone] = useState('')
  const [iban, setIban] = useState('')
  const [showTermsModal, setShowTermsModal] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setIsAnimating(true)
      
      if (user?.bankDetails) {
        setMbwayPhone(user.bankDetails.mbwayPhone || '')
        setIban(user.bankDetails.iban || '')
        if (user.bankDetails.wallet) {
          setLightningAddress(user.bankDetails.wallet)
        }

        if (user.bankDetails.preferredMethod) {
          const method = user.bankDetails.preferredMethod.toUpperCase()
          if (['MBWAY', 'IBAN', 'SATOSHI'].includes(method)) {
            setFormData(prev => ({ ...prev, payoutMethod: method }))
          }
        }
      }

      const savedLightning = localStorage.getItem('lightningAddress')
      if (savedLightning && !user?.bankDetails?.wallet) {
        setLightningAddress(savedLightning)
      }

      if (!user?.bankDetails) {
        const savedBankDetails = localStorage.getItem('bankDetails')
        if (savedBankDetails) {
          try {
            const bankData = JSON.parse(savedBankDetails)
            setMbwayPhone(bankData.mbwayPhone || '')
            setIban(bankData.iban || '')
          } catch (error) {
            console.error('Erro ao carregar dados bancários:', error)
          }
        }
      }
    }
  }, [isOpen, user])

  if (!isOpen) return null

  const formatInputAmount = (value: string) => {
    const numbers = value.replace(/\D/g, '')
    if (!numbers) return ''
    const cents = parseInt(numbers)
    const amount = cents / 100
    if (language === 'pt-BR') {
      return amount.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    }
    return amount.toFixed(2)
  }

  const parseAmount = (value: string) => {
    if (!value) return 0
    if (language === 'pt-BR') {
      return parseFloat(value.replace(/\./g, '').replace(',', '.'))
    }
    return parseFloat(value)
  }

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    const formatted = formatInputAmount(value)
    setDisplayAmount(formatted)
    setFormData({ ...formData, amount: formatted })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (step < 2) {
      setStep(step + 1)
    } else {
      const isSatoshi = formData.payoutMethod === 'SATOSHI'
      const amount = isSatoshi ? parseInt(formData.satoshiAmount) : parseAmount(formData.amount)
      const discountAmount = amount * discountMultiplier
      
      let details = formData.payoutMethod
      if (formData.payoutMethod === 'MBWAY') details = mbwayPhone
      else if (formData.payoutMethod === 'IBAN') details = iban
      else if (isSatoshi) details = lightningAddress

      addRequest({
        amount,
        paymentMethod: formData.payoutMethod.toLowerCase() as 'mbway' | 'iban' | 'satoshi',
        status: 'pending',
        date: new Date().toISOString(),
        netAmount: discountAmount,
        accountDetails: details,
        currency: isSatoshi ? 'SATS' : 'EUR',
        lightningAddress: isSatoshi ? lightningAddress : undefined,
      })
      
      addNotification({
        title: 'Solicitação Enviada',
        message: isSatoshi 
          ? `Sua solicitação de ${amount} sats foi enviada com sucesso.`
          : `Sua solicitação de ${globalFormatCurrency(amount)} foi enviada com sucesso.`,
        type: 'info',
      })
      
      handleClose()
    }
  }

  const handleClose = () => {
    setStep(1)
    setFormData({ amount: '', payoutMethod: 'MBWAY', satoshiAmount: '' })
    setDisplayAmount('')
    setIsConfirmed(false)
    onClose()
  }

  const canProceed = () => {
    return formData.amount && parseAmount(formData.amount) > 0
  }

  const getMethodIcon = (method: string) => {
    if (method === 'SATOSHI') return <img src="/logos/BITCOIN.png" alt="BTC" className="w-5 h-5" />
    if (method === 'MBWAY') return <Smartphone className="w-5 h-5 text-[#00d749]" />
    return <CreditCard className="w-5 h-5 text-[#00d749]" />
  }

  const getMethodName = (method: string) => {
    if (method === 'SATOSHI') return 'Lightning'
    if (method === 'MBWAY') return isBR ? 'PIX' : 'MB Way'
    return isBR ? 'Conta' : 'IBAN'
  }

  const getMethodDetail = (method: string) => {
    if (method === 'SATOSHI') return lightningAddress
    if (method === 'MBWAY') return mbwayPhone
    return iban
  }

  const modalContent = (
    <div 
      className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 transition-opacity duration-300 ${
        isAnimating ? 'opacity-100' : 'opacity-0'
      }`}
      onClick={handleClose}
    >
      <div 
        className={`bg-white dark:bg-neutral-900 w-full max-w-md rounded-2xl shadow-2xl transition-all duration-300 ${
          isAnimating ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header compacto */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#00d749]/10 flex items-center justify-center">
              <Euro className="w-5 h-5 text-[#00d749]" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-black dark:text-white">
                {step === 1 ? 'Novo Adiantamento' : 'Confirmar'}
              </h2>
              <p className="text-xs text-neutral-500">{step}/2</p>
            </div>
          </div>
          <button onClick={handleClose} className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
            <X className="w-5 h-5 text-neutral-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          {step === 1 && (
            <div className="p-4 space-y-4">
              {/* Input de valor - muda baseado no método */}
              {formData.payoutMethod === 'SATOSHI' ? (
                <div className="bg-[#f7931a]/5 border-2 border-[#f7931a]/30 rounded-2xl p-4">
                  <label className="text-xs font-medium text-[#f7931a] uppercase tracking-wider flex items-center gap-2">
                    <img src="/logos/BITCOIN.png" alt="BTC" className="w-4 h-4" />
                    Quantidade de Satoshi
                  </label>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-3xl font-bold text-[#f7931a]">₿</span>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={formData.satoshiAmount}
                      onChange={(e) => {
                        const value = e.target.value.replace(/\D/g, '')
                        const euroValue = (parseInt(value || '0') * 0.00003).toFixed(2)
                        setFormData({ ...formData, satoshiAmount: value, amount: euroValue })
                        setDisplayAmount(euroValue)
                      }}
                      className="flex-1 text-3xl font-bold bg-transparent border-none outline-none text-[#f7931a] placeholder-[#f7931a]/40"
                      placeholder="0"
                      autoFocus
                    />
                    <span className="text-lg text-[#f7931a]/60">sats</span>
                  </div>
                  {formData.satoshiAmount && (
                    <p className="text-xs text-[#f7931a]/70 mt-2">
                      A descontar: <span className="font-semibold text-[#f7931a]">{Math.round(parseInt(formData.satoshiAmount) * discountMultiplier)} sats</span>
                      <span className="text-[#f7931a]/50"> ({interestRate}% taxa)</span>
                    </p>
                  )}
                </div>
              ) : (
                <div className="bg-[#00d749]/5 border-2 border-[#00d749]/20 rounded-2xl p-4">
                  <label className="text-xs font-medium text-[#00d749] uppercase tracking-wider">
                    Valor do Adiantamento
                  </label>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-3xl font-bold text-[#00d749]">{currencySymbol}</span>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={displayAmount}
                      onChange={handleAmountChange}
                      className="flex-1 text-3xl font-bold bg-transparent border-none outline-none text-[#00d749] placeholder-[#00d749]/30"
                      placeholder="0,00"
                      autoFocus
                    />
                  </div>
                  {formData.amount && (
                    <p className="text-xs text-[#00d749]/70 mt-2">
                      A descontar: <span className="font-semibold text-amber-600">{globalFormatCurrency(parseAmount(formData.amount) * discountMultiplier)}</span>
                      <span className="text-[#00d749]/50"> ({interestRate}% taxa)</span>
                    </p>
                  )}
                </div>
              )}

              {/* Métodos de pagamento - compactos em linha */}
              <div>
                <label className="text-xs font-medium text-neutral-500 uppercase tracking-wider mb-2 block">
                  Receber via
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {/* MB Way / PIX */}
                  <button
                    type="button"
                    onClick={() => mbwayPhone && setFormData({ ...formData, payoutMethod: 'MBWAY' })}
                    disabled={!mbwayPhone}
                    className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1 ${
                      !mbwayPhone
                        ? 'border-neutral-100 dark:border-neutral-800 opacity-40'
                        : formData.payoutMethod === 'MBWAY'
                        ? 'border-[#00d749] bg-[#00d749]/5'
                        : 'border-neutral-200 dark:border-neutral-700'
                    }`}
                  >
                    <Smartphone className={`w-5 h-5 ${formData.payoutMethod === 'MBWAY' ? 'text-[#00d749]' : 'text-neutral-400'}`} />
                    <span className={`text-xs font-medium ${formData.payoutMethod === 'MBWAY' ? 'text-[#00d749]' : 'text-neutral-600 dark:text-neutral-400'}`}>
                      {isBR ? 'PIX' : 'MB Way'}
                    </span>
                  </button>

                  {/* IBAN / Conta */}
                  <button
                    type="button"
                    onClick={() => iban && setFormData({ ...formData, payoutMethod: 'IBAN' })}
                    disabled={!iban}
                    className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1 ${
                      !iban
                        ? 'border-neutral-100 dark:border-neutral-800 opacity-40'
                        : formData.payoutMethod === 'IBAN'
                        ? 'border-[#00d749] bg-[#00d749]/5'
                        : 'border-neutral-200 dark:border-neutral-700'
                    }`}
                  >
                    <CreditCard className={`w-5 h-5 ${formData.payoutMethod === 'IBAN' ? 'text-[#00d749]' : 'text-neutral-400'}`} />
                    <span className={`text-xs font-medium ${formData.payoutMethod === 'IBAN' ? 'text-[#00d749]' : 'text-neutral-600 dark:text-neutral-400'}`}>
                      {isBR ? 'Conta' : 'IBAN'}
                    </span>
                  </button>

                  {/* Bitcoin */}
                  <button
                    type="button"
                    onClick={() => lightningAddress && setFormData({ ...formData, payoutMethod: 'SATOSHI' })}
                    disabled={!lightningAddress}
                    className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1 ${
                      !lightningAddress
                        ? 'border-neutral-100 dark:border-neutral-800 opacity-40'
                        : formData.payoutMethod === 'SATOSHI'
                        ? 'border-[#f7931a] bg-[#f7931a]/5'
                        : 'border-neutral-200 dark:border-neutral-700'
                    }`}
                  >
                    <img src="/logos/BITCOIN.png" alt="BTC" className={`w-5 h-5 ${!lightningAddress ? 'opacity-40' : ''}`} />
                    <span className={`text-xs font-medium ${formData.payoutMethod === 'SATOSHI' ? 'text-[#f7931a]' : 'text-neutral-600 dark:text-neutral-400'}`}>
                      Bitcoin
                    </span>
                  </button>
                </div>

                {/* Detalhe do método selecionado */}
                {getMethodDetail(formData.payoutMethod) && (
                  <p className="text-xs text-neutral-500 mt-2 text-center truncate">
                    {getMethodDetail(formData.payoutMethod)}
                  </p>
                )}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="p-4 space-y-3">
              {/* Resumo compacto */}
              <div className={`rounded-xl p-4 flex justify-between items-center ${
                formData.payoutMethod === 'SATOSHI' ? 'bg-[#f7931a]/5' : 'bg-[#00d749]/5'
              }`}>
                <div>
                  <p className={`text-xs font-medium ${formData.payoutMethod === 'SATOSHI' ? 'text-[#f7931a]' : 'text-[#00d749]'}`}>
                    Você receberá
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    {getMethodIcon(formData.payoutMethod)}
                    <span className="text-xs text-neutral-500">{getMethodName(formData.payoutMethod)}</span>
                  </div>
                </div>
                <p className={`text-2xl font-bold ${formData.payoutMethod === 'SATOSHI' ? 'text-[#f7931a]' : 'text-[#00d749]'}`}>
                  {formData.payoutMethod === 'SATOSHI' 
                    ? `${formData.satoshiAmount} sats`
                    : globalFormatCurrency(parseAmount(formData.amount))
                  }
                </p>
              </div>

              {/* Detalhes */}
              <div className="bg-neutral-50 dark:bg-neutral-800/30 rounded-xl divide-y divide-neutral-100 dark:divide-neutral-800">
                <div className="flex justify-between p-3">
                  <span className="text-sm text-neutral-500">Taxa de serviço</span>
                  <span className="text-sm font-medium text-amber-600">
                    {formData.payoutMethod === 'SATOSHI'
                      ? `+${Math.round(parseInt(formData.satoshiAmount || '0') * interestRateDecimal)} sats (${interestRate}%)`
                      : `+${globalFormatCurrency(parseAmount(formData.amount) * interestRateDecimal)} (${interestRate}%)`
                    }
                  </span>
                </div>
                <div className="flex justify-between p-3">
                  <span className="text-sm text-neutral-500">A descontar</span>
                  <span className="text-sm font-bold text-red-600">
                    {formData.payoutMethod === 'SATOSHI'
                      ? `${Math.round(parseInt(formData.satoshiAmount || '0') * discountMultiplier)} sats`
                      : globalFormatCurrency(parseAmount(formData.amount) * discountMultiplier)
                    }
                  </span>
                </div>
                <div className="flex justify-between p-3">
                  <span className="text-sm text-neutral-500">Data prevista</span>
                  <span className="text-sm text-neutral-700 dark:text-neutral-300">{formatNextMondayDate()}</span>
                </div>
              </div>

              {/* Confirmação compacta */}
              <button
                type="button"
                onClick={() => setIsConfirmed(!isConfirmed)}
                className={`w-full p-3 rounded-xl flex items-center gap-3 transition-all ${
                  isConfirmed 
                    ? 'bg-[#00d749]/10 ring-2 ring-[#00d749]' 
                    : 'bg-neutral-50 dark:bg-neutral-800/30'
                }`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                  isConfirmed ? 'bg-[#00d749]' : 'border-2 border-neutral-300'
                }`}>
                  {isConfirmed && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                </div>
                <span className="text-sm text-neutral-700 dark:text-neutral-300 text-left">
                  Aceito os{' '}
                  <span 
                    className="text-[#00d749] font-medium"
                    onClick={(e) => { e.stopPropagation(); setShowTermsModal(true) }}
                  >
                    termos e condições
                  </span>
                </span>
              </button>
            </div>
          )}

          {/* Botões fixos no rodapé */}
          <div className="p-4 border-t border-neutral-100 dark:border-neutral-800 flex gap-3">
            {step === 2 && (
              <button type="button" onClick={() => setStep(1)} className="btn-secondary flex-1">
                Voltar
              </button>
            )}
            <button
              type="submit"
              disabled={step === 2 ? !isConfirmed : !canProceed()}
              className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {step === 2 ? 'Enviar' : 'Continuar'}
              {step === 1 && <ChevronRight className="w-4 h-4" />}
            </button>
          </div>
        </form>
      </div>
    </div>
  )

  const termsModal = showTermsModal && (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
      style={{ zIndex: 100001 }}
      onClick={() => setShowTermsModal(false)}
    >
      <div 
        className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-md max-h-[80vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
          <h3 className="text-lg font-bold text-black dark:text-white">Termos e Condições</h3>
          <button onClick={() => setShowTermsModal(false)} className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800">
            <X className="w-5 h-5 text-neutral-400" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-sm text-neutral-600 dark:text-neutral-400">
          <section>
            <h4 className="font-bold text-black dark:text-white mb-1">1. Adiantamento</h4>
            <p>O serviço permite solicitar antecipação de ganhos, sujeito à aprovação do gestor.</p>
          </section>
          <section>
            <h4 className="font-bold text-black dark:text-white mb-1">2. Taxa de Serviço</h4>
            <p>Taxa de {interestRate}% será aplicada e acrescida ao valor a descontar. Você recebe o valor integral.</p>
          </section>
          <section>
            <h4 className="font-bold text-black dark:text-white mb-1">3. Processamento</h4>
            <p>Solicitações são processadas em dias úteis, sujeitas à aprovação.</p>
          </section>
          <section>
            <h4 className="font-bold text-black dark:text-white mb-1">4. Cancelamento</h4>
            <p>Cancelamento possível apenas com status "Pendente".</p>
          </section>
        </div>
        
        <div className="p-4 border-t border-neutral-200 dark:border-neutral-800">
          <button onClick={() => setShowTermsModal(false)} className="btn-primary w-full">
            Entendi
          </button>
        </div>
      </div>
    </div>
  )

  return (
    <>
      {createPortal(modalContent, document.body)}
      {showTermsModal && createPortal(termsModal, document.body)}
    </>
  )
}
