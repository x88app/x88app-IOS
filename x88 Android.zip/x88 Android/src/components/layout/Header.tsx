import { Bell, Moon, Sun, Rss } from 'lucide-react'
import { useState, useEffect, useRef } from 'react'
import { useLocation } from 'react-router-dom'
import X88Logo from '../ui/X88Logo'
import { useNotifications } from '../../contexts/NotificationsContext'
import { NotificationsPanel } from '../NotificationsPanel'
import { FeedPanel } from '../FeedPanel'

const Header = () => {
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('darkMode')
    if (saved !== null) {
      return saved === 'true'
    }
    return document.documentElement.classList.contains('dark')
  })
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [feedOpen, setFeedOpen] = useState(false)
  const [bellShake, setBellShake] = useState(false)
  const [bellPosition, setBellPosition] = useState({ x: 0, y: 0 })
  const [feedPosition, setFeedPosition] = useState({ x: 0, y: 0 })
  const [isScrolled, setIsScrolled] = useState(false)
  const bellButtonRef = useRef<HTMLButtonElement>(null)
  const feedButtonRef = useRef<HTMLButtonElement>(null)
  const { unreadCount, markAllAsRead } = useNotifications()
  const location = useLocation()
  
  const isHomePage = location.pathname === '/'

  useEffect(() => {
    if (bellButtonRef.current) {
      const rect = bellButtonRef.current.getBoundingClientRect()
      setBellPosition({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      })
    }
    if (feedButtonRef.current) {
      const rect = feedButtonRef.current.getBoundingClientRect()
      setFeedPosition({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      })
    }
  }, [])

  useEffect(() => {
    if (!isHomePage) {
      setIsScrolled(false)
      return
    }

    let ticking = false

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const rootElement = document.getElementById('root')
          const scrollTop = rootElement?.scrollTop || 0
          console.log('SCROLL DETECTADO:', scrollTop, 'isScrolled será:', scrollTop > 0)
          setIsScrolled(scrollTop > 0)
          ticking = false
        })
        ticking = true
      }
    }

    const rootElement = document.getElementById('root')
    console.log('Root element encontrado:', !!rootElement)
    
    if (rootElement) {
      rootElement.addEventListener('scroll', handleScroll, { passive: true })
      handleScroll()
      
      return () => {
        rootElement.removeEventListener('scroll', handleScroll)
      }
    }
  }, [isHomePage])

  useEffect(() => {
    setBellShake(true)
    const shakeTimeout = setTimeout(() => setBellShake(false), 500)
    
    let readTimeout: ReturnType<typeof setTimeout>

    if (notificationsOpen) {
      if (bellButtonRef.current) {
        const rect = bellButtonRef.current.getBoundingClientRect()
        setBellPosition({
          x: rect.left + rect.width / 2,
          y: rect.top + rect.height / 2
        })
      }
      if (unreadCount > 0) {
        readTimeout = setTimeout(() => markAllAsRead(), 800)
      }
    }

    return () => {
      clearTimeout(shakeTimeout)
      if (readTimeout) clearTimeout(readTimeout)
    }
  }, [notificationsOpen, unreadCount, markAllAsRead])

  // Aplicar dark mode ao carregar
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [])

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode
    setDarkMode(newDarkMode)
    localStorage.setItem('darkMode', String(newDarkMode))
    if (newDarkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }

  const [forceDarkIcons, setForceDarkIcons] = useState(false)
  
  useEffect(() => {
    const checkBodyClass = () => {
      const shouldForceDark = document.body.classList.contains('header-icons-dark')
      setForceDarkIcons(shouldForceDark)
    }
    
    checkBodyClass()
    const observer = new MutationObserver(checkBodyClass)
    observer.observe(document.body, { attributes: true, attributeFilter: ['class'] })
    
    return () => observer.disconnect()
  }, [])
  
  const showIcons = isHomePage
  const iconColorClass = forceDarkIcons ? 'text-black dark:text-black' : 'text-white'
  const buttonClass = forceDarkIcons 
    ? 'w-9 h-9 rounded-full bg-black/10 dark:bg-black/20 flex items-center justify-center hover:bg-black/20 dark:hover:bg-black/30 transition-colors' 
    : 'p-2 rounded-lg hover:bg-white/20 transition-colors'

  return (
    <>
      <header className={`absolute top-0 left-0 right-0 z-50 ${!showIcons ? 'pointer-events-none' : ''}`}>
        <div style={{ paddingTop: 56 }} className={`pl-2 pr-4 py-1 flex items-center justify-end ${forceDarkIcons ? 'pr-6' : ''}`}>
          <div className={`flex items-center gap-2 ${
            showIcons ? '' : 'opacity-0 pointer-events-none'
          }`}>
            <button
              ref={feedButtonRef}
              onClick={() => setFeedOpen(!feedOpen)}
              className={buttonClass}
              aria-label="Feed"
            >
              <Rss className={`w-5 h-5 ${iconColorClass}`} />
            </button>
            <button
              onClick={toggleDarkMode}
              className={buttonClass}
              aria-label="Toggle dark mode"
            >
              {darkMode ? (
                <Sun className={`w-5 h-5 ${iconColorClass}`} />
              ) : (
                <Moon className={`w-5 h-5 ${iconColorClass}`} />
              )}
            </button>
            <button
              ref={bellButtonRef}
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className={`${buttonClass} relative`}
              aria-label="Notificações"
            >
              <Bell 
                className={`w-5 h-5 transition-all ${iconColorClass} ${
                  bellShake ? 'animate-bell-ring' : ''
                } ${unreadCount > 0 && !forceDarkIcons ? 'fill-white' : ''} ${unreadCount > 0 && forceDarkIcons ? 'fill-black dark:fill-black' : ''}`}
              />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[20px] h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center px-1.5 animate-pulse">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      <NotificationsPanel 
        isOpen={notificationsOpen} 
        onClose={() => setNotificationsOpen(false)}
        bellPosition={bellPosition}
      />

      <FeedPanel
        isOpen={feedOpen}
        onClose={() => setFeedOpen(false)}
        buttonPosition={feedPosition}
      />
    </>
  )
}

export default Header
