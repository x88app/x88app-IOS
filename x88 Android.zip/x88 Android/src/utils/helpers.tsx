import { Clock, CheckCircle, XCircle } from 'lucide-react'

export const getStatusBadge = (status: string) => {
  switch (status.toUpperCase()) {
    case 'PENDING':
    case 'PROCESSING':
      return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-500/20 text-yellow-600">Pendente</span>
    case 'APPROVED':
      return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#00d749]/20 text-[#00d749]">Aprovada</span>
    case 'REJECTED':
      return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-600">Rejeitada</span>
    case 'CANCELED':
      return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-gray-500/20 text-gray-600">Cancelada</span>
    case 'PAID':
      return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#00d749]/20 text-[#00d749]">Paga</span>
    case 'VERIFYING':
      return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-500/20 text-yellow-600">Pendente</span>
    default:
      return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-500/20 text-yellow-600">Pendente</span>
  }
}

export const getStatusIcon = (status: string) => {
  switch (status.toUpperCase()) {
    case 'PENDING':
    case 'PROCESSING':
    case 'VERIFYING':
      return <Clock className="w-4 h-4 text-yellow-600" />
    case 'APPROVED':
    case 'PAID':
      return <CheckCircle className="w-4 h-4 text-[#00d749]" />
    case 'REJECTED':
      return <XCircle className="w-4 h-4 text-red-600" />
    case 'CANCELED':
      return <XCircle className="w-4 h-4 text-gray-600" />
    default:
      return <Clock className="w-4 h-4 text-yellow-600" />
  }
}

export const formatCurrency = (value: number, currency: 'EUR' | 'SATS') => {
  if (currency === 'SATS') {
    return `${Math.round(value)} sats`
  }
  // This is a fallback/legacy helper. 
  // Prefer using useLanguage().formatCurrency for dynamic currency symbol support.
  // But if this is called, we'll default to Euro with comma decimal for PT-style consistency if possible,
  // though ideally this function shouldn't be used for display where Region matters.
  return `€${value.toFixed(2)}` 
}

export const formatDate = (date: string | number) => {
  const dateObj = typeof date === 'string' ? new Date(date) : new Date(date)
  return dateObj.toLocaleDateString('pt-PT', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

export const getPaymentMethodLabel = (method: string, isBR: boolean = false) => {
  if (method === 'mbway') return isBR ? 'PIX' : 'MB Way'
  if (method === 'satoshi') return 'Satoshi (Lightning)'
  return isBR ? 'Conta Bancária' : 'IBAN'
}
