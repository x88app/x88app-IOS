import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CheckCircle } from 'lucide-react'

const InitialSetup = () => {
  const navigate = useNavigate()
  const [step, setStep] = useState(1)

  const handleComplete = () => {
    navigate('/')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00d749] to-[#00dc43] flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-neutral-900 rounded-3xl shadow-2xl p-8 max-w-md w-full">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-[#00d749]/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-[#00d749]" />
            </div>
            <h1 className="text-3xl font-bold text-black dark:text-white mb-2">
              Configuração Inicial
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400">
              Complete seu perfil para começar
            </p>
          </div>

          <button
            onClick={handleComplete}
            className="w-full bg-[#00d749] text-white py-4 rounded-xl font-semibold hover:bg-[#00dc43] transition-colors"
          >
            Começar
          </button>
        </div>
      </div>
    </div>
  )
}

export default InitialSetup
