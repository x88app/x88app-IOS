import { User, CreditCard, Bell, Shield, LogOut, ChevronRight, Globe, Trash2, FileText, Lock, HelpCircle, Camera, X, Upload, RefreshCw, ArrowLeft } from 'lucide-react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { useLanguage } from '../../contexts/LanguageContext'
import { useState, useRef, useEffect } from 'react'
import { LogoutModal } from '../../components/LogoutModal'
import { DeleteAccountModal } from '../../components/DeleteAccountModal'
import { supabase } from '../../lib/supabase'
import { loadImageWithCache } from '../../lib/imageCache'

const Profile = () => {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const fromChatPopup = searchParams.get('from') === 'chatpopup'
  const { user, logout, login, updateAvatar } = useAuth()
  const { language } = useLanguage()
  const isBR = language === 'pt-BR'
  const [showLogoutModal, setShowLogoutModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false)
  const [cachedAvatarUrl, setCachedAvatarUrl] = useState<string>('')
  const [showPhotoModal, setShowPhotoModal] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (user?.avatarUrl) {
      loadImageWithCache(user.avatarUrl).then(setCachedAvatarUrl)
    }
  }, [user?.avatarUrl])

  const handleLogout = () => {
    logout()
    navigate('/auth/login')
  }

  const handleDeleteAccount = async (password: string) => {
    setIsDeleting(true)
    try {
      // 1. Verificar senha fazendo login
      const { error: loginError, success } = await login(user?.email || '', password)
      
      if (!success || loginError) {
        alert('Senha incorreta. Por favor, tente novamente.')
        setIsDeleting(false)
        throw new Error('Senha incorreta')
      }

      // 2. Chamar função RPC para deletar conta
      const { error: deleteError } = await supabase.rpc('delete_own_account')
      
      if (deleteError) throw deleteError

      // 3. Logout e redirecionar
      await logout()
      navigate('/auth/login')
      
    } catch (error: any) {
      console.error('Erro ao excluir conta:', error)
      if (error.message !== 'Senha incorreta') {
          alert('Erro ao excluir conta. Tente novamente.')
      }
      setIsDeleting(false)
      throw error
    }
  }

  const handleAvatarClick = () => {
    fileInputRef.current?.click()
  }

  const handlePhotoView = () => {
    setShowPhotoModal(true)
  }

  const handleRemovePhoto = async () => {
    if (!confirm('Tem certeza que deseja remover sua foto?')) return
    
    setIsUploadingAvatar(true)
    try {
      const result = await updateAvatar(null)
      if (!result.success) {
        alert('Erro ao remover foto: ' + result.error)
      } else {
        setCachedAvatarUrl('')
        setShowPhotoModal(false)
      }
    } catch (error) {
      console.error('Erro ao remover foto:', error)
      alert('Erro ao remover foto.')
    } finally {
      setIsUploadingAvatar(false)
    }
  }

  const handleChangePhotoFromModal = () => {
    setShowPhotoModal(false)
    fileInputRef.current?.click()
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validar tipo de arquivo
    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione uma imagem válida.')
      return
    }

    // Validar tamanho (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('A imagem deve ter no máximo 5MB.')
      return
    }

    setIsUploadingAvatar(true)
    try {
      const result = await updateAvatar(file)
      if (!result.success) {
        alert('Erro ao atualizar foto: ' + result.error)
      }
    } catch (error) {
      console.error('Erro ao fazer upload:', error)
      alert('Erro ao fazer upload da foto.')
    } finally {
      setIsUploadingAvatar(false)
      // Limpar input para permitir selecionar a mesma imagem novamente
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  if (!user) {
    return null
  }

  const menuItems = [
    {
      icon: User,
      label: 'Dados Pessoais',
      description: 'Nome, email, telefone',
      path: '/profile/personal',
    },
    {
      icon: CreditCard,
      label: 'Dados Bancários',
      description: isBR ? 'PIX e Conta Bancária' : 'IBAN e MB Way',
      path: '/profile/bank',
    },
    {
      icon: Bell,
      label: 'Notificações',
      description: 'Preferências de notificação',
      path: '/profile/notifications',
    },
    {
      icon: Shield,
      label: 'Privacidade e Segurança',
      description: 'Senha e permissões',
      path: '/profile/security',
    },
    {
      icon: Globe,
      label: 'Idioma e Região',
      description: 'Fuso horário e idioma',
      path: '/profile/language',
    },
    {
      icon: HelpCircle,
      label: 'Ajuda',
      description: 'Suporte e dúvidas',
      path: '/profile/help',
    },
  ]

  const legalItems = [
    {
      icon: FileText,
      label: 'Termos de Uso',
      description: 'Leia os termos do serviço',
      path: '/legal/terms',
    },
    {
      icon: Lock,
      label: 'Política de Privacidade',
      description: 'Como protegemos seus dados',
      path: '/legal/privacy',
    },
  ]

  const handleBackToChat = () => {
    sessionStorage.setItem('x88_chat_return', 'true')
    navigate('/')
  }

  return (
    <div className="p-4 pt-14 space-y-6 pb-40">
      {/* Header com botão de voltar quando vem do chat */}
      {fromChatPopup && (
        <button
          onClick={handleBackToChat}
          className="flex items-center gap-2 text-[#00d749] font-medium -mt-2 mb-2"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar ao Chat
        </button>
      )}
      
      <div>
        <h2 className="text-2xl font-bold text-black dark:text-white">Meu Perfil</h2>
        <p className="text-neutral-600 dark:text-neutral-400 mt-1">
          Gerencie suas informações pessoais
        </p>
      </div>

      {/* Input oculto para upload de foto */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Card do usuário */}
      <div className="card bg-[#00d749] text-white">
        <div className="flex items-center gap-3">
          {/* Área do Avatar - círculo à esquerda */}
          <div className="relative flex-shrink-0">
            <button 
              onClick={handleAvatarClick}
              disabled={isUploadingAvatar}
              className="w-16 h-16 rounded-full bg-white/20 border-2 border-white/40 flex items-center justify-center overflow-hidden cursor-pointer hover:bg-white/30 transition-all"
            >
              {isUploadingAvatar ? (
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (cachedAvatarUrl || user.avatarUrl) ? (
                <img 
                  src={cachedAvatarUrl || user.avatarUrl} 
                  alt={user.name} 
                  className="w-full h-full object-cover"
                  onClick={(e) => {
                    e.stopPropagation()
                    handlePhotoView()
                  }}
                />
              ) : (
                <Camera className="w-6 h-6 text-white" />
              )}
            </button>
            {/* Badge de câmera */}
            <div className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full bg-white shadow-lg flex items-center justify-center">
              <Camera className="w-3.5 h-3.5 text-[#00d749]" />
            </div>
          </div>
          {/* Info do usuário */}
          <div className="flex-1">
            <h3 className="text-xl font-bold">{user.name}</h3>
            <p className="text-sm opacity-90">{user.email}</p>
          </div>
        </div>
      </div>

      {/* Menu de opções */}
      <div className="flex flex-col gap-3">
        {menuItems.map((item) => {
          const Icon = item.icon
          return (
            <Link key={item.path} to={item.path}>
              <div className="card p-4 hover:shadow-lg flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#00d749]/10 flex items-center justify-center">
                  <Icon className="w-6 h-6 text-[#00d749]" />
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-black dark:text-white">{item.label}</h4>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    {item.description}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-neutral-400" />
              </div>
            </Link>
          )
        })}
      </div>

      {/* Informações da conta */}
      <div className="card">
        <h3 className="text-lg font-bold text-black dark:text-white mb-4">Informações da Conta</h3>
        <div className="space-y-5">
          <div className="flex justify-between py-2 border-b border-neutral-200 dark:border-neutral-800">
            <span className="text-neutral-600 dark:text-neutral-400">Telefone</span>
            <span className="font-medium text-black dark:text-white">{user.phone}</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-neutral-600 dark:text-neutral-400">Status</span>
            <span className="status-success">Ativo</span>
          </div>
        </div>
      </div>

      {/* Informações Legais */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-bold text-neutral-500 uppercase tracking-wider">Informações Legais</h3>
        {legalItems.map((item) => {
          const Icon = item.icon
          return (
            <Link key={item.path} to={item.path}>
              <div className="card p-4 hover:shadow-lg flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center">
                  <Icon className="w-6 h-6 text-neutral-600 dark:text-neutral-400" />
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-black dark:text-white">{item.label}</h4>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    {item.description}
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-neutral-400" />
              </div>
            </Link>
          )
        })}
      </div>

      {/* Botão de sair */}
      <div className="space-y-3">
        <button 
          onClick={() => setShowLogoutModal(true)}
          className="w-full card p-4 hover:shadow-lg flex items-center justify-center gap-2 text-neutral-600 dark:text-neutral-400"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sair da Conta</span>
        </button>

        <button 
          onClick={() => setShowDeleteModal(true)}
          className="w-full card p-4 hover:shadow-lg flex items-center justify-center gap-2 text-red-600 bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30"
        >
          <Trash2 className="w-5 h-5" />
          <span className="font-medium">Excluir Minha Conta</span>
        </button>
      </div>

      <LogoutModal
        isOpen={showLogoutModal}
        onClose={() => setShowLogoutModal(false)}
        onConfirm={handleLogout}
      />

      <DeleteAccountModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        onConfirm={handleDeleteAccount}
        isLoading={isDeleting}
      />

      {/* Modal de visualização da foto */}
      {showPhotoModal && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4"
          onClick={() => setShowPhotoModal(false)}
        >
          <button
            onClick={() => setShowPhotoModal(false)}
            className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
          
          {(cachedAvatarUrl || user?.avatarUrl) ? (
            <>
              <img
                src={cachedAvatarUrl || user?.avatarUrl}
                alt={user?.name}
                className="max-w-full max-h-[60vh] rounded-2xl object-contain mb-6"
                onClick={(e) => e.stopPropagation()}
              />
              <div className="flex gap-3" onClick={(e) => e.stopPropagation()}>
                <button
                  onClick={handleChangePhotoFromModal}
                  disabled={isUploadingAvatar}
                  className="flex items-center justify-center gap-2 w-36 py-2.5 bg-white/10 text-white rounded-lg text-sm font-medium hover:bg-white/20 transition-colors border border-white/20"
                >
                  <RefreshCw className="w-4 h-4" />
                  Trocar
                </button>
                <button
                  onClick={handleRemovePhoto}
                  disabled={isUploadingAvatar}
                  className="flex items-center justify-center gap-2 w-36 py-2.5 bg-white/10 text-red-400 rounded-lg text-sm font-medium hover:bg-red-500/20 transition-colors border border-white/20"
                >
                  {isUploadingAvatar ? (
                    <div className="w-4 h-4 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4" />
                  )}
                  Remover
                </button>
              </div>
            </>
          ) : (
            <div 
              className="flex flex-col items-center gap-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-48 h-48 rounded-full bg-white/10 border-2 border-dashed border-white/40 flex items-center justify-center">
                <Camera className="w-16 h-16 text-white/60" />
              </div>
              <p className="text-white/80 text-lg">Nenhuma foto de perfil</p>
              <button
                onClick={handleChangePhotoFromModal}
                className="flex items-center gap-2 px-6 py-3 bg-[#00d749] text-white rounded-xl font-medium hover:bg-[#00c142] transition-colors"
              >
                <Upload className="w-5 h-5" />
                Upload de Foto
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default Profile
