import { useState, useEffect } from 'react'
import { ArrowLeft, User, Mail, Phone, Hash, CheckCircle, AlertCircle } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import { useToast } from '../../contexts/ToastContext'
import { useBackNavigation } from '../../hooks/useBackNavigation'

const PersonalData = () => {
  const { goBack } = useBackNavigation('/profile')
  const { user, updatePersonalData } = useAuth()
  const { showToast } = useToast()
  const [isEditing, setIsEditing] = useState(false)
  const [countryCode, setCountryCode] = useState('+351')
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    nif: '',
  })

  useEffect(() => {
    if (user) {
      let phone = user.phone || ''
      let code = '+351'

      if (phone.startsWith('+55')) {
        code = '+55'
        phone = phone.substring(3)
      } else if (phone.startsWith('+351')) {
        code = '+351'
        phone = phone.substring(4)
      }

      setCountryCode(code)
      setFormData({
        name: user.name,
        email: user.email,
        phone: phone,
        nif: user.nif
      })
    }
  }, [user])

  const handleSave = async () => {
    try {
      if (countryCode === '+351' && formData.phone.length !== 9) {
        showToast('Para Portugal, o telefone deve ter 9 dígitos', 'error')
        return
      }
      if (countryCode === '+55' && formData.phone.length !== 11) {
        showToast('Para o Brasil, o telefone deve ter 11 dígitos (DDD + Número)', 'error')
        return
      }

      const fullPhone = `${countryCode}${formData.phone}`

      const { success, error } = await updatePersonalData({
        name: formData.name,
        email: formData.email,
        phone: fullPhone,
        nif: formData.nif
      })
      
      if (success) {
        showToast('Dados pessoais atualizados com sucesso!', 'success')
        setIsEditing(false)
      } else {
        showToast('Erro ao atualizar dados: ' + error, 'error')
      }
    } catch (err) {
      showToast('Erro ao atualizar dados.', 'error')
    }
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '')
    setFormData({ ...formData, phone: value })
  }

  return (
    <div className="p-4 pt-14 space-y-6 pb-40">
      <div className="flex items-center gap-3 mb-2">
        <button
          type="button"
          onClick={goBack}
          className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-black dark:text-white" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-black dark:text-white">Dados Pessoais</h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            Gerencie suas informações pessoais
          </p>
        </div>
      </div>

      {/* Status de verificação */}
      <div className="card bg-[#00d749]/10 border-[#00d749]">
        <div className="flex items-start gap-3">
          <CheckCircle className="w-6 h-6 text-[#00d749] flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-bold text-black dark:text-white mb-1">
              Perfil Verificado
            </h3>
            <p className="text-sm text-neutral-600 dark:text-neutral-400">
              Seus dados foram verificados pelo gestor em 15/10/2025
            </p>
          </div>
        </div>
      </div>

      {/* Botão Editar no topo */}
      {!isEditing && (
        <button onClick={() => setIsEditing(true)} className="btn-primary w-full">
          Editar Dados
        </button>
      )}

      {/* Formulário */}
      <div className="space-y-4">
        <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
            <User className="w-4 h-4 inline mr-2" />
            Nome Completo
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            disabled={!isEditing}
            className="input w-full"
            placeholder="Seu nome completo"
          />
        </div>

        <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
            <Mail className="w-4 h-4 inline mr-2" />
            Email
          </label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            disabled={!isEditing}
            className="input w-full"
            placeholder="seu.email@example.com"
          />
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
            Email usado para login e notificações importantes
          </p>
        </div>

        <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
            <Phone className="w-4 h-4 inline mr-2" />
            Telefone
          </label>
          <div className="flex gap-2">
            <div className="relative w-24">
               <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                disabled={!isEditing}
                className="w-full pl-2 pr-1 py-3 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00d749] focus:border-transparent text-black dark:text-white appearance-none text-center font-medium disabled:opacity-50 disabled:bg-neutral-100 dark:disabled:bg-neutral-800"
               >
                 <option value="+351">🇵🇹 +351</option>
                 <option value="+55">🇧🇷 +55</option>
               </select>
            </div>
            <input
              type="tel"
              value={formData.phone}
              onChange={handlePhoneChange}
              disabled={!isEditing}
              className="input flex-1"
              placeholder={countryCode === '+351' ? "9xx xxx xxx" : "(DD) 9xxxx-xxxx"}
            />
          </div>
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
            Usado para recuperação de conta e notificações SMS
          </p>
        </div>

        <div className={`card transition-opacity ${!isEditing ? 'opacity-50' : 'opacity-100'}`}>
          <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
            <Hash className="w-4 h-4 inline mr-2" />
            NIF
          </label>
          <input
            type="text"
            value={formData.nif}
            onChange={(e) => setFormData({ ...formData, nif: e.target.value.replace(/\D/g, '').slice(0, 9) })}
            disabled={!isEditing}
            className="input w-full"
            placeholder="123456789"
            maxLength={9}
          />
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
            Número de Identificação Fiscal
          </p>
        </div>
      </div>

      {/* Aviso sobre alterações */}
      {isEditing && (
        <div className="card bg-blue-50 dark:bg-blue-950/30">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-black dark:text-white mb-1">
                Atenção
              </h4>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Alterações nos dados pessoais podem precisar de nova verificação pelo gestor.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Botões de ação (apenas quando editando) */}
      {isEditing && (
        <div className="flex gap-3">
          <button
            onClick={() => setIsEditing(false)}
            className="btn-secondary flex-1"
          >
            Cancelar
          </button>
          <button onClick={handleSave} className="btn-primary flex-1">
            Salvar Alterações
          </button>
        </div>
      )}
    </div>
  )
}

export default PersonalData
