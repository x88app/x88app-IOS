import { useState } from 'react'
import { ArrowLeft, Lock, Eye, EyeOff, AlertTriangle } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import { useToast } from '../../contexts/ToastContext'
import { useBackNavigation } from '../../hooks/useBackNavigation'

const PrivacySecurity = () => {
  const { goBack } = useBackNavigation('/profile')
  const { updatePassword } = useAuth()
  const { showToast } = useToast()
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isChangingPassword, setIsChangingPassword] = useState(false)
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  })

  const handlePasswordChange = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      showToast('As senhas não coincidem!', 'error')
      return
    }
    if (passwordData.newPassword.length < 8) {
      showToast('A senha deve ter pelo menos 8 caracteres!', 'error')
      return
    }
    
    const { success, error } = await updatePassword(passwordData.newPassword)
    if (success) {
      showToast('Senha alterada com sucesso!', 'success')
      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' })
      setIsChangingPassword(false)
    } else {
      showToast('Erro ao alterar senha: ' + error, 'error')
    }
  }

  return (
    <div className="p-4 pt-14 space-y-6 pb-40">
      <div className="flex items-center gap-3 mb-2">
        <button
          type="button"
          onClick={goBack}
          className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-black dark:text-white" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-black dark:text-white">Privacidade e Segurança</h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            Gerencie a segurança da sua conta
          </p>
        </div>
      </div>

      {/* Alterar Senha */}
      <div className={`card transition-opacity ${!isChangingPassword ? 'opacity-50' : 'opacity-100'}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
              <Lock className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-black dark:text-white">Senha</h3>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Altere sua senha de acesso
              </p>
            </div>
          </div>
          {!isChangingPassword && (
            <button
              onClick={() => setIsChangingPassword(true)}
              className="btn-secondary text-sm px-4 py-2"
            >
              Alterar
            </button>
          )}
        </div>

        {isChangingPassword && (
          <div className="space-y-4 mt-4">
            {/* Senha Atual */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Senha Atual
              </label>
              <div className="relative">
                <input
                  type={showCurrentPassword ? 'text' : 'password'}
                  value={passwordData.currentPassword}
                  onChange={(e) =>
                    setPasswordData({ ...passwordData, currentPassword: e.target.value })
                  }
                  className="input w-full pr-10"
                  placeholder="Digite sua senha atual"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                >
                  {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Nova Senha */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Nova Senha
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={passwordData.newPassword}
                  onChange={(e) =>
                    setPasswordData({ ...passwordData, newPassword: e.target.value })
                  }
                  className="input w-full pr-10"
                  placeholder="Digite sua nova senha"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                >
                  {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1">
                Mínimo de 8 caracteres
              </p>
            </div>

            {/* Confirmar Senha */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                Confirmar Nova Senha
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={passwordData.confirmPassword}
                  onChange={(e) =>
                    setPasswordData({ ...passwordData, confirmPassword: e.target.value })
                  }
                  className="input w-full pr-10"
                  placeholder="Confirme sua nova senha"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600"
                >
                  {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  setIsChangingPassword(false)
                  setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' })
                }}
                className="btn-secondary flex-1"
              >
                Cancelar
              </button>
              <button onClick={handlePasswordChange} className="btn-primary flex-1">
                Salvar Senha
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Aviso de Segurança */}
      <div className="card bg-yellow-50 dark:bg-yellow-950/30 border-yellow-300 dark:border-yellow-800">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-medium text-black dark:text-white mb-1">
              Dicas de Segurança
            </h4>
            <ul className="text-sm text-neutral-600 dark:text-neutral-400 space-y-1">
              <li>• Use uma senha forte e única</li>
              <li>• Nunca compartilhe sua senha com ninguém</li>
              <li>• Mantenha seu email e telefone atualizados</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PrivacySecurity
