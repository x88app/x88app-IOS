import { useState, useEffect } from 'react'
import { ArrowLeft, Bell, Volume2 } from 'lucide-react'
import { useAuth } from '../../contexts/AuthContext'
import { useBackNavigation } from '../../hooks/useBackNavigation'

const NotificationSettings = () => {
  const { goBack } = useBackNavigation('/profile')
  const { user, updatePreferences } = useAuth()
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    requestApproved: true,
    requestRejected: true,
    paymentReceived: true,
    promotions: false,
    soundEnabled: true,
  })

  useEffect(() => {
    if (user?.preferences?.notifications) {
      const n = user.preferences.notifications
      setSettings({
        emailNotifications: n.email,
        pushNotifications: n.push,
        smsNotifications: n.sms,
        requestApproved: n.types.approved,
        requestRejected: n.types.rejected,
        paymentReceived: n.types.payment,
        promotions: n.types.promotions,
        soundEnabled: n.sound,
      })
    }
  }, [user])

  const handleToggle = async (key: keyof typeof settings) => {
    const newSettings = { ...settings, [key]: !settings[key] }
    setSettings(newSettings)
    
    // Map flat settings back to structured preferences
    const preferencesToUpdate = {
      notifications: {
        email: key === 'emailNotifications' ? !settings.emailNotifications : settings.emailNotifications,
        push: key === 'pushNotifications' ? !settings.pushNotifications : settings.pushNotifications,
        sms: key === 'smsNotifications' ? !settings.smsNotifications : settings.smsNotifications,
        types: {
          approved: key === 'requestApproved' ? !settings.requestApproved : settings.requestApproved,
          rejected: key === 'requestRejected' ? !settings.requestRejected : settings.requestRejected,
          payment: key === 'paymentReceived' ? !settings.paymentReceived : settings.paymentReceived,
          promotions: key === 'promotions' ? !settings.promotions : settings.promotions,
        },
        sound: key === 'soundEnabled' ? !settings.soundEnabled : settings.soundEnabled,
      }
    }

    await updatePreferences(preferencesToUpdate)
  }

  return (
    <div className="p-4 pt-14 space-y-6 pb-40">
      <div className="flex items-center gap-3 mb-2">
        <button
          type="button"
          onClick={goBack}
          className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all"
        >
          <ArrowLeft className="w-5 h-5 text-black dark:text-white" />
        </button>
        <div>
          <h2 className="text-2xl font-bold text-black dark:text-white">Notificações</h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            Gerencie como você recebe notificações
          </p>
        </div>
      </div>

      {/* Notificações Push */}
      <div className="card">
        <h3 className="text-lg font-bold text-black dark:text-white mb-4">
          Notificações Push
        </h3>
        <div className="flex items-center justify-between py-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
              <Bell className="w-5 h-5 text-[#00d749]" />
            </div>
            <div>
              <p className="font-medium text-black dark:text-white">Ativar Notificações</p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Receber notificações no dispositivo
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.pushNotifications}
              onChange={() => handleToggle('pushNotifications')}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-[#00d749]"></div>
          </label>
        </div>
      </div>

      {/* Tipos de Notificação */}
      <div className="card">
        <h3 className="text-lg font-bold text-black dark:text-white mb-4">
          Tipos de Notificação
        </h3>
        <div className="space-y-4">
          {/* Solicitação Aprovada */}
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-black dark:text-white">Solicitação Aprovada</p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Quando sua solicitação for aprovada
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.requestApproved}
                onChange={() => handleToggle('requestApproved')}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-[#00d749]"></div>
            </label>
          </div>

          {/* Solicitação Rejeitada */}
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-black dark:text-white">Solicitação Rejeitada</p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Quando sua solicitação for rejeitada
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.requestRejected}
                onChange={() => handleToggle('requestRejected')}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-[#00d749]"></div>
            </label>
          </div>

          {/* Pagamento Recebido */}
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-black dark:text-white">Pagamento Recebido</p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Quando receber um pagamento
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.paymentReceived}
                onChange={() => handleToggle('paymentReceived')}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-[#00d749]"></div>
            </label>
          </div>

          {/* Promoções */}
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-black dark:text-white">Promoções e Novidades</p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Ofertas especiais e atualizações
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.promotions}
                onChange={() => handleToggle('promotions')}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-[#00d749]"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Configurações de Som */}
      <div className="card">
        <h3 className="text-lg font-bold text-black dark:text-white mb-4">
          Som e Vibração
        </h3>
        <div className="flex items-center justify-between py-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
              <Volume2 className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="font-medium text-black dark:text-white">Som de Notificação</p>
              <p className="text-sm text-neutral-600 dark:text-neutral-400">
                Reproduzir som ao receber notificações
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={() => handleToggle('soundEnabled')}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-neutral-300 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-[#00d749]"></div>
          </label>
        </div>
      </div>

    </div>
  )
}

export default NotificationSettings

