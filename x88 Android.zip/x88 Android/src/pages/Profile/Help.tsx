import { ArrowLeft, MessageCircle, Mail, HelpCircle } from 'lucide-react'
import { useConfiguracoesGlobais } from '../../hooks/useConfiguracoesGlobais'
import { useBackNavigation } from '../../hooks/useBackNavigation'

const Help = () => {
  const { goBack } = useBackNavigation('/profile')
  const { config, handleContactWhatsapp, handleContactEmail } = useConfiguracoesGlobais()

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-black pt-10">
      <div className="bg-white dark:bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800">
        <div className="flex items-center gap-4 p-4">
          <button
            onClick={goBack}
            className="p-2 -ml-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6 text-black dark:text-white" />
          </button>
          <h1 className="text-xl font-bold text-black dark:text-white">Ajuda</h1>
        </div>
      </div>

      <div className="p-4 space-y-6">
        <div className="card p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-[#00d749]/10 flex items-center justify-center mx-auto mb-4">
            <HelpCircle className="w-8 h-8 text-[#00d749]" />
          </div>
          <h2 className="text-xl font-bold text-black dark:text-white mb-2">
            Precisa de ajuda?
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400">
            Estamos aqui para ajudar! Entre em contato com nosso suporte para tirar suas dúvidas.
          </p>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-bold text-neutral-500 uppercase tracking-wider">
            Canais de Atendimento
          </h3>

          {config.whatsapp_suporte && (
            <button
              onClick={handleContactWhatsapp}
              className="w-full card p-4 hover:shadow-lg flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-[#25D366]/10 flex items-center justify-center">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
                  alt="WhatsApp" 
                  className="w-6 h-6"
                />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-bold text-black dark:text-white">WhatsApp</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  Fale com o suporte agora
                </p>
              </div>
              <MessageCircle className="w-5 h-5 text-[#25D366]" />
            </button>
          )}

          {config.email_suporte && (
            <button
              onClick={handleContactEmail}
              className="w-full card p-4 hover:shadow-lg flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                <Mail className="w-6 h-6 text-blue-500" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-bold text-black dark:text-white">E-mail</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  {config.email_suporte}
                </p>
              </div>
            </button>
          )}
        </div>

        <div className="card p-4">
          <h3 className="font-bold text-black dark:text-white mb-3">Perguntas Frequentes</h3>
          <div className="space-y-3 text-sm">
            <div className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg">
              <p className="font-medium text-black dark:text-white">Como solicitar um adiantamento?</p>
              <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                Na tela inicial, clique em "Novo Adiantamento" e siga as instruções.
              </p>
            </div>
            <div className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg">
              <p className="font-medium text-black dark:text-white">Quanto tempo leva para receber?</p>
              <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                Após aprovação, o pagamento é processado em até 24 horas úteis.
              </p>
            </div>
            <div className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg">
              <p className="font-medium text-black dark:text-white">Como alterar meus dados bancários?</p>
              <p className="text-neutral-600 dark:text-neutral-400 mt-1">
                Acesse Perfil → Dados Bancários para atualizar suas informações.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Help
