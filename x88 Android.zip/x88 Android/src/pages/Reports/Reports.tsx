import { useState } from 'react'
import { TrendingUp, Calendar, X } from 'lucide-react'
import { useRequests } from '../../contexts/RequestsContext'
import { RequestModal } from '../../components/RequestModal'
import { DatePicker } from '../../components/DatePicker'
import { FormattedDate } from '../../components/FormattedDate'
import { useLanguage } from '../../contexts/LanguageContext'

const Reports = () => {
  const { requests } = useRequests()
  const { formatCurrency, language } = useLanguage()
  const isBR = language === 'pt-BR'
  const [selectedRequest, setSelectedRequest] = useState<typeof requests[0] | null>(null)
  const [showDateFilter, setShowDateFilter] = useState(false)
  const [startDate, setStartDate] = useState<Date | null>(null)
  const [endDate, setEndDate] = useState<Date | null>(null)
  const [tempStartDate, setTempStartDate] = useState<Date | null>(null)
  const [tempEndDate, setTempEndDate] = useState<Date | null>(null)

  const historico = requests
    .filter((r) => r.status === 'paid')
    .filter((r) => {
      if (!startDate && !endDate) return true
      const itemDate = new Date(r.createdAt)
      itemDate.setHours(0, 0, 0, 0)
      
      const start = startDate ? new Date(startDate) : null
      if (start) start.setHours(0, 0, 0, 0)
      
      const end = endDate ? new Date(endDate) : null
      if (end) end.setHours(23, 59, 59, 999)
      
      if (start && end) {
        return itemDate >= start && itemDate <= end
      } else if (start) {
        return itemDate >= start
      } else if (end) {
        return itemDate <= end
      }
      return true
    })
    .sort((a, b) => b.createdAt - a.createdAt)

  const applyDateFilter = () => {
    setStartDate(tempStartDate)
    setEndDate(tempEndDate)
    setShowDateFilter(false)
  }

  const clearDateFilter = () => {
    setStartDate(null)
    setEndDate(null)
    setTempStartDate(null)
    setTempEndDate(null)
    setShowDateFilter(false)
  }

  return (
    <div className="pb-40 bg-neutral-50 dark:bg-neutral-950 min-h-screen">
      <div className="bg-[#00d749] p-6 pt-14 pb-12 rounded-b-3xl">
        <h1 className="text-3xl font-bold mb-1 text-black">Histórico</h1>
        <p className="text-black/80 text-sm">Histórico de pagamentos</p>
      </div>

      {/* Histórico de Pagamentos */}
      <div className="px-4 mt-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-black dark:text-white">Histórico de Pagamentos</h2>
          <div className="flex items-center gap-2">
            {(startDate || endDate) && (
              <button
                onClick={clearDateFilter}
                className="flex items-center gap-2 px-3 py-2 bg-red-100 dark:bg-red-900/20 text-red-600 rounded-lg hover:bg-red-200 dark:hover:bg-red-900/30 transition-colors text-sm font-medium"
              >
                <X className="w-4 h-4" />
                Limpar
              </button>
            )}
            <button
              onClick={() => setShowDateFilter(true)}
              className="flex items-center gap-2 px-4 py-2 bg-[#00d749] text-white rounded-lg hover:bg-[#00dc43] transition-colors text-sm font-medium"
            >
              <Calendar className="w-4 h-4" />
              Filtrar
            </button>
          </div>
        </div>

        {historico.length === 0 ? (
          <div className="bg-white dark:bg-neutral-900 rounded-2xl p-8 shadow-md border border-neutral-100 dark:border-neutral-800 text-center">
            <div className="w-16 h-16 bg-neutral-100 dark:bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-8 h-8 text-neutral-400" />
            </div>
            <p className="text-neutral-600 dark:text-neutral-400 font-medium">
              Você ainda não possui pagamentos recebidos.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {historico.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedRequest(item)}
                className="bg-white dark:bg-neutral-900 rounded-2xl p-4 shadow-md border border-neutral-100 dark:border-neutral-800 hover:shadow-lg transition-shadow cursor-pointer"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-bold text-base text-black dark:text-white mb-1">
                      Pedido via {item.currency === 'SATS' ? 'Satoshi' : item.paymentMethod === 'mbway' ? (isBR ? 'PIX' : 'MB Way') : (isBR ? 'Conta Bancária' : 'IBAN')}
                    </p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400">
                      <FormattedDate date={item.createdAt} options={{
                        day: '2-digit',
                        month: 'long',
                        year: 'numeric',
                      }} />
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold text-xl mb-1 ${item.currency === 'SATS' ? 'text-[#E69F39]' : 'text-black dark:text-white'}`}>
                      {item.currency === 'SATS' ? `${Math.round(item.amount)} sats` : formatCurrency(item.amount)}
                    </p>
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        item.currency === 'SATS' ? 'bg-[#E69F39]/10 text-[#E69F39]' : 'bg-[#00d749]/10 text-[#00d749]'
                      }`}
                    >
                      Recebido
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedRequest && (
        <RequestModal 
          request={selectedRequest} 
          onClose={() => setSelectedRequest(null)} 
        />
      )}

      {/* Modal de Filtro de Data */}
      {showDateFilter && (
        <div 
          className="fixed bg-black/50 backdrop-blur-sm flex items-start justify-center p-4 pt-6"
          style={{ 
            zIndex: 99999,
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            position: 'fixed',
            width: '100vw',
            height: '100vh',
            margin: 0,
            padding: '1.5rem 1rem'
          }}
          onClick={() => setShowDateFilter(false)}
        >
          <div 
            className="bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl max-w-md w-full p-6 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-black dark:text-white">Filtrar por Data</h3>
              <button
                onClick={() => setShowDateFilter(false)}
                className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-neutral-600 dark:text-neutral-400" />
              </button>
            </div>

            <div className="space-y-4">
              <DatePicker
                label="Data Inicial"
                selected={tempStartDate}
                onChange={setTempStartDate}
              />

              <DatePicker
                label="Data Final"
                selected={tempEndDate}
                onChange={setTempEndDate}
              />
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowDateFilter(false)}
                className="flex-1 py-3 bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-semibold rounded-xl hover:bg-neutral-300 dark:hover:bg-neutral-600 transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={applyDateFilter}
                className="flex-1 py-3 bg-[#00d749] text-white font-semibold rounded-xl hover:bg-[#00dc43] transition-colors"
              >
                Aplicar Filtro
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Reports
