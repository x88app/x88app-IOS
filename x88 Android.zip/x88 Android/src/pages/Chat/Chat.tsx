import { useState, useRef, useEffect } from 'react'
import { ArrowLeft, Send, Trash2, Sparkles, ExternalLink } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useChat, ChatMessage } from '../../hooks/useChat'
import { useLanguage } from '../../contexts/LanguageContext'
import { useAuth } from '../../contexts/AuthContext'

// Função para parsear botões no texto [BUTTON:texto:url]
const parseMessageWithButtons = (text: string, navigate: (path: string) => void) => {
  const buttonRegex = /\[BUTTON:([^\]:]+):([^\]]+)\]/g
  const parts: (string | JSX.Element)[] = []
  let lastIndex = 0
  let match

  while ((match = buttonRegex.exec(text)) !== null) {
    // Adiciona o texto antes do botão
    if (match.index > lastIndex) {
      parts.push(text.slice(lastIndex, match.index))
    }

    const buttonText = match[1]
    const buttonUrl = match[2]
    const isExternal = buttonUrl.startsWith('http') || buttonUrl.startsWith('mailto:') || buttonUrl.startsWith('tel:')

    parts.push(
      <button
        key={`btn-${match.index}`}
        onClick={() => {
          if (isExternal) {
            window.open(buttonUrl, '_blank')
          } else {
            // Adiciona ?from=chat para poder voltar ao chat depois
            const urlWithFrom = buttonUrl.includes('?') 
              ? `${buttonUrl}&from=chat` 
              : `${buttonUrl}?from=chat`
            navigate(urlWithFrom)
          }
        }}
        className="flex items-center gap-2 mt-2 px-4 py-2.5 bg-[#00d749] hover:bg-[#00c142] text-white rounded-xl font-medium text-sm transition-colors w-full justify-center"
      >
        {buttonText}
        {isExternal && <ExternalLink className="w-4 h-4" />}
      </button>
    )

    lastIndex = match.index + match[0].length
  }

  // Adiciona o texto restante
  if (lastIndex < text.length) {
    parts.push(text.slice(lastIndex))
  }

  return parts.length > 0 ? parts : [text]
}

const Chat = () => {
  const navigate = useNavigate()
  const { messages, isLoading, sendMessage, clearHistory } = useChat()
  const { t, language } = useLanguage()
  const { user } = useAuth()
  const [inputValue, setInputValue] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [showClearConfirm, setShowClearConfirm] = useState(false)

  const isBR = language === 'pt-BR'

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputValue.trim() && !isLoading) {
      sendMessage(inputValue)
      setInputValue('')
    }
  }

  const handleClear = () => {
    clearHistory()
    setShowClearConfirm(false)
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString(isBR ? 'pt-BR' : 'pt-PT', {
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const welcomeMessage = isBR
    ? `Olá${user?.name ? `, ${user.name.split(' ')[0]}` : ''}! 👋\n\nSou a X88 IA, sua assistente virtual. Posso te ajudar com:\n\n• Como fazer solicitações\n• Dúvidas sobre limites e taxas\n• Informações sobre pagamentos\n• Ou qualquer outra pergunta!\n\nComo posso ajudar?`
    : `Olá${user?.name ? `, ${user.name.split(' ')[0]}` : ''}! 👋\n\nSou a X88 IA, a sua assistente virtual. Posso ajudá-lo com:\n\n• Como fazer pedidos\n• Dúvidas sobre limites e taxas\n• Informações sobre pagamentos\n• Ou qualquer outra questão!\n\nComo posso ajudar?`

  return (
    <div className="flex flex-col h-screen bg-white dark:bg-black pt-10">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-black sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/')}
            className="p-2 -ml-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-black dark:text-white" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00d749] to-[#00a83a] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-black dark:text-white">X88 IA</h1>
              <p className="text-xs text-neutral-500">
                {isLoading ? (isBR ? 'Digitando...' : 'A escrever...') : 'Online'}
              </p>
            </div>
          </div>
        </div>
        
        <button
          onClick={() => setShowClearConfirm(true)}
          className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-full transition-colors"
          title={isBR ? 'Limpar conversa' : 'Limpar conversa'}
        >
          <Trash2 className="w-5 h-5 text-neutral-500" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 && (
          <div className="flex justify-start">
            <div className="max-w-[85%] rounded-2xl rounded-tl-sm px-4 py-3 bg-neutral-100 dark:bg-neutral-800">
              <p className="text-sm text-black dark:text-white whitespace-pre-line">
                {welcomeMessage}
              </p>
            </div>
          </div>
        )}

        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                message.role === 'user'
                  ? 'bg-[#00d749] text-white rounded-tr-sm'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-black dark:text-white rounded-tl-sm'
              }`}
            >
              {message.isLoading ? (
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-neutral-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              ) : (
                <>
                  <div className="text-sm whitespace-pre-line">
                    {message.role === 'assistant' 
                      ? parseMessageWithButtons(message.content, navigate).map((part, i) => 
                          typeof part === 'string' ? <span key={i}>{part}</span> : part
                        )
                      : message.content
                    }
                  </div>
                  <p className={`text-[10px] mt-1 ${
                    message.role === 'user' 
                      ? 'text-white/70' 
                      : 'text-neutral-400'
                  }`}>
                    {formatTime(message.timestamp)}
                  </p>
                </>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-black p-4 pb-8">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={isBR ? 'Digite sua mensagem...' : 'Escreva a sua mensagem...'}
            className="flex-1 bg-neutral-100 dark:bg-neutral-800 rounded-full px-4 py-3 text-sm text-black dark:text-white placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-[#00d749]"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isLoading}
            className="w-12 h-12 rounded-full bg-[#00d749] flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
          >
            <Send className="w-5 h-5 text-white" />
          </button>
        </form>
      </div>

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold text-black dark:text-white mb-2">
              {isBR ? 'Limpar conversa?' : 'Limpar conversa?'}
            </h3>
            <p className="text-neutral-600 dark:text-neutral-400 text-sm mb-6">
              {isBR 
                ? 'Todo o histórico da conversa será apagado. Esta ação não pode ser desfeita.'
                : 'Todo o histórico da conversa será apagado. Esta ação não pode ser desfeita.'}
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-3 rounded-xl border border-neutral-300 dark:border-neutral-700 text-black dark:text-white font-medium"
              >
                {isBR ? 'Cancelar' : 'Cancelar'}
              </button>
              <button
                onClick={handleClear}
                className="flex-1 py-3 rounded-xl bg-red-500 text-white font-medium"
              >
                {isBR ? 'Limpar' : 'Limpar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Chat
