import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { Clock, CheckCircle, XCircle, FileText, CreditCard, ChevronDown, Ban } from 'lucide-react'
import { useRequests } from '../../contexts/RequestsContext'
import { FormattedDate } from '../../components/FormattedDate'
import { useLanguage } from '../../contexts/LanguageContext'
import { DateRangePicker } from '../../components/DateRangePicker'

type FilterType = 'ALL' | 'pending' | 'approved' | 'rejected' | 'canceled'

const RequestsList = () => {
  const { requests } = useRequests()
  const { formatCurrency, language } = useLanguage()
  const isBR = language === 'pt-BR'
  const [filter, setFilter] = useState<FilterType>('ALL')
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [startDate, setStartDate] = useState<string>('')
  const [endDate, setEndDate] = useState<string>('')

  const filteredRequests = useMemo(() => {
    return requests.filter((req) => {
      // Filtro por status
      let matchesStatus = true
      if (filter === 'ALL') {
        matchesStatus = true
      } else if (filter === 'approved') {
        matchesStatus = req.status === 'approved' || req.status === 'paid'
      } else if (filter === 'pending') {
        matchesStatus = req.status === 'pending' || req.status === 'processing' || req.status === 'verifying'
      } else if (filter === 'canceled') {
        matchesStatus = req.status === 'canceled'
      } else {
        matchesStatus = req.status === filter
      }

      // Filtro por data
      let matchesDate = true
      if (startDate || endDate) {
        const reqDate = new Date(req.date)
        reqDate.setHours(0, 0, 0, 0)
        
        if (startDate) {
          const start = new Date(startDate)
          start.setHours(0, 0, 0, 0)
          if (reqDate < start) matchesDate = false
        }
        
        if (endDate) {
          const end = new Date(endDate)
          end.setHours(23, 59, 59, 999)
          if (reqDate > end) matchesDate = false
        }
      }

      return matchesStatus && matchesDate
    })
  }, [requests, filter, startDate, endDate])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
      case 'processing':
        return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-500/20 text-yellow-600">Pendente</span>
      case 'approved':
        return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#00d749]/20 text-[#00d749]">Aprovada</span>
      case 'rejected':
        return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-600">Rejeitada</span>
      case 'paid':
        return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#00d749]/20 text-[#00d749]">Paga</span>
      case 'verifying':
        return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-500/20 text-yellow-600">Em Verificação</span>
      case 'canceled':
        return <span className="px-3 py-1 rounded-full text-xs font-semibold bg-neutral-500/20 text-neutral-600 dark:text-neutral-400">Cancelada</span>
      default:
        return null
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
      case 'processing':
      case 'verifying':
        return <Clock className="w-6 h-6 text-yellow-600" />
      case 'approved':
      case 'paid':
        return <CheckCircle className="w-6 h-6 text-[#00d749]" />
      case 'rejected':
        return <XCircle className="w-6 h-6 text-red-600" />
      case 'canceled':
        return <Ban className="w-6 h-6 text-neutral-500" />
      default:
        return null
    }
  }

  const getPaymentMethodLabel = (method: string) => {
    if (method === 'mbway') return isBR ? 'PIX' : 'MB Way'
    if (method === 'satoshi') return 'Satoshi (Lightning)'
    return isBR ? 'Conta Bancária' : 'IBAN'
  }

  return (
    <div className="p-4 pt-14 space-y-6 pb-40">
      <div>
        <h2 className="text-2xl font-bold text-black dark:text-white">Minhas Solicitações</h2>
        <p className="text-neutral-600 dark:text-neutral-400 mt-1">
          Acompanhe o status dos seus pedidos
        </p>
      </div>

      {/* Filtros */}
      <div className="space-y-4">
        {/* Filtro por Status */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="w-full bg-white dark:bg-neutral-800 border-2 border-neutral-200 dark:border-neutral-700 rounded-xl px-4 py-3 flex items-center justify-between font-semibold text-black dark:text-white hover:border-[#00d749] transition-all"
          >
            <span>
              {filter === 'ALL' && 'Todas'}
              {filter === 'pending' && 'Pendentes'}
              {filter === 'approved' && 'Aprovadas'}
              {filter === 'rejected' && 'Rejeitadas'}
              {filter === 'canceled' && 'Canceladas'}
            </span>
            <ChevronDown className={`w-5 h-5 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {dropdownOpen && (
            <div className="absolute z-10 w-full mt-2 bg-white dark:bg-neutral-800 border-2 border-neutral-200 dark:border-neutral-700 rounded-xl shadow-lg overflow-hidden">
              {[
                { value: 'ALL', label: 'Todas' },
                { value: 'pending', label: 'Pendentes' },
                { value: 'approved', label: 'Aprovadas' },
                { value: 'rejected', label: 'Rejeitadas' },
                { value: 'canceled', label: 'Canceladas' }
              ].map((status) => (
                <button
                  key={status.value}
                  onClick={() => {
                    setFilter(status.value as FilterType)
                    setDropdownOpen(false)
                  }}
                  className={`w-full px-4 py-3 text-left font-medium transition-colors ${
                    filter === status.value
                      ? 'bg-[#00d749] text-white'
                      : 'text-black dark:text-white hover:bg-neutral-100 dark:hover:bg-neutral-700'
                  }`}
                >
                  {status.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Filtro por Data - Calendário Personalizado */}
        <DateRangePicker
          startDate={startDate}
          endDate={endDate}
          onStartDateChange={setStartDate}
          onEndDateChange={setEndDate}
          onClear={() => { setStartDate(''); setEndDate(''); }}
        />
      </div>

      {/* Lista */}
      <div className="space-y-5">
        {filteredRequests.length === 0 ? (
          <div className="bg-white dark:bg-neutral-800 rounded-2xl shadow-md p-10 text-center">
            <FileText className="w-16 h-16 text-neutral-400 mx-auto mb-4" />
            <p className="text-neutral-600 dark:text-neutral-400 text-lg font-medium">
              Nenhuma solicitação encontrada
            </p>
          </div>
        ) : (
          filteredRequests.map((request) => (
            <Link key={request.id} to={`/requests/${request.id}`} className="block">
              <div className="bg-white dark:bg-neutral-800 rounded-2xl shadow-md p-5 hover:shadow-xl transition-all hover:scale-[1.02]">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(request.status)}
                    <div>
                      <h3 className="font-bold text-lg text-black dark:text-white">
                        Adiantamento
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <CreditCard className="w-4 h-4 text-neutral-500" />
                        <p className="text-sm text-neutral-600 dark:text-neutral-400 font-medium">
                          {getPaymentMethodLabel(request.paymentMethod)}
                        </p>
                      </div>
                    </div>
                  </div>
                  {getStatusBadge(request.status)}
                </div>

                {/* Valores */}
                <div className="bg-neutral-50 dark:bg-neutral-900 rounded-xl p-4 mb-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-neutral-600 dark:text-neutral-400 mb-1">Valor Solicitado</p>
                      <p className={`text-xl font-bold ${request.currency === 'SATS' ? 'text-[#E69F39]' : 'text-[#00d749]'}`}>
                        {request.currency === 'SATS' ? `${request.amount} sats` : formatCurrency(request.amount)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-neutral-600 dark:text-neutral-400 mb-1">
                        {request.status === 'paid' 
                          ? (request.descontado ? 'Descontado' : 'A Descontar')
                          : 'A Descontar'}
                      </p>
                      <p className={`text-xl font-bold ${
                        request.status === 'paid' 
                          ? (request.descontado 
                              ? 'text-green-600 dark:text-green-400' 
                              : 'text-red-600')
                          : 'text-red-600'
                      }`}>
                        {request.currency === 'SATS' 
                          ? `${Math.round(request.netAmount)} sats`
                          : formatCurrency(request.netAmount)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Badge Descontado */}
                {request.descontado && (
                  <div className="flex items-center gap-2 mb-3 px-3 py-2 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800">
                    <div className="w-4 h-4 rounded-full bg-green-500 flex items-center justify-center">
                      <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-xs text-green-700 dark:text-green-400 font-semibold">
                      Valor descontado do salário
                    </span>
                  </div>
                )}

                {/* Footer */}
                <div className="flex items-center justify-between pt-3 border-t border-neutral-200 dark:border-neutral-700">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-neutral-500" />
                    <p className="text-sm text-neutral-600 dark:text-neutral-400">
                      <FormattedDate date={request.date} />
                    </p>
                  </div>
                  <p className="text-sm text-[#00d749] font-semibold">Ver detalhes →</p>
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  )
}

export default RequestsList
