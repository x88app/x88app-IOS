import { ArrowLeft } from 'lucide-react'
import { useGestorEmail } from '../../hooks/useGestorEmail'
import { useBackNavigation } from '../../hooks/useBackNavigation'

const TermsOfUse = () => {
  const { gestorEmail } = useGestorEmail()
  const { goBack } = useBackNavigation('/')
  const displayEmail = gestorEmail || 'x88app@gmail.com'

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <div className="max-w-3xl mx-auto px-4 pt-14 py-8 pb-32">
        <button
          onClick={goBack}
          className="inline-flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-black dark:hover:text-white transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <h1 className="text-3xl font-bold text-black dark:text-white mb-2">
          Termos de Uso
        </h1>
        <p className="text-neutral-500 dark:text-neutral-400 text-sm mb-8">
          Última atualização: 6 de Dezembro de 2025
        </p>

        <div className="prose prose-neutral dark:prose-invert max-w-none space-y-6 text-neutral-700 dark:text-neutral-300">
          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">1. Aceitação dos Termos</h2>
            <p>
              Ao aceder ou utilizar a aplicação X88 Motorista Parceiro ("Aplicação"), você concorda em ficar 
              vinculado a estes Termos de Uso ("Termos"). Se não concordar com qualquer parte destes 
              Termos, não deve utilizar a Aplicação.
            </p>
            <p>
              Estes Termos constituem um acordo legal entre você ("Utilizador", "Motorista Parceiro" ou "você") 
              e a X88 ("nós", "nosso" ou "Empresa").
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">2. Descrição do Serviço</h2>
            <p>
              A Aplicação X88 Motorista Parceiro permite aos motoristas parceiros registados:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Solicitar adiantamentos</li>
              <li>Acompanhar o estado das solicitações</li>
              <li>Receber pagamentos através de MB Way, PIX, IBAN ou Lightning Network (Bitcoin)</li>
              <li>Gerir dados pessoais e bancários</li>
              <li>Receber notificações e comunicações</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">3. Elegibilidade e Registo</h2>
            <p>Para utilizar a Aplicação, você deve:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Ter pelo menos 18 anos de idade</li>
              <li>Ser motorista parceiro ativo da frota X88 ou parceiro autorizado</li>
              <li>Fornecer informações verdadeiras, precisas e completas durante o registo</li>
              <li>Manter as suas credenciais de acesso seguras e confidenciais</li>
            </ul>
            <p className="mt-3">
              Você é responsável por todas as atividades que ocorram na sua conta. Deve notificar-nos 
              imediatamente sobre qualquer uso não autorizado.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">4. Adiantamento</h2>
            
            <h3 className="text-lg font-semibold text-black dark:text-white mt-4 mb-2">4.1 Natureza do Serviço</h3>
            <p>
              O serviço de adiantamento permite ao motorista parceiro solicitar uma antecipação de parte 
              dos seus ganhos. <strong>Este serviço não constitui um empréstimo ou crédito</strong>, mas sim 
              uma antecipação de valores já devidos pelo trabalho realizado.
            </p>

            <h3 className="text-lg font-semibold text-black dark:text-white mt-4 mb-2">4.2 Taxa de Serviço</h3>
            <p>
              Uma taxa de serviço será aplicada sobre cada adiantamento solicitado. Esta taxa:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Será claramente apresentada antes da confirmação da solicitação</li>
              <li>Será acrescida ao valor a ser descontado do repasse</li>
              <li>Pode variar e será definida pelo gestor</li>
              <li>Cobre os custos administrativos e de processamento</li>
            </ul>

            <h3 className="text-lg font-semibold text-black dark:text-white mt-4 mb-2">4.3 Aprovação e Limites</h3>
            <p>
              Todas as solicitações estão sujeitas à aprovação do gestor. Os limites de adiantamento 
              são definidos individualmente e podem variar com base no histórico do motorista parceiro e nas 
              políticas da frota.
            </p>

            <h3 className="text-lg font-semibold text-black dark:text-white mt-4 mb-2">4.4 Processamento</h3>
            <p>
              Os pagamentos são processados após aprovação. O tempo de processamento varia conforme o 
              método de pagamento escolhido:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>MB Way / PIX:</strong> Geralmente instantâneo</li>
              <li><strong>IBAN / Transferência Bancária:</strong> 1-2 dias úteis</li>
              <li><strong>Lightning Network (Bitcoin):</strong> Geralmente instantâneo</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">5. Pagamentos em Criptomoedas</h2>
            <p>
              A Aplicação permite receber adiantamentos em Bitcoin através da Lightning Network. 
              Ao optar por este método, você reconhece e aceita que:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>O valor em criptomoeda está sujeito a volatilidade de mercado</li>
              <li>A conversão para moeda fiduciária é da sua responsabilidade</li>
              <li>Deve fornecer um endereço Lightning válido e funcional</li>
              <li>Transações em blockchain são irreversíveis</li>
              <li>É responsável por declarar rendimentos conforme a legislação fiscal aplicável</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">6. Dados Bancários</h2>
            <p>
              Você é integralmente responsável por:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Fornecer dados bancários corretos e atualizados</li>
              <li>Garantir que é o titular legítimo das contas fornecidas</li>
              <li>Atualizar os dados sempre que houver alterações</li>
            </ul>
            <p className="mt-3">
              A X88 não se responsabiliza por pagamentos realizados para dados bancários incorretos 
              fornecidos pelo utilizador.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">7. Obrigações do Utilizador</h2>
            <p>Ao utilizar a Aplicação, você concorda em:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Fornecer apenas informações verdadeiras e precisas</li>
              <li>Não utilizar a Aplicação para fins fraudulentos ou ilegais</li>
              <li>Não tentar aceder a contas de outros utilizadores</li>
              <li>Não interferir com o funcionamento da Aplicação</li>
              <li>Cumprir com todas as leis e regulamentos aplicáveis</li>
              <li>Não partilhar as suas credenciais de acesso</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">8. Cancelamento de Solicitações</h2>
            <p>
              Solicitações de adiantamento podem ser canceladas apenas enquanto estiverem com o estado 
              "Pendente". Uma vez aprovadas pelo gestor, o cancelamento não é possível e o processamento 
              do pagamento será efetuado.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">9. Propriedade Intelectual</h2>
            <p>
              Todos os direitos de propriedade intelectual relativos à Aplicação, incluindo mas não 
              limitado a software, design, logótipos, textos e gráficos, são propriedade exclusiva da X88 
              ou dos seus licenciadores.
            </p>
            <p>
              É concedida ao utilizador uma licença limitada, não exclusiva e não transferível para 
              utilizar a Aplicação de acordo com estes Termos.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">10. Limitação de Responsabilidade</h2>
            <p>
              Na máxima extensão permitida por lei, a X88 não será responsável por:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Danos indiretos, incidentais ou consequenciais</li>
              <li>Perda de dados ou lucros</li>
              <li>Interrupções temporárias do serviço</li>
              <li>Ações de terceiros, incluindo instituições bancárias</li>
              <li>Volatilidade de criptomoedas</li>
              <li>Erros causados por informações incorretas fornecidas pelo utilizador</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">11. Indemnização</h2>
            <p>
              Você concorda em indemnizar e isentar a X88, seus diretores, funcionários e parceiros 
              de qualquer reclamação, dano, perda ou despesa decorrente da sua violação destes Termos 
              ou do uso indevido da Aplicação.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">12. Suspensão e Rescisão</h2>
            <p>
              Reservamo-nos o direito de suspender ou encerrar a sua conta a qualquer momento, com ou 
              sem aviso prévio, se:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Violar estes Termos de Uso</li>
              <li>Fornecer informações falsas ou enganosas</li>
              <li>Utilizar a Aplicação de forma fraudulenta</li>
              <li>Deixar de ser motorista parceiro elegível</li>
            </ul>
            <p className="mt-3">
              Você pode encerrar a sua conta a qualquer momento através da funcionalidade 
              "Excluir Minha Conta" disponível na Aplicação.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">13. Alterações aos Termos</h2>
            <p>
              Podemos modificar estes Termos a qualquer momento. As alterações entrarão em vigor após 
              a publicação na Aplicação. O uso continuado da Aplicação após tais alterações constitui 
              a sua aceitação dos Termos atualizados.
            </p>
            <p>
              Para alterações significativas, enviaremos uma notificação através da Aplicação ou por email.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">14. Lei Aplicável e Jurisdição</h2>
            <p>
              Estes Termos são regidos pelas leis de Portugal. Qualquer disputa será submetida à 
              jurisdição exclusiva dos tribunais portugueses, sem prejuízo dos direitos que lhe 
              assistam enquanto consumidor ao abrigo da legislação aplicável.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">15. Disposições Gerais</h2>
            <ul className="list-disc pl-6 space-y-1">
              <li>
                <strong>Acordo Integral:</strong> Estes Termos constituem o acordo integral entre 
                você e a X88 relativamente à Aplicação.
              </li>
              <li>
                <strong>Separabilidade:</strong> Se qualquer disposição for considerada inválida, 
                as restantes permanecerão em vigor.
              </li>
              <li>
                <strong>Renúncia:</strong> A não aplicação de qualquer direito não constitui 
                renúncia ao mesmo.
              </li>
              <li>
                <strong>Cessão:</strong> Você não pode ceder os seus direitos ou obrigações sem 
                o nosso consentimento escrito.
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">16. Contacto</h2>
            <p>
              Para questões sobre estes Termos de Uso, pode contactar-nos através de:
            </p>
            <div className="bg-neutral-100 dark:bg-neutral-800 rounded-xl p-4 mt-3">
              <p><strong>X88</strong></p>
              <p>Email: {displayEmail}</p>
            </div>
          </section>

          <section className="border-t border-neutral-200 dark:border-neutral-800 pt-6 mt-8">
            <p className="text-sm text-neutral-500 dark:text-neutral-400">
              Ao utilizar a Aplicação X88 Motorista Parceiro, você confirma que leu, compreendeu e aceita 
              estar vinculado a estes Termos de Uso.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}

export default TermsOfUse
