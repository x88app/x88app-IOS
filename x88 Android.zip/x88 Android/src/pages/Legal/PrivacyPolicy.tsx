import { ArrowLeft } from 'lucide-react'
import { useGestorEmail } from '../../hooks/useGestorEmail'
import { useBackNavigation } from '../../hooks/useBackNavigation'

const PrivacyPolicy = () => {
  const { gestorEmail } = useGestorEmail()
  const { goBack } = useBackNavigation('/')
  const displayEmail = gestorEmail || 'x88app@gmail.com'

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <div className="max-w-3xl mx-auto px-4 pt-14 py-8 pb-32">
        <button
          onClick={goBack}
          className="inline-flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-black dark:hover:text-white transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Voltar
        </button>

        <h1 className="text-3xl font-bold text-black dark:text-white mb-2">
          Política de Privacidade
        </h1>
        <p className="text-neutral-500 dark:text-neutral-400 text-sm mb-8">
          Última atualização: Dezembro de 2025
        </p>

        <div className="prose prose-neutral dark:prose-invert max-w-none space-y-6 text-neutral-700 dark:text-neutral-300">
          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">1. Introdução</h2>
            <p>
              A X88 ("nós", "nosso" ou "nossa") está comprometida em proteger a privacidade dos nossos utilizadores. 
              Esta Política de Privacidade explica como recolhemos, utilizamos, divulgamos e protegemos as suas 
              informações pessoais quando utiliza a nossa aplicação móvel X88 ("Aplicação").
            </p>
            <p>
              Ao utilizar a nossa Aplicação, você concorda com a recolha e utilização de informações de acordo 
              com esta política. Recomendamos que leia atentamente este documento.
            </p>
            <p className="mt-3">
              <strong>Importante:</strong> O X88 é um aplicativo de <strong>gestão e intermediação</strong> entre 
              colaboradores e gestores. O aplicativo <strong>não realiza transações financeiras, transferências 
              bancárias ou processamento de pagamentos</strong>. Funciona apenas como ferramenta de comunicação 
              e gestão de solicitações. Todos os pagamentos são realizados externamente pelo gestor, fora do 
              ambiente do aplicativo.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">2. Informações que Recolhemos</h2>
            <p>Recolhemos os seguintes tipos de informações:</p>
            
            <h3 className="text-lg font-semibold text-black dark:text-white mt-4 mb-2">2.1 Informações Pessoais</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Dados de Identificação:</strong> Nome completo, endereço de email, número de telefone</li>
              <li><strong>Dados de Autenticação:</strong> Palavra-passe (armazenada de forma encriptada)</li>
              <li><strong>Dados Bancários:</strong> IBAN, número MB Way/PIX, endereço Lightning Network</li>
              <li><strong>Dados de Utilização:</strong> Histórico de solicitações, valores, datas e status</li>
              <li><strong>Foto de Perfil:</strong> Imagem opcional que você escolhe enviar</li>
              <li><strong>Conversas com Assistente:</strong> Mensagens trocadas com nossa assistente virtual</li>
            </ul>

            <h3 className="text-lg font-semibold text-black dark:text-white mt-4 mb-2">2.2 Informações Técnicas</h3>
            <ul className="list-disc pl-6 space-y-1">
              <li>Tipo de dispositivo e sistema operativo</li>
              <li>Identificadores únicos do dispositivo</li>
              <li>Endereço IP</li>
              <li>Dados de navegação e interação com a Aplicação</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">3. Como Utilizamos as Suas Informações</h2>
            <p>Utilizamos as informações recolhidas para:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Processar e gerir as suas solicitações de adiantamento</li>
              <li>Efetuar pagamentos através dos métodos bancários fornecidos</li>
              <li>Comunicar consigo sobre o estado das suas solicitações</li>
              <li>Enviar notificações relevantes sobre a sua conta</li>
              <li>Melhorar e personalizar a experiência na Aplicação</li>
              <li>Cumprir obrigações legais e regulamentares</li>
              <li>Prevenir fraudes e garantir a segurança da plataforma</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">4. Partilha de Informações</h2>
            <p>Podemos partilhar as suas informações com:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Gestores:</strong> Para aprovação e processamento das solicitações</li>
              <li><strong>Prestadores de Serviços:</strong> Empresas que nos ajudam a operar a plataforma (processamento de pagamentos, alojamento de dados)</li>
              <li><strong>Autoridades:</strong> Quando exigido por lei ou ordem judicial</li>
            </ul>
            <p className="mt-3">
              <strong>Não vendemos</strong> as suas informações pessoais a terceiros para fins de marketing.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">5. Segurança dos Dados</h2>
            <p>
              Implementamos medidas de segurança técnicas e organizacionais adequadas para proteger as suas 
              informações pessoais contra acesso não autorizado, alteração, divulgação ou destruição. Estas incluem:
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Encriptação de dados em trânsito e em repouso</li>
              <li>Autenticação segura com palavras-passe encriptadas</li>
              <li>Controlo de acesso baseado em funções</li>
              <li>Monitorização contínua de segurança</li>
              <li>Backups regulares e planos de recuperação</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">6. Retenção de Dados</h2>
            <p>
              Retemos as suas informações pessoais apenas pelo tempo necessário para cumprir os fins descritos 
              nesta política, a menos que um período de retenção mais longo seja exigido ou permitido por lei.
            </p>
            <p>
              Após a eliminação da sua conta, podemos reter determinadas informações por um período adicional 
              para cumprir obrigações legais, resolver disputas e fazer cumprir os nossos acordos.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">7. Os Seus Direitos</h2>
            <p>De acordo com a legislação aplicável (incluindo o RGPD), você tem direito a:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Acesso:</strong> Obter informação sobre os dados que temos sobre si</li>
              <li><strong>Retificação:</strong> Corrigir dados incorretos ou incompletos</li>
              <li><strong>Eliminação:</strong> Solicitar a eliminação dos seus dados pessoais</li>
              <li><strong>Portabilidade:</strong> Receber os seus dados num formato estruturado</li>
              <li><strong>Oposição:</strong> Opor-se ao processamento dos seus dados em certas circunstâncias</li>
              <li><strong>Limitação:</strong> Solicitar a limitação do processamento</li>
            </ul>
            <p className="mt-3">
              Para exercer estes direitos, pode utilizar a funcionalidade "Excluir Minha Conta" na Aplicação 
              ou contactar-nos através dos dados indicados abaixo.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">8. Cookies e Tecnologias Similares</h2>
            <p>
              A nossa Aplicação pode utilizar tecnologias de armazenamento local (como localStorage) para 
              melhorar a sua experiência, guardar preferências e manter a sessão iniciada. Estas tecnologias 
              são essenciais para o funcionamento da Aplicação.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">9. Transferências Internacionais</h2>
            <p>
              Os seus dados podem ser transferidos e processados em servidores localizados fora do seu país 
              de residência. Quando tal ocorrer, garantimos que existem salvaguardas adequadas para proteger 
              os seus dados de acordo com esta política e a legislação aplicável.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">10. Menores de Idade</h2>
            <p>
              A nossa Aplicação não se destina a menores de 18 anos. Não recolhemos intencionalmente 
              informações pessoais de menores. Se tomarmos conhecimento de que recolhemos dados de um menor, 
              tomaremos medidas para eliminar essas informações.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">11. Alterações a Esta Política</h2>
            <p>
              Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos sobre quaisquer 
              alterações significativas através da Aplicação ou por email. A continuação da utilização da 
              Aplicação após tais alterações constitui a sua aceitação da política atualizada.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-black dark:text-white mb-3">12. Contacto</h2>
            <p>
              Se tiver questões sobre esta Política de Privacidade ou sobre as nossas práticas de 
              privacidade, pode contactar-nos através de:
            </p>
            <div className="bg-neutral-100 dark:bg-neutral-800 rounded-xl p-4 mt-3">
              <p><strong>X88</strong></p>
              <p>Email: {displayEmail}</p>
            </div>
          </section>

          <section className="border-t border-neutral-200 dark:border-neutral-800 pt-6 mt-8">
            <p className="text-sm text-neutral-500 dark:text-neutral-400">
              Esta política de privacidade está em conformidade com o Regulamento Geral sobre a Proteção 
              de Dados (RGPD) da União Europeia e a Lei Geral de Proteção de Dados (LGPD) do Brasil.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}

export default PrivacyPolicy
