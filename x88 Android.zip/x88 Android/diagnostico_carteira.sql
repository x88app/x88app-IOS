-- Diagnóstico de Carteira e Permissões
-- Verificar estrutura e permissões da tabela carteira_gestor

-- 1. Verificar estrutura da tabela
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'carteira_gestor';

-- 2. Verificar policies existentes na carteira_gestor
SELECT * FROM pg_policies WHERE table_name = 'carteira_gestor';

-- 3. Verificar se RLS está habilitado
SELECT relname, relrowsecurity, relforcerowsecurity 
FROM pg_class 
WHERE relname = 'carteira_gestor';

-- 4. Verificar policies em transacoes_carteira
SELECT * FROM pg_policies WHERE table_name = 'transacoes_carteira';

-- 5. Tentar simular um update (sem commitar de verdade se fosse possível, mas aqui vamos apenas ler)
-- Verificando se o usuário gestor tem permissão de update
-- (Isso é mais difícil de testar sem estar logado como gestor, mas as policies dirão)
