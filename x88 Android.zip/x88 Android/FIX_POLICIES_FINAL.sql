-- =====================================================
-- CORREÇÃO FINAL: Policies para gestor fazer login
-- =====================================================

-- PROBLEMA: O app gestor tenta buscar seu próprio registro em usuarios
-- durante o login, mas as policies antigas impedem isso.

-- SOLUÇÃO: Recriar as policies corretamente

-- PASSO 1: Remover TODAS as policies antigas de usuarios
DROP POLICY IF EXISTS "Colaboradores podem ver próprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Gestores podem ver todos usuários" ON usuarios;
DROP POLICY IF EXISTS "Colaboradores podem atualizar próprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Usuarios veem proprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Gestores veem todos usuarios" ON usuarios;

-- PASSO 2: Criar policies corretas

-- Policy 1: TODOS os usuários autenticados veem seu próprio perfil
-- Essencial para o login funcionar!
CREATE POLICY "Usuarios autenticados veem proprio perfil"
    ON usuarios FOR SELECT
    USING (auth.uid() = id);

-- Policy 2: Gestores veem TODOS os usuários
CREATE POLICY "Gestores veem todos os usuarios"
    ON usuarios FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Policy 3: Usuários podem atualizar apenas seu próprio perfil
CREATE POLICY "Usuarios atualizam proprio perfil"
    ON usuarios FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- PASSO 3: Verificar se as policies foram criadas
SELECT 
    tablename,
    policyname,
    cmd,
    qual
FROM pg_policies
WHERE tablename = 'usuarios'
ORDER BY policyname;

-- PASSO 4: Testar como gestor
-- Deve retornar SEU registro
SELECT * FROM usuarios WHERE id = auth.uid();

-- Deve retornar TRUE
SELECT EXISTS (
    SELECT 1 FROM usuarios 
    WHERE id = auth.uid() 
    AND tipo_usuario IN ('gestor', 'admin')
) AS sou_gestor;

-- Deve retornar TODOS os usuários (4 registros)
SELECT COUNT(*) as total FROM usuarios;

-- Deve retornar 2 colaboradores
SELECT COUNT(*) as total FROM vw_colaboradores_completos;
