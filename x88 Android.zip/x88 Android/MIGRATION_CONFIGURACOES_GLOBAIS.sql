-- =====================================================
-- MIGRATION: Configurações Globais Compartilhadas
-- Descrição: Cria tabela única para configurações que 
-- devem ser compartilhadas entre todos os gestores
-- =====================================================

-- 1. Criar tabela de configurações globais (apenas UMA linha)
CREATE TABLE IF NOT EXISTS configuracoes_globais (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Configurações de Suporte
    email_suporte VARCHAR(255),
    telefone_suporte VARCHAR(50),
    whatsapp_suporte VARCHAR(50),
    usar_whatsapp_suporte BOOLEAN DEFAULT FALSE,
    
    -- Configurações de Taxas (padrão para todos)
    taxa_juros_padrao DECIMAL(5, 2) DEFAULT 10.00,
    limite_padrao DECIMAL(10, 2) DEFAULT 1000.00,
    
    -- Outras configurações globais
    nome_empresa VARCHAR(255),
    logo_url TEXT,
    cor_primaria VARCHAR(20) DEFAULT '#22c55e',
    
    -- Metadados
    ultima_atualizacao_por UUID REFERENCES usuarios(id),
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_atualizacao TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Garantir que existe apenas UMA linha (constraint)
CREATE UNIQUE INDEX IF NOT EXISTS idx_configuracoes_globais_unica 
ON configuracoes_globais ((true));

-- Trigger para atualizar timestamp
CREATE TRIGGER trigger_atualizar_configuracoes_globais
    BEFORE UPDATE ON configuracoes_globais
    FOR EACH ROW
    EXECUTE FUNCTION atualizar_data_modificacao();

-- 2. Inserir linha padrão (se não existir)
INSERT INTO configuracoes_globais (id)
SELECT gen_random_uuid()
WHERE NOT EXISTS (SELECT 1 FROM configuracoes_globais);

-- 3. Migrar dados existentes do primeiro gestor (se houver)
UPDATE configuracoes_globais SET
    email_suporte = (
        SELECT email_suporte FROM usuarios 
        WHERE tipo_usuario = 'gestor' AND email_suporte IS NOT NULL 
        LIMIT 1
    )
WHERE email_suporte IS NULL;

-- 4. Políticas RLS para configuracoes_globais
ALTER TABLE configuracoes_globais ENABLE ROW LEVEL SECURITY;

-- Todos podem LER as configurações globais
CREATE POLICY "Qualquer usuario pode ler configuracoes globais"
ON configuracoes_globais FOR SELECT
USING (true);

-- Apenas gestores podem ATUALIZAR
CREATE POLICY "Gestores podem atualizar configuracoes globais"
ON configuracoes_globais FOR UPDATE
USING (
    EXISTS (
        SELECT 1 FROM usuarios 
        WHERE id = auth.uid() 
        AND tipo_usuario IN ('gestor', 'admin')
        AND ativo = true
    )
);

-- Habilitar realtime
ALTER PUBLICATION supabase_realtime ADD TABLE configuracoes_globais;

-- =====================================================
-- 5. Criar View para facilitar acesso
-- =====================================================
CREATE OR REPLACE VIEW vw_configuracoes_suporte AS
SELECT 
    email_suporte,
    telefone_suporte,
    whatsapp_suporte,
    usar_whatsapp_suporte,
    nome_empresa,
    logo_url,
    cor_primaria
FROM configuracoes_globais
LIMIT 1;

-- Política para a view
GRANT SELECT ON vw_configuracoes_suporte TO authenticated;
GRANT SELECT ON vw_configuracoes_suporte TO anon;

-- =====================================================
-- 6. Função RPC para obter configurações globais
-- =====================================================
CREATE OR REPLACE FUNCTION get_configuracoes_globais()
RETURNS TABLE (
    email_suporte VARCHAR(255),
    telefone_suporte VARCHAR(50),
    whatsapp_suporte VARCHAR(50),
    usar_whatsapp_suporte BOOLEAN,
    nome_empresa VARCHAR(255),
    logo_url TEXT,
    cor_primaria VARCHAR(20)
)
LANGUAGE sql
SECURITY DEFINER
AS $$
    SELECT 
        email_suporte,
        telefone_suporte,
        whatsapp_suporte,
        usar_whatsapp_suporte,
        nome_empresa,
        logo_url,
        cor_primaria
    FROM configuracoes_globais
    LIMIT 1;
$$;

-- =====================================================
-- 7. Função RPC para atualizar configurações globais
-- =====================================================
CREATE OR REPLACE FUNCTION atualizar_configuracoes_globais(
    p_email_suporte VARCHAR(255) DEFAULT NULL,
    p_telefone_suporte VARCHAR(50) DEFAULT NULL,
    p_whatsapp_suporte VARCHAR(50) DEFAULT NULL,
    p_usar_whatsapp_suporte BOOLEAN DEFAULT NULL,
    p_nome_empresa VARCHAR(255) DEFAULT NULL,
    p_logo_url TEXT DEFAULT NULL,
    p_cor_primaria VARCHAR(20) DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_tipo VARCHAR(20);
BEGIN
    -- Verificar se usuário é gestor/admin
    SELECT tipo_usuario INTO v_user_tipo
    FROM usuarios
    WHERE id = auth.uid();
    
    IF v_user_tipo NOT IN ('gestor', 'admin') THEN
        RAISE EXCEPTION 'Apenas gestores podem atualizar configurações';
    END IF;
    
    -- Atualizar apenas campos não nulos
    UPDATE configuracoes_globais SET
        email_suporte = COALESCE(p_email_suporte, email_suporte),
        telefone_suporte = COALESCE(p_telefone_suporte, telefone_suporte),
        whatsapp_suporte = COALESCE(p_whatsapp_suporte, whatsapp_suporte),
        usar_whatsapp_suporte = COALESCE(p_usar_whatsapp_suporte, usar_whatsapp_suporte),
        nome_empresa = COALESCE(p_nome_empresa, nome_empresa),
        logo_url = COALESCE(p_logo_url, logo_url),
        cor_primaria = COALESCE(p_cor_primaria, cor_primaria),
        ultima_atualizacao_por = auth.uid(),
        data_atualizacao = NOW();
    
    RETURN TRUE;
END;
$$;

COMMENT ON TABLE configuracoes_globais IS 'Configurações compartilhadas entre todos os gestores - apenas UMA linha existe nesta tabela';
COMMENT ON FUNCTION get_configuracoes_globais IS 'Retorna as configurações globais do sistema';
COMMENT ON FUNCTION atualizar_configuracoes_globais IS 'Atualiza as configurações globais - apenas gestores';
