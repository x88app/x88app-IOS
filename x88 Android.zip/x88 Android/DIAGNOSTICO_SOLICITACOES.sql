-- =====================================================
-- DIAGNÓSTICO: SOLICITAÇÕES INVISÍVEIS
-- =====================================================

-- 1. Verificar quem sou eu
SELECT auth.uid() as meu_id, auth.role() as role;

-- 2. Verificar se sou gestor
SELECT EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo_usuario IN ('gestor', 'admin')) as sou_gestor;

-- 3. Contar solicitações (SEM RLS - se possível)
-- SET session_replication_role = 'replica';
-- SELECT count(*) as total_real FROM solicitacoes;
-- SET session_replication_role = 'origin';

-- 4. Contar solicitações que eu vejo (COM RLS)
SELECT count(*) as total_visivel FROM solicitacoes;

-- 5. Contar solicitações na VIEW
SELECT count(*) as total_view FROM vw_solicitacoes_completas;

-- 6. Verificar policies da tabela solicitacoes
SELECT policyname, cmd, qual 
FROM pg_policies 
WHERE tablename = 'solicitacoes';

-- 7. Tentar ler diretamente da tabela usuarios (para garantir que o EXISTS funciona)
SELECT count(*) as total_usuarios FROM usuarios;

-- 8. Tentar ler diretamente da tabela colaboradores
SELECT count(*) as total_colaboradores FROM colaboradores;

-- 9. Verificar se existe alguma solicitacao no banco
SELECT id, colaborador_id, valor_solicitado, status FROM solicitacoes LIMIT 5;
