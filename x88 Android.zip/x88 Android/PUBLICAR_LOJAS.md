# 📱 Guia Completo: Publicar X88 Colaborador nas Lojas

## ✅ Status Atual
- ✅ Capacitor configurado
- ✅ Projeto Android criado (`/android`)
- ✅ Projeto iOS criado (`/ios`)
- ✅ Plugins nativos instalados

---

# 🤖 PARTE 1: GOOGLE PLAY STORE (Android)

## Pré-requisitos
- ✅ Android Studio instalado ([Download](https://developer.android.com/studio))
- ✅ Conta Google Play Console ativa (você já tem!)
- ✅ JDK 17+ instalado

## Passo 1: Abrir no Android Studio

```bash
cd c:\Users\silvi\Documents\colaborador
npx cap open android
```

Ou abra o Android Studio e selecione: **File → Open → Selecione a pasta `android`**

## Passo 2: Configurar Ícones do App

No Android Studio:
1. Clique direito em `app` → **New → Image Asset**
2. Selecione **Launcher Icons (Adaptive and Legacy)**
3. Em "Source Asset", escolha o logo: `public/logos/logotipo X88 green.fw.png`
4. Background color: `#000000`
5. Clique **Next → Finish**

## Passo 3: Gerar Keystore (Chave de Assinatura)

⚠️ **IMPORTANTE: Guarde esta chave para sempre! Sem ela, você não poderá atualizar o app.**

No terminal do Android Studio:
```bash
keytool -genkey -v -keystore x88-colaborador-key.keystore -alias x88colaborador -keyalg RSA -keysize 2048 -validity 10000
```

Preencha:
- Senha: (crie uma senha forte e GUARDE!)
- Nome: Seu nome ou empresa
- Organização: X88
- Cidade, Estado, País: seus dados

## Passo 4: Configurar Assinatura

1. No Android Studio: **Build → Generate Signed Bundle / APK**
2. Selecione **Android App Bundle**
3. Selecione o keystore criado
4. Preencha senha e alias
5. Selecione **release**
6. Clique **Create**

O arquivo `.aab` será gerado em: `android/app/release/app-release.aab`

## Passo 5: Publicar no Google Play Console

1. Acesse [Google Play Console](https://play.google.com/console)
2. Clique **Criar app**
3. Preencha:
   - Nome: **X88 Colaborador**
   - Idioma: Português (Brasil)
   - Tipo: App
   - Gratuito/Pago: Gratuito

4. Na seção **Versão de produção**:
   - Clique **Criar nova versão**
   - Faça upload do arquivo `.aab`

5. Preencha a **Ficha da loja**:
   - Descrição curta (80 caracteres)
   - Descrição completa (4000 caracteres)
   - Screenshots (mínimo 2)
   - Ícone 512x512 PNG
   - Gráfico de recursos 1024x500

6. **Configurações obrigatórias**:
   - Classificação de conteúdo (preencha questionário)
   - Público-alvo (18+)
   - Política de privacidade (URL obrigatória)
   - Categoria: Finanças ou Negócios

7. Clique **Enviar para revisão**

### ⏱️ Tempo de Aprovação: 1-7 dias

---

# 🍎 PARTE 2: APPLE APP STORE (iOS)

## Pré-requisitos
- ⚠️ **Mac obrigatório** (não funciona no Windows)
- ✅ Xcode 15+ instalado ([Download na Mac App Store](https://apps.apple.com/app/xcode/id497799835))
- ✅ Conta Apple Developer ativa (você já tem!)

## Passo 1: Copiar projeto para Mac

Copie toda a pasta `colaborador` para o Mac (via pendrive, Google Drive, etc.)

## Passo 2: Instalar dependências no Mac

```bash
cd /caminho/para/colaborador
npm install
npm run build
npx cap sync ios
cd ios/App
pod install
```

## Passo 3: Abrir no Xcode

```bash
npx cap open ios
```

Ou abra o Xcode e selecione: `ios/App/App.xcworkspace`

## Passo 4: Configurar Projeto no Xcode

1. Selecione o projeto **App** no navegador lateral
2. Em **Signing & Capabilities**:
   - Team: Selecione sua conta Apple Developer
   - Bundle Identifier: `com.x88.colaborador`
   - Marque: **Automatically manage signing**

## Passo 5: Configurar Ícones

1. No Xcode, vá em **App → Assets → AppIcon**
2. Arraste o logo `logotipo X88 green.fw.png` em cada slot
3. Ou use [AppIcon Generator](https://appicon.co) para gerar todos os tamanhos

## Passo 6: Gerar Build de Produção

1. Selecione **Any iOS Device** no seletor de dispositivo
2. Menu: **Product → Archive**
3. Aguarde o build finalizar
4. Na janela Organizer, clique **Distribute App**
5. Selecione **App Store Connect**
6. Clique **Upload**

## Passo 7: Publicar no App Store Connect

1. Acesse [App Store Connect](https://appstoreconnect.apple.com)
2. Clique **Meus Apps → +** → **Novo App**
3. Preencha:
   - Nome: **X88 Colaborador**
   - Idioma principal: Português (Brasil)
   - Bundle ID: `com.x88.colaborador`
   - SKU: `x88colaborador`

4. Na aba **App Store**:
   - Screenshots iPhone (6.7" e 5.5")
   - Descrição
   - Palavras-chave
   - URL de suporte
   - Política de privacidade (obrigatória)

5. Em **Build**, selecione o build enviado

6. Preencha **App Review Information**:
   - Dados de contato
   - Notas para revisão (se necessário)

7. Clique **Enviar para revisão**

### ⏱️ Tempo de Aprovação: 1-3 dias

---

# 📸 Screenshots Necessários

## Google Play
| Tipo | Tamanho |
|------|---------|
| Celular | 1080x1920 (mín 2, máx 8) |
| Tablet 7" | 1200x1920 (opcional) |
| Tablet 10" | 1600x2560 (opcional) |
| Gráfico de recursos | 1024x500 |
| Ícone | 512x512 PNG |

## App Store
| Tipo | Tamanho |
|------|---------|
| iPhone 6.7" | 1290x2796 |
| iPhone 5.5" | 1242x2208 |
| iPad 12.9" | 2048x2732 (se suportar iPad) |

---

# 📋 Checklist Final

## Antes de Publicar
- [ ] Ícone do app configurado (ambas plataformas)
- [ ] Splash screen configurada
- [ ] Nome do app correto
- [ ] Bundle ID: `com.x88.colaborador`
- [ ] Versão: `1.0.0`
- [ ] Screenshots prontos
- [ ] Descrição do app escrita
- [ ] Política de privacidade publicada online
- [ ] URL de suporte

## Política de Privacidade
Você precisa de uma página com política de privacidade. Opções:
1. Crie uma página no seu site
2. Use [TermsFeed](https://www.termsfeed.com/blog/sample-privacy-policy-template/)
3. Use [Privacy Policy Generator](https://app-privacy-policy-generator.firebaseapp.com/)

---

# 🔄 Comandos Úteis

## Atualizar o App (após mudanças no código)
```bash
npm run build
npx cap sync
```

## Abrir projetos nativos
```bash
npx cap open android   # Abre Android Studio
npx cap open ios       # Abre Xcode (só Mac)
```

## Verificar status
```bash
npx cap doctor
```

---

# 🚨 Problemas Comuns

## Android: "SDK location not found"
Crie arquivo `android/local.properties`:
```
sdk.dir=C\:\\Users\\SEU_USUARIO\\AppData\\Local\\Android\\Sdk
```

## iOS: "No signing certificate"
- Abra Xcode → Preferences → Accounts
- Faça login com Apple ID
- Clique "Download Manual Profiles"

## iOS: "pod install" falha
```bash
sudo gem install cocoapods
cd ios/App
pod install
```

---

# 📞 Suporte

Se precisar de ajuda:
- [Documentação Capacitor](https://capacitorjs.com/docs)
- [Google Play Console Help](https://support.google.com/googleplay/android-developer)
- [App Store Connect Help](https://developer.apple.com/help/app-store-connect/)

---

**Boa sorte com a publicação! 🚀**
