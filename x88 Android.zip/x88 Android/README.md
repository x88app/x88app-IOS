# X88 Colaborador - Aplicativo do Motorista

## 📱 Sobre o Projeto

Aplicativo móvel (PWA) para colaboradores/motoristas da X88 solicitarem adiantamentos de forma rápida e eficiente.

## 🎨 Design

- **Cores**: Preto, Verde (#22c55e) e Branco
- **Fonte**: Inter
- **Estilo**: Moderno, mobile-first com bottom navigation

## ⚡ Funcionalidades

### Para Colaboradores
- 🏠 Dashboard com resumo de solicitações
- 💰 Solicitar adiantamentos com wizard de 3 passos
- 📋 Acompanhar status das solicitações
- 💳 Gerenciar dados bancários (IBAN e MB Way)
- 💼 Histórico de pagamentos recebidos
- 👤 Perfil pessoal completo

## 🚀 Tecnologias

- **React 18** com TypeScript
- **Vite** para build e desenvolvimento
- **Tailwind CSS** para estilização
- **React Router** para navegação
- **Lucide React** para ícones
- **Tanstack Query** para gerenciamento de estado
- **PWA** com service workers

## 📦 Instalação

```bash
# Instalar dependências
npm install

# Iniciar desenvolvimento
npm run dev

# Build de produção
npm run build

# Preview da build
npm run preview
```

## 📁 Estrutura do Projeto

```
colaborador/
├── public/
│   ├── icons/           # Ícones PWA
│   └── manifest.webmanifest
├── src/
│   ├── components/
│   │   ├── layout/      # Header, BottomNav
│   │   ├── ui/          # Componentes reutilizáveis
│   │   └── forms/       # Inputs especializados
│   ├── pages/
│   │   ├── Home/        # Dashboard principal
│   │   ├── Requests/    # Solicitações
│   │   ├── Wallet/      # Carteira
│   │   ├── Profile/     # Perfil
│   │   └── Onboarding/  # Cadastro inicial
│   ├── features/
│   │   ├── advances/    # Lógica de adiantamentos
│   │   └── bank/        # Lógica de dados bancários
│   ├── lib/             # Utilitários
│   ├── hooks/           # React hooks customizados
│   └── styles/          # Estilos globais
├── App.tsx
├── main.tsx
└── vite.config.ts
```

## 🔐 Dados Bancários

O aplicativo suporta dois métodos de recebimento:

### MB Way
- Número de telefone português (+351)
- Pagamentos instantâneos
- Validação em tempo real

### IBAN
- IBAN português (PT50...)
- Validação de checksum
- Nome do titular
- SWIFT/BIC opcional
- Processamento em até 1 dia útil

## 📝 Fluxo de Solicitação

1. **Passo 1**: Valor e motivo
   - Insere valor desejado
   - Seleciona motivo (Combustível, Portagens, Manutenção, Outro)
   - Visualiza valor líquido (após taxa de 10%)

2. **Passo 2**: Descrição e método
   - Detalha a justificativa
   - Escolhe método de recebimento (MB Way ou IBAN)

3. **Passo 3**: Confirmação
   - Revisa todos os dados
   - Aceita termos e condições
   - Envia solicitação

## 🎯 Status das Solicitações

- **Pendente**: Aguardando análise do gestor
- **Aprovada**: Aprovada pelo gestor
- **Paga**: Pagamento processado
- **Rejeitada**: Negada pelo gestor (com justificativa)

## 🔄 Integração Futura

O aplicativo será integrado ao sistema de gestão através do **Supabase**:

- Autenticação via Supabase Auth
- Banco de dados PostgreSQL com RLS (Row Level Security)
- Queries em tempo real com TanStack Query
- Notificações push

### Schema Planejado (Supabase)

```sql
-- Tabela de motoristas
drivers (
  id, auth_user_id, name, phone, email, created_at
)

-- Tabela de dados bancários
driver_bank_accounts (
  id, driver_id, preferred_method, iban, bank_holder_name,
  swift_bic, mbway_phone, consent_terms, verified_at
)

-- Tabela de solicitações
advance_requests (
  id, driver_id, amount, payout_method, reason, reason_note,
  status, approved_by, approved_at, paid_at, notes
)
```

## 🔒 Segurança

- RLS habilitado em todas as tabelas
- Cada colaborador só acessa seus próprios dados
- Validação de IBAN com checksum mod 97
- Dados bancários criptografados
- Consentimento LGPD obrigatório

## 📱 PWA Features

- ✅ Instalável no dispositivo
- ✅ Funciona offline (planejado)
- ✅ Notificações push (planejado)
- ✅ Ícones personalizados
- ✅ Tema dark/light

## 🎨 Componentes Principais

- **Header**: Logo, modo escuro, notificações
- **BottomNav**: Navegação principal com 5 tabs
- **RequestCard**: Card de solicitação com status
- **PaymentCard**: Card de pagamento recebido
- **IBANInput**: Input com validação de IBAN
- **PhoneInput**: Input com máscara para telefone PT

## 🌐 Ambiente de Desenvolvimento

- **Porta**: 3001
- **Hot reload**: Habilitado
- **TypeScript**: Strict mode

## 📄 Licença

Projeto privado - Todos os direitos reservados © 2025 X88
