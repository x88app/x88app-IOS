-- =====================================================
-- FIX DE REGISTRO: Permitir inserção de usuários e colaboradores
-- =====================================================

-- 1. Policy para tabela USUARIOS (Permitir auto-registro)
-- Primeiro removemos policies de insert antigas para evitar conflitos
DROP POLICY IF EXISTS "Usuarios criam proprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Enable insert for users based on user_id" ON usuarios;
DROP POLICY IF EXISTS "insert_own_profile" ON usuarios;

-- Cria policy que permite INSERT se o ID bater com o UID do Auth
CREATE POLICY "Usuarios criam proprio perfil"
    ON usuarios FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);

-- 2. Policy para tabela COLABORADORES (Permitir auto-registro)
DROP POLICY IF EXISTS "Colaboradores criam proprio perfil" ON colaboradores;
DROP POLICY IF EXISTS "Enable insert for own collaborator profile" ON colaboradores;
DROP POLICY IF EXISTS "insert_own_colaborador" ON colaboradores;

-- Cria policy que permite INSERT se o usuario_id bater com o UID do Auth
CREATE POLICY "Colaboradores criam proprio perfil"
    ON colaboradores FOR INSERT
    TO authenticated
    WITH CHECK (usuario_id = auth.uid());

-- 3. Garantir que policies de SELECT permitam ver o próprio registro recém criado
-- (Caso as policies do FIX_POLICIES_FINAL.sql não tenham sido rodadas)

-- Usuarios: Ver próprio
DROP POLICY IF EXISTS "Usuarios autenticados veem proprio perfil" ON usuarios;
CREATE POLICY "Usuarios autenticados veem proprio perfil"
    ON usuarios FOR SELECT
    TO authenticated
    USING (auth.uid() = id);

-- Colaboradores: Ver próprio
DROP POLICY IF EXISTS "Colaboradores veem proprio perfil" ON colaboradores;
CREATE POLICY "Colaboradores veem proprio perfil"
    ON colaboradores FOR SELECT
    TO authenticated
    USING (usuario_id = auth.uid());

-- 4. Verificação
SELECT 
    tablename,
    policyname,
    cmd,
    qual
FROM pg_policies
WHERE tablename IN ('usuarios', 'colaboradores')
ORDER BY tablename, cmd;
