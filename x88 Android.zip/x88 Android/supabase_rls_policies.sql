-- =====================================================
-- POLÍTICAS RLS (ROW LEVEL SECURITY) - SUPABASE
-- Versão: 1.0.0
-- Descrição: Políticas de segurança em nível de linha
-- =====================================================

-- =====================================================
-- HABILITAR RLS EM TODAS AS TABELAS
-- =====================================================

ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE colaboradores ENABLE ROW LEVEL SECURITY;
ALTER TABLE solicitacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE notificacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE carteira_gestor ENABLE ROW LEVEL SECURITY;
ALTER TABLE transacoes_carteira ENABLE ROW LEVEL SECURITY;
ALTER TABLE banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE cards_anuncio ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_sistema ENABLE ROW LEVEL SECURITY;
ALTER TABLE auditoria ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- POLÍTICAS PARA: usuarios
-- =====================================================

-- Colaboradores podem ver apenas seus próprios dados
CREATE POLICY "Colaboradores podem ver próprio perfil"
    ON usuarios FOR SELECT
    USING (
        auth.uid() = id 
        OR 
        tipo_usuario = 'gestor'
    );

-- Colaboradores podem atualizar apenas seus próprios dados
CREATE POLICY "Colaboradores podem atualizar próprio perfil"
    ON usuarios FOR UPDATE
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Gestores podem ver todos os usuários
CREATE POLICY "Gestores podem ver todos usuários"
    ON usuarios FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Permitir inserção de novos usuários (registro)
CREATE POLICY "Permitir registro de novos usuários"
    ON usuarios FOR INSERT
    WITH CHECK (true);

-- =====================================================
-- POLÍTICAS PARA: colaboradores
-- =====================================================

-- Colaboradores podem ver apenas seus próprios dados
CREATE POLICY "Colaboradores podem ver próprios dados"
    ON colaboradores FOR SELECT
    USING (
        usuario_id = auth.uid()
        OR
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Colaboradores podem atualizar apenas seus próprios dados
CREATE POLICY "Colaboradores podem atualizar próprios dados"
    ON colaboradores FOR UPDATE
    USING (usuario_id = auth.uid())
    WITH CHECK (usuario_id = auth.uid());

-- Gestores podem atualizar qualquer colaborador
CREATE POLICY "Gestores podem atualizar colaboradores"
    ON colaboradores FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Gestores podem inserir novos colaboradores
CREATE POLICY "Gestores podem inserir colaboradores"
    ON colaboradores FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- =====================================================
-- POLÍTICAS PARA: solicitacoes
-- =====================================================

-- Colaboradores podem ver apenas suas próprias solicitações
CREATE POLICY "Colaboradores veem próprias solicitações"
    ON solicitacoes FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE id = colaborador_id 
            AND usuario_id = auth.uid()
        )
        OR
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Colaboradores podem criar solicitações
CREATE POLICY "Colaboradores podem criar solicitações"
    ON solicitacoes FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE id = colaborador_id 
            AND usuario_id = auth.uid()
        )
    );

-- Colaboradores podem atualizar apenas suas solicitações pendentes
CREATE POLICY "Colaboradores atualizam próprias solicitações"
    ON solicitacoes FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE id = colaborador_id 
            AND usuario_id = auth.uid()
        )
        AND status IN ('pendente', 'processando')
    );

-- Gestores podem atualizar qualquer solicitação
CREATE POLICY "Gestores atualizam qualquer solicitação"
    ON solicitacoes FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- Gestores podem deletar solicitações
CREATE POLICY "Gestores podem deletar solicitações"
    ON solicitacoes FOR DELETE
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- =====================================================
-- POLÍTICAS PARA: notificacoes
-- =====================================================

-- Usuários veem apenas suas próprias notificações
CREATE POLICY "Usuários veem próprias notificações"
    ON notificacoes FOR SELECT
    USING (usuario_id = auth.uid());

-- Sistema pode inserir notificações
CREATE POLICY "Sistema pode inserir notificações"
    ON notificacoes FOR INSERT
    WITH CHECK (true);

-- Usuários podem atualizar (marcar como lida) suas notificações
CREATE POLICY "Usuários atualizam próprias notificações"
    ON notificacoes FOR UPDATE
    USING (usuario_id = auth.uid())
    WITH CHECK (usuario_id = auth.uid());

-- Usuários podem deletar suas próprias notificações
CREATE POLICY "Usuários deletam próprias notificações"
    ON notificacoes FOR DELETE
    USING (usuario_id = auth.uid());

-- =====================================================
-- POLÍTICAS PARA: carteira_gestor
-- =====================================================

-- Apenas gestores podem ver a carteira
CREATE POLICY "Gestores veem própria carteira"
    ON carteira_gestor FOR SELECT
    USING (
        gestor_id = auth.uid()
        OR
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario = 'admin'
        )
    );

-- Gestores podem atualizar própria carteira
CREATE POLICY "Gestores atualizam própria carteira"
    ON carteira_gestor FOR UPDATE
    USING (gestor_id = auth.uid())
    WITH CHECK (gestor_id = auth.uid());

-- Gestores podem inserir carteira
CREATE POLICY "Gestores podem inserir carteira"
    ON carteira_gestor FOR INSERT
    WITH CHECK (gestor_id = auth.uid());

-- =====================================================
-- POLÍTICAS PARA: transacoes_carteira
-- =====================================================

-- Gestores veem transações de sua carteira
CREATE POLICY "Gestores veem próprias transações"
    ON transacoes_carteira FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM carteira_gestor 
            WHERE id = carteira_id 
            AND gestor_id = auth.uid()
        )
        OR
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario = 'admin'
        )
    );

-- Sistema pode inserir transações
CREATE POLICY "Sistema insere transações"
    ON transacoes_carteira FOR INSERT
    WITH CHECK (true);

-- =====================================================
-- POLÍTICAS PARA: banners
-- =====================================================

-- Todos podem ver banners ativos
CREATE POLICY "Todos veem banners ativos"
    ON banners FOR SELECT
    USING (ativo = true OR EXISTS (
        SELECT 1 FROM usuarios 
        WHERE id = auth.uid() 
        AND tipo_usuario IN ('gestor', 'admin')
    ));

-- Apenas gestores podem gerenciar banners
CREATE POLICY "Gestores gerenciam banners"
    ON banners FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- =====================================================
-- POLÍTICAS PARA: cards_anuncio
-- =====================================================

-- Todos podem ver cards ativos
CREATE POLICY "Todos veem cards ativos"
    ON cards_anuncio FOR SELECT
    USING (ativo = true OR EXISTS (
        SELECT 1 FROM usuarios 
        WHERE id = auth.uid() 
        AND tipo_usuario IN ('gestor', 'admin')
    ));

-- Apenas gestores podem gerenciar cards
CREATE POLICY "Gestores gerenciam cards"
    ON cards_anuncio FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- =====================================================
-- POLÍTICAS PARA: configuracoes_sistema
-- =====================================================

-- Todos podem ler configurações públicas
CREATE POLICY "Todos leem configurações públicas"
    ON configuracoes_sistema FOR SELECT
    USING (true);

-- Apenas admins podem alterar configurações
CREATE POLICY "Admins gerenciam configurações"
    ON configuracoes_sistema FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario = 'admin'
        )
    );

-- =====================================================
-- POLÍTICAS PARA: auditoria
-- =====================================================

-- Apenas admins podem ver auditoria
CREATE POLICY "Admins veem auditoria"
    ON auditoria FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario = 'admin'
        )
    );

-- Sistema pode inserir logs de auditoria
CREATE POLICY "Sistema insere auditoria"
    ON auditoria FOR INSERT
    WITH CHECK (true);

-- =====================================================
-- FIM DAS POLÍTICAS RLS
-- =====================================================
