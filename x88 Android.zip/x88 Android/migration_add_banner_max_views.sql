-- Adiciona coluna para limitar quantidade de visualizações por usuário
-- Se NULL ou 0, considera sem limite (ou definiremos uma lógica no front)
ALTER TABLE public.banners 
ADD COLUMN IF NOT EXISTS max_views integer DEFAULT 3;

-- Atualiza os existentes para ter um padrão (ex: 3 vezes)
UPDATE public.banners SET max_views = 3 WHERE max_views IS NULL;
