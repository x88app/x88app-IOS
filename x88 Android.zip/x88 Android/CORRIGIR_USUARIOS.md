# 🔧 Como Corrigir os Usuários no Supabase

## ⚠️ Problema

Você inseriu dados na tabela `usuarios`, mas os UUIDs não correspondem aos usuários do **Supabase Authentication**. Isso impede o login!

---

## ✅ Solução Rápida

### **Passo 1: Criar Usuários no Authentication**

1. No Supabase, vá em **Authentication** → **Users**
2. Clique em **Add user** → **Create new user**
3. Crie cada usuário abaixo:

| Email | Senha Sugerida | Confirmar? |
|-------|----------------|------------|
| `gestor@x88.pt` | `Gestor@123` | ✅ Sim |
| `joao.silva@x88.pt` | `Joao@123` | ✅ Sim |
| `maria.santos@x88.pt` | `Maria@123` | ✅ Sim |
| `pedro.costa@x88.pt` | `Pedro@123` | ✅ Sim |
| `ana.ferreira@x88.pt` | `Ana@123` | ✅ Sim |
| `carlos.oliveira@x88.pt` | `Carlos@123` | ✅ Sim |

**IMPORTANTE:** Marque **"Auto Confirm User"** para cada um!

---

### **Passo 2: Obter os UUIDs Reais**

Depois de criar os usuários, execute no **SQL Editor**:

```sql
SELECT id, email FROM auth.users ORDER BY email;
```

**Copie os IDs** que aparecerem! Exemplo:
```
550e8400-e29b-41d4-a716-446655440000 | ana.ferreira@x88.pt
660e8400-e29b-41d4-a716-446655440001 | carlos.oliveira@x88.pt
...
```

---

### **Passo 3: Limpar Dados Antigos**

Execute no SQL Editor:

```sql
TRUNCATE TABLE auditoria CASCADE;
TRUNCATE TABLE transacoes_carteira CASCADE;
TRUNCATE TABLE notificacoes CASCADE;
TRUNCATE TABLE solicitacoes CASCADE;
TRUNCATE TABLE carteira_gestor CASCADE;
TRUNCATE TABLE colaboradores CASCADE;
TRUNCATE TABLE usuarios CASCADE;
```

---

### **Passo 4: Inserir Dados Corretos**

Abra o arquivo `supabase_criar_usuarios_auth.sql` que criei.

**SUBSTITUA** os UUIDs pelo IDs reais que você copiou no Passo 2:

```sql
-- ANTES (ERRADO):
INSERT INTO usuarios (id, nome, email, ...) VALUES (
    'COLE-AQUI-O-UUID-DO-GESTOR',  -- ❌
    'Gestor de administração X88',
    'gestor@x88.pt',
    ...
);

-- DEPOIS (CORRETO):
INSERT INTO usuarios (id, nome, email, ...) VALUES (
    '770e8400-e29b-41d4-a716-446655440003',  -- ✅ UUID real!
    'Gestor de administração X88',
    'gestor@x88.pt',
    ...
);
```

Faça isso para **TODOS os 6 usuários**.

Execute o script modificado no SQL Editor.

---

### **Passo 5: Inserir Colaboradores**

Depois execute o resto do `supabase_seed.sql` (colaboradores, solicitações, etc.)

---

## 🚨 Alternativa Mais Simples

Se preferir, posso criar uma **página de cadastro** nos apps que:
- Cria usuário no Auth automaticamente
- Insere na tabela usuarios
- Cria colaborador se necessário

**Você prefere:**
- [ ] **A)** Fazer manualmente (seguir os passos acima)
- [ ] **B)** Eu criar sistema de cadastro automático

Me avise o que prefere! 😊
