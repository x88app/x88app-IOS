# Como Corrigir Permissões dos Gestores

## Problema Identificado

Os gestores não conseguem ver os colaboradores e solicitações porque **faltam políticas RLS (Row Level Security)** no Supabase para permitir que gestores acessem esses dados.

## Solução

Execute o script SQL no Supabase para adicionar as permissões corretas.

## Passos para Corrigir

### 1. Acesse o Supabase Dashboard

1. Abra [https://supabase.com](https://supabase.com)
2. Faça login na sua conta
3. Selecione o projeto do X88

### 2. Abra o SQL Editor

1. No menu lateral, clique em **SQL Editor**
2. Clique em **New Query**

### 3. Execute o Script de Correção

Copie e cole o conteúdo do arquivo **`fix_gestor_permissions.sql`** no editor SQL e clique em **RUN**.

O script irá:
- ✅ Adicionar política para gestores verem TODOS os colaboradores
- ✅ Adicionar política para gestores atualizarem colaboradores
- ✅ Adicionar política para gestores verem TODAS as solicitações
- ✅ Adicionar política para gestores atualizarem solicitações
- ✅ Adicionar política para gestores verem todos os usuários

### 4. Verificar se Funcionou

Após executar o script:

1. Abra o aplicativo do **Gestor**
2. Faça login com uma conta de gestor
3. Verifique se:
   - ✅ A contagem de colaboradores aparece na página inicial
   - ✅ As solicitações aparecem na lista
   - ✅ Você consegue ver detalhes dos colaboradores

## O que o Script Faz

O script adiciona 5 novas políticas RLS:

### 1. `Gestores veem todos colaboradores`
Permite que qualquer usuário com `tipo_usuario = 'gestor'` veja todos os registros da tabela `colaboradores`.

### 2. `Gestores atualizam colaboradores`
Permite que gestores atualizem dados dos colaboradores (status, limites, etc.).

### 3. `Gestores veem todas solicitações`
Permite que gestores vejam todas as solicitações de todos os colaboradores.

### 4. `Gestores atualizam solicitações`
Permite que gestores aprovem, rejeitem e marquem solicitações como pagas.

### 5. `Gestores veem todos usuários`
Permite que gestores vejam os dados básicos de todos os usuários (necessário para as views).

## Conceito Importante

**Todos os gestores veem os mesmos dados:**
- Se você criar 5 contas de gestor, todas verão os mesmos colaboradores e solicitações
- Não há separação por gestor - é um sistema centralizado
- Múltiplos gestores podem administrar o mesmo pool de colaboradores

## Troubleshooting

### Erro ao executar o script

Se você receber um erro ao executar o script, pode ser que:

1. **As políticas já existam**: Tudo bem, o script tem `DROP POLICY IF EXISTS` para lidar com isso
2. **Falta permissão**: Certifique-se de que está logado como admin do projeto no Supabase

### Ainda não aparece nada após executar

1. **Verifique o tipo de usuário**: 
   - Abra a tabela `usuarios` no Supabase
   - Confirme que sua conta tem `tipo_usuario = 'gestor'`
   
2. **Verifique se há dados**:
   - Abra a tabela `colaboradores` e veja se existem registros
   - Abra a tabela `solicitacoes` e veja se existem registros

3. **Limpe o cache do navegador**:
   - Pressione `Ctrl + Shift + R` (Windows/Linux) ou `Cmd + Shift + R` (Mac)
   - Ou abra o aplicativo em uma aba anônima

4. **Verifique o console do navegador**:
   - Pressione `F12` para abrir as ferramentas de desenvolvedor
   - Vá até a aba **Console**
   - Procure por erros relacionados ao Supabase ou permissões

## Scripts Adicionais

### Verificar tipo de usuário

```sql
SELECT id, nome, email, tipo_usuario, ativo 
FROM usuarios 
WHERE tipo_usuario = 'gestor';
```

### Verificar colaboradores cadastrados

```sql
SELECT COUNT(*) as total_colaboradores 
FROM colaboradores;
```

### Verificar solicitações cadastradas

```sql
SELECT COUNT(*) as total_solicitacoes 
FROM solicitacoes;
```

### Ver todas as políticas RLS da tabela colaboradores

```sql
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'colaboradores';
```

## Próximos Passos

Após aplicar esta correção, os gestores deverão conseguir:
- ✅ Ver a contagem de colaboradores ativos
- ✅ Ver todas as solicitações pendentes, aprovadas e pagas
- ✅ Aprovar/rejeitar solicitações
- ✅ Marcar solicitações como pagas
- ✅ Ver detalhes dos colaboradores

Se ainda houver problemas, verifique os logs do Supabase no console do navegador para identificar erros específicos.
