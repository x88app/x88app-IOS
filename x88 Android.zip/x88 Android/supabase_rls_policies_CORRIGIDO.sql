-- =====================================================
-- POLÍTICAS RLS CORRIGIDAS - SEM RECURSÃO
-- =====================================================

-- PRIMEIRO: REMOVER TODAS AS POLÍTICAS ANTIGAS
DROP POLICY IF EXISTS "Colaboradores podem ver próprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Colaboradores podem atualizar próprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Gestores podem ver todos usuários" ON usuarios;
DROP POLICY IF EXISTS "Permitir registro de novos usuários" ON usuarios;

DROP POLICY IF EXISTS "Colaboradores podem ver próprios dados" ON colaboradores;
DROP POLICY IF EXISTS "Colaboradores podem atualizar próprios dados" ON colaboradores;
DROP POLICY IF EXISTS "Gestores podem atualizar colaboradores" ON colaboradores;
DROP POLICY IF EXISTS "Gestores podem inserir colaboradores" ON colaboradores;

DROP POLICY IF EXISTS "Colaboradores veem próprias solicitações" ON solicitacoes;
DROP POLICY IF EXISTS "Colaboradores podem criar solicitações" ON solicitacoes;
DROP POLICY IF EXISTS "Colaboradores atualizam próprias solicitações" ON solicitacoes;
DROP POLICY IF EXISTS "Gestores atualizam qualquer solicitação" ON solicitacoes;
DROP POLICY IF EXISTS "Gestores podem deletar solicitações" ON solicitacoes;

DROP POLICY IF EXISTS "Usuários veem próprias notificações" ON notificacoes;
DROP POLICY IF EXISTS "Sistema pode inserir notificações" ON notificacoes;
DROP POLICY IF EXISTS "Usuários atualizam próprias notificações" ON notificacoes;
DROP POLICY IF EXISTS "Usuários deletam próprias notificações" ON notificacoes;

DROP POLICY IF EXISTS "Gestores veem própria carteira" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores atualizam própria carteira" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestores podem inserir carteira" ON carteira_gestor;

DROP POLICY IF EXISTS "Gestores veem próprias transações" ON transacoes_carteira;
DROP POLICY IF EXISTS "Sistema insere transações" ON transacoes_carteira;

DROP POLICY IF EXISTS "Todos veem banners ativos" ON banners;
DROP POLICY IF EXISTS "Gestores gerenciam banners" ON banners;

DROP POLICY IF EXISTS "Todos veem cards ativos" ON cards_anuncio;
DROP POLICY IF EXISTS "Gestores gerenciam cards" ON cards_anuncio;

DROP POLICY IF EXISTS "Todos leem configurações públicas" ON configuracoes_sistema;
DROP POLICY IF EXISTS "Admins gerenciam configurações" ON configuracoes_sistema;

DROP POLICY IF EXISTS "Admins veem auditoria" ON auditoria;
DROP POLICY IF EXISTS "Sistema insere auditoria" ON auditoria;

-- =====================================================
-- NOVAS POLÍTICAS SIMPLIFICADAS (SEM RECURSÃO)
-- =====================================================

-- USUARIOS: Acesso baseado apenas no auth.uid()
CREATE POLICY "Usuários veem próprio perfil"
    ON usuarios FOR SELECT
    USING (auth.uid() = id);

CREATE POLICY "Usuários atualizam próprio perfil"
    ON usuarios FOR UPDATE
    USING (auth.uid() = id);

CREATE POLICY "Permitir inserção de novos usuários"
    ON usuarios FOR INSERT
    WITH CHECK (true);

-- COLABORADORES: Baseado em usuario_id
CREATE POLICY "Usuários veem próprios dados de colaborador"
    ON colaboradores FOR SELECT
    USING (auth.uid() = usuario_id);

CREATE POLICY "Usuários atualizam próprios dados de colaborador"
    ON colaboradores FOR UPDATE
    USING (auth.uid() = usuario_id);

CREATE POLICY "Permitir inserção de colaboradores"
    ON colaboradores FOR INSERT
    WITH CHECK (true);

-- SOLICITACOES: Baseado em colaborador_id
CREATE POLICY "Colaboradores veem próprias solicitações"
    ON solicitacoes FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE colaboradores.id = solicitacoes.colaborador_id 
            AND colaboradores.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Colaboradores criam solicitações"
    ON solicitacoes FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE colaboradores.id = colaborador_id 
            AND colaboradores.usuario_id = auth.uid()
        )
    );

CREATE POLICY "Colaboradores atualizam próprias solicitações pendentes"
    ON solicitacoes FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM colaboradores 
            WHERE colaboradores.id = solicitacoes.colaborador_id 
            AND colaboradores.usuario_id = auth.uid()
        )
        AND status IN ('pendente', 'processando')
    );

-- NOTIFICACOES: Baseado em usuario_id
CREATE POLICY "Usuários veem próprias notificações"
    ON notificacoes FOR SELECT
    USING (auth.uid() = usuario_id);

CREATE POLICY "Sistema insere notificações"
    ON notificacoes FOR INSERT
    WITH CHECK (true);

CREATE POLICY "Usuários atualizam próprias notificações"
    ON notificacoes FOR UPDATE
    USING (auth.uid() = usuario_id);

CREATE POLICY "Usuários deletam próprias notificações"
    ON notificacoes FOR DELETE
    USING (auth.uid() = usuario_id);

-- CARTEIRA GESTOR: Baseado em gestor_id
CREATE POLICY "Gestores veem própria carteira"
    ON carteira_gestor FOR SELECT
    USING (auth.uid() = gestor_id);

CREATE POLICY "Gestores atualizam própria carteira"
    ON carteira_gestor FOR UPDATE
    USING (auth.uid() = gestor_id);

CREATE POLICY "Gestores inserem carteira"
    ON carteira_gestor FOR INSERT
    WITH CHECK (auth.uid() = gestor_id);

-- TRANSACOES CARTEIRA: Baseado em carteira do gestor
CREATE POLICY "Gestores veem próprias transações"
    ON transacoes_carteira FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM carteira_gestor 
            WHERE carteira_gestor.id = transacoes_carteira.carteira_id 
            AND carteira_gestor.gestor_id = auth.uid()
        )
    );

CREATE POLICY "Sistema insere transações"
    ON transacoes_carteira FOR INSERT
    WITH CHECK (true);

-- BANNERS: Todos podem ver
CREATE POLICY "Todos veem banners ativos"
    ON banners FOR SELECT
    USING (ativo = true);

-- CARDS ANUNCIO: Todos podem ver
CREATE POLICY "Todos veem cards ativos"
    ON cards_anuncio FOR SELECT
    USING (ativo = true);

-- CONFIGURACOES: Todos podem ler
CREATE POLICY "Todos leem configurações"
    ON configuracoes_sistema FOR SELECT
    USING (true);

-- AUDITORIA: Sem políticas (apenas admin via service_role)
-- Não criar políticas para auditoria por enquanto

-- =====================================================
-- FIM DAS POLÍTICAS CORRIGIDAS
-- =====================================================
