-- ==============================================================================
-- HABILITAR REALTIME PARA SOLICITAÇÕES
-- ==============================================================================

-- 1. Adicionar a tabela 'solicitacoes' à publicação do Supabase Realtime
-- Isso permite que o frontend receba atualizações em tempo real
alter publication supabase_realtime add table solicitacoes;

-- 2. Adicionar também a tabela 'notificacoes' se quiser que as notificações
-- apareçam instantaneamente
alter publication supabase_realtime add table notificacoes;

-- 3. Verificar se a replicação foi ativada (opcional, apenas para confirmação visual)
select * from pg_publication_tables where pubname = 'supabase_realtime';
