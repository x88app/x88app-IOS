-- ==============================================================================
-- SOLUÇÃO FINAL: FORÇAR VISIBILIDADE E ATIVAÇÃO
-- ==============================================================================

-- 1. Garantir que o SEU usuário (silvioluigmj@gmail.com) é GESTOR
-- Sem isso, as policies retornam FALSE e você não vê nada.
UPDATE usuarios 
SET tipo_usuario = 'gestor', ativo = true 
WHERE email = 'silvioluigmj@gmail.com';

-- 2. Ativar TODOS os colaboradores
-- O painel filtra por "status = 'ativo'". Se estiver 'pendente', mostra 0.
UPDATE colaboradores 
SET status = 'ativo';

-- 3. Grant de permissão na função de segurança
-- Garante que o app possa executar a verificação de cargo
GRANT EXECUTE ON FUNCTION public.is_admin_or_gestor TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_admin_or_gestor TO anon;
GRANT EXECUTE ON FUNCTION public.is_admin_or_gestor TO service_role;

-- 4. Recriar a View de Colaboradores com SECURITY INVOKER
-- Isso garante que a view use as permissões do usuário logado (você)
DROP VIEW IF EXISTS vw_colaboradores_completos;

CREATE OR REPLACE VIEW vw_colaboradores_completos WITH (security_invoker = true) AS
SELECT 
    c.id,
    c.usuario_id,
    u.nome,
    u.email,
    u.telefone,
    u.nif,
    c.iban,
    c.nome_titular_banco,
    c.telefone_mbway,
    c.carteira_lightning,
    c.status,
    c.limite_total,
    c.limite_disponivel,
    c.taxa_juros,
    c.total_adiantamentos,
    c.data_admissao,
    c.data_registro,
    u.ativo AS usuario_ativo
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- 5. Diagnóstico final (Para você conferir no output)
SELECT 'Seu Usuario' as check, email, tipo_usuario, ativo FROM usuarios WHERE email = 'silvioluigmj@gmail.com';
SELECT 'Total Colaboradores' as check, count(*) as qtd FROM colaboradores;
SELECT 'Total Ativos' as check, count(*) as qtd FROM colaboradores WHERE status = 'ativo';
