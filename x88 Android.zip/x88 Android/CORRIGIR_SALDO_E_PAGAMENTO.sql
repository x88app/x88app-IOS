-- SCRIPT DE CORREÇÃO DE PAGAMENTO E SALDO (SOLUÇÃO ROBUSTA)

-- 1. Corrigir permissões da carteira (RLS)
ALTER TABLE carteira_gestor ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Gestor ve sua propria carteira" ON carteira_gestor;
DROP POLICY IF EXISTS "Gestor atualiza sua propria carteira" ON carteira_gestor;

CREATE POLICY "Gestor ve sua propria carteira" ON carteira_gestor FOR SELECT USING (auth.uid() = gestor_id);
CREATE POLICY "Gestor atualiza sua propria carteira" ON carteira_gestor FOR UPDATE USING (auth.uid() = gestor_id);

-- 2. Corrigir permissões de transações
ALTER TABLE transacoes_carteira ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Gestor ve suas transacoes" ON transacoes_carteira;
DROP POLICY IF EXISTS "Gestor cria transacoes" ON transacoes_carteira;

CREATE POLICY "Gestor ve suas transacoes" ON transacoes_carteira FOR SELECT 
USING (EXISTS (SELECT 1 FROM carteira_gestor WHERE carteira_gestor.id = transacoes_carteira.carteira_id AND carteira_gestor.gestor_id = auth.uid()));

CREATE POLICY "Gestor cria transacoes" ON transacoes_carteira FOR INSERT 
WITH CHECK (EXISTS (SELECT 1 FROM carteira_gestor WHERE carteira_gestor.id = transacoes_carteira.carteira_id AND carteira_gestor.gestor_id = auth.uid()));

-- 3. FUNÇÃO SEGURA DE PAGAMENTO (RPC)
-- Esta função realiza toda a operação de pagamento atomicamente no banco de dados
CREATE OR REPLACE FUNCTION processar_pagamento_solicitacao(
    p_solicitacao_id UUID,
    p_valor_liquido DECIMAL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_solicitacao RECORD;
    v_carteira RECORD;
    v_novo_saldo DECIMAL;
    v_user_id UUID;
    v_moeda TEXT;
BEGIN
    -- Pegar usuário atual
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'message', 'Usuário não autenticado');
    END IF;

    -- Buscar solicitação
    SELECT * INTO v_solicitacao FROM solicitacoes WHERE id = p_solicitacao_id;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Solicitação não encontrada');
    END IF;

    IF v_solicitacao.status = 'pago' THEN
        RETURN jsonb_build_object('success', false, 'message', 'Solicitação já foi paga');
    END IF;

    -- Buscar carteira do gestor
    SELECT * INTO v_carteira FROM carteira_gestor WHERE gestor_id = v_user_id FOR UPDATE;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'message', 'Carteira não encontrada');
    END IF;

    v_moeda := v_solicitacao.moeda;

    -- Verificar saldo
    IF v_moeda = 'EUR' THEN
        IF v_carteira.saldo_eur < p_valor_liquido THEN
            RETURN jsonb_build_object('success', false, 'message', 'Saldo em EUR insuficiente');
        END IF;
        v_novo_saldo := v_carteira.saldo_eur - p_valor_liquido;
        
        -- Atualizar saldo EUR
        UPDATE carteira_gestor SET saldo_eur = v_novo_saldo WHERE id = v_carteira.id;
    ELSE
        IF v_carteira.saldo_sats < p_valor_liquido THEN
            RETURN jsonb_build_object('success', false, 'message', 'Saldo em SATS insuficiente');
        END IF;
        v_novo_saldo := v_carteira.saldo_sats - p_valor_liquido;
        
        -- Atualizar saldo SATS
        UPDATE carteira_gestor SET saldo_sats = v_novo_saldo WHERE id = v_carteira.id;
    END IF;

    -- Atualizar solicitação
    UPDATE solicitacoes 
    SET status = 'pago',
        data_pagamento = NOW(),
        etapa_progresso = 4
    WHERE id = p_solicitacao_id;

    -- Registrar transação
    INSERT INTO transacoes_carteira (
        carteira_id,
        tipo_transacao,
        moeda,
        valor,
        saldo_anterior,
        saldo_atual,
        solicitacao_id,
        descricao,
        data_transacao
    ) VALUES (
        v_carteira.id,
        'pagamento',
        v_moeda,
        p_valor_liquido,
        CASE WHEN v_moeda = 'EUR' THEN v_carteira.saldo_eur ELSE v_carteira.saldo_sats END,
        v_novo_saldo,
        p_solicitacao_id,
        'Pagamento de solicitação (via app)',
        NOW()
    );

    RETURN jsonb_build_object('success', true, 'novo_saldo', v_novo_saldo);
END;
$$;
