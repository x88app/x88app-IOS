-- =====================================================
-- DIAGNÓSTICO DA VIEW DE SOLICITAÇÕES
-- =====================================================

-- 1. Verificar se a view retorna dados
SELECT COUNT(*) as total_view FROM vw_solicitacoes_completas;

-- 2. Verificar se o JOIN está falhando
-- Vamos simular o JOIN manualmente para ver onde quebra
SELECT 
    s.id as solicitacao_id,
    s.colaborador_id,
    c.id as c_id,
    c.usuario_id,
    u.id as u_id,
    u.nome
FROM solicitacoes s
LEFT JOIN colaboradores c ON s.colaborador_id = c.id
LEFT JOIN usuarios u ON c.usuario_id = u.id;

-- 3. Verificar se todos os usuários envolvidos estão ativos
SELECT 
    u.nome, 
    u.ativo, 
    c.status as status_colaborador
FROM solicitacoes s
JOIN colaboradores c ON s.colaborador_id = c.id
JOIN usuarios u ON c.usuario_id = u.id;
