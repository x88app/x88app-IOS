-- Add preferencias column to usuarios table
ALTER TABLE usuarios 
ADD COLUMN IF NOT EXISTS preferencias JSONB DEFAULT '{
  "notifications": {
    "email": true,
    "push": true,
    "sms": false,
    "types": {
      "approved": true,
      "rejected": true,
      "payment": true,
      "promotions": false
    },
    "sound": true
  },
  "security": {
    "twoFactor": false,
    "biometrics": true,
    "loginNotify": true
  }
}'::jsonb;

-- Update view if necessary (not strictly needed as views usually select specific columns or *)
-- But if vw_colaboradores_completos uses *, it will automatically include it if re-created, 
-- or if it selects specific columns, I might want to add it there too.
-- Looking at vw_colaboradores_completos definition in schema:
-- It selects specific columns. I should probably add it to the view too if the frontend uses the view.
-- The frontend in AuthContext loads from 'usuarios' and 'colaboradores' tables directly.

-- Comment
COMMENT ON COLUMN usuarios.preferencias IS 'Preferências do usuário (notificações, segurança, etc)';
