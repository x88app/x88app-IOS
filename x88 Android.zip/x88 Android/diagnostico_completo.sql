-- =====================================================
-- DIAGNÓSTICO COMPLETO DO PROBLEMA
-- Execute este script para descobrir o que está errado
-- =====================================================

-- 1. Verificar total de usuários
SELECT 'TOTAL DE USUÁRIOS' as tabela, COUNT(*) as total FROM usuarios;
SELECT 'USUÁRIOS COLABORADORES' as tipo, COUNT(*) as total FROM usuarios WHERE tipo_usuario = 'colaborador';
SELECT 'USUÁRIOS GESTORES' as tipo, COUNT(*) as total FROM usuarios WHERE tipo_usuario = 'gestor';

-- 2. Verificar tabela colaboradores
SELECT 'TOTAL NA TABELA COLABORADORES' as tabela, COUNT(*) as total FROM colaboradores;

-- 3. Mostrar todos os usuários e se têm registro em colaboradores
SELECT 
    u.id,
    u.nome,
    u.email,
    u.tipo_usuario,
    CASE WHEN c.id IS NOT NULL THEN 'SIM' ELSE 'NÃO' END as tem_registro_colaborador
FROM usuarios u
LEFT JOIN colaboradores c ON c.usuario_id = u.id
ORDER BY u.tipo_usuario, u.nome;

-- 4. Verificar a VIEW vw_colaboradores_completos
SELECT 'TOTAL NA VIEW COLABORADORES' as tabela, COUNT(*) as total FROM vw_colaboradores_completos;

-- 5. Mostrar dados da view
SELECT * FROM vw_colaboradores_completos LIMIT 10;

-- 6. Verificar solicitações
SELECT 'TOTAL DE SOLICITAÇÕES' as tabela, COUNT(*) as total FROM solicitacoes;

-- 7. Verificar VIEW de solicitações
SELECT 'TOTAL NA VIEW SOLICITAÇÕES' as tabela, COUNT(*) as total FROM vw_solicitacoes_completas;

-- 8. Verificar políticas RLS ativas
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual
FROM pg_policies
WHERE tablename IN ('usuarios', 'colaboradores', 'solicitacoes')
ORDER BY tablename, policyname;

-- 9. Verificar se RLS está ativo
SELECT 
    tablename,
    rowsecurity as rls_ativo
FROM pg_tables
WHERE schemaname = 'public'
AND tablename IN ('usuarios', 'colaboradores', 'solicitacoes')
ORDER BY tablename;

-- 10. Testar a função is_gestor
SELECT 'FUNÇÃO IS_GESTOR EXISTE?' as teste, 
    CASE WHEN EXISTS (
        SELECT 1 FROM pg_proc WHERE proname = 'is_gestor'
    ) THEN 'SIM' ELSE 'NÃO' END as resultado;
