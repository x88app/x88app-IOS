# ✅ Checklist de Integração com Supabase

## 📋 Progresso Atual

- ✅ **Passo 1**: Dependências instaladas (`@supabase/supabase-js`)
- ✅ **Passo 2**: Arquivos `.env.example` criados
- ✅ **Passo 3**: Cliente Supabase configurado em ambos os apps
- ⏳ **Passo 4**: Você precisa fazer agora!

---

## 🎯 O QUE VOCÊ PRECISA FAZER AGORA:

### 1️⃣ Criar arquivo `.env` no APP COLABORADOR

1. Na pasta raiz do projeto colaborador (`/c:/Users/silvi/Documents/colaborador/`)
2. Crie um arquivo chamado `.env` (sem extensão)
3. Cole este conteúdo:

```env
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-publica-aqui
```

4. **Substitua** as credenciais pelas suas do Supabase:
   - Vá no Supabase → Settings → API
   - Copie **Project URL**
   - Copie **anon public key**

---

### 2️⃣ Criar arquivo `.env` no APP GESTOR

1. Na pasta do gestor (`/c:/Users/silvi/Documents/colaborador/x88gestor/`)
2. Crie um arquivo chamado `.env` (sem extensão)
3. Cole o **MESMO CONTEÚDO** acima
4. Use as **MESMAS CREDENCIAIS** (mesmo projeto Supabase)

---

### 3️⃣ Executar o SEED no Supabase

**IMPORTANTE:** Antes de executar o seed, você precisa criar usuários no Supabase Auth!

#### Opção A: Criar Usuários Manualmente (RECOMENDADO)

1. No Supabase, vá em **Authentication** → **Users**
2. Clique em **Add user** → **Create new user**
3. Crie estes usuários:

**GESTOR:**
- Email: `gestor@x88.pt`
- Password: `Gestor@123` (escolha uma senha forte)
- ✅ Clique em "Auto Confirm User"

**COLABORADORES:**
- Email: `joao.silva@x88.pt` | Senha: `Joao@123`
- Email: `maria.santos@x88.pt` | Senha: `Maria@123`
- Email: `pedro.costa@x88.pt` | Senha: `Pedro@123`
- Email: `ana.ferreira@x88.pt` | Senha: `Ana@123`
- Email: `carlos.oliveira@x88.pt` | Senha: `Carlos@123`

**Para cada usuário:**
- ✅ Marque "Auto Confirm User"
- ✅ Clique em "Create user"
- ✅ **COPIE O UUID** que aparece (você vai precisar!)

#### Opção B: Modificar o Seed

Vou criar um seed modificado que usa os UUIDs do Supabase Auth.

---

### 4️⃣ Depois de Criar os Usuários

Execute este SQL no Supabase (SQL Editor):

```sql
-- Verificar IDs dos usuários criados
SELECT id, email FROM auth.users ORDER BY email;
```

Anote os IDs que aparecerem e me mostre. Vou adaptar o seed para usar esses IDs!

---

## 🚀 Próximos Passos

Depois de fazer isso, me avise e eu vou:
1. ✅ Atualizar os Contexts para usar Supabase
2. ✅ Configurar autenticação completa
3. ✅ Testar a integração

---

## ❓ Precisa de Ajuda?

**Onde está o painel do Supabase?**
- Acesse: https://supabase.com/dashboard

**Onde acho as credenciais?**
- No projeto → Settings (⚙️) → API
- Copie "Project URL" e "anon public"

**Como criar arquivo .env?**
- Pode criar no VS Code mesmo
- Arquivo sem extensão, apenas `.env`
- Salve na pasta raiz do projeto

---

Me avise quando terminar! 🎉
