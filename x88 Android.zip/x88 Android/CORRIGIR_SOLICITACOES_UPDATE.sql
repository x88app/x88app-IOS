-- CORREÇÃO ESPECÍFICA PARA ERRO AO APROVAR SOLICITAÇÃO
-- Este script garante que o gestor tenha permissão para atualizar o status da solicitação

-- 1. Habilitar RLS (já deve estar habilitado, mas por garantia)
ALTER TABLE solicitacoes ENABLE ROW LEVEL SECURITY;

-- 2. Remover policy antiga que pode estar causando erro de recursão
DROP POLICY IF EXISTS "Gestores atualizam qualquer solicitação" ON solicitacoes;

-- 3. Criar nova policy que permite atualização por gestores
-- A subquery verifica se o usuário atual é gestor ou admin
CREATE POLICY "Gestores atualizam qualquer solicitação"
    ON solicitacoes FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- 4. IMPORTANTE: Garantir que a tabela usuarios permita leitura do próprio usuário sem recursão
-- Se esta policy não existir, a verificação acima falhará
DROP POLICY IF EXISTS "Usuarios autenticados veem proprio perfil" ON usuarios;
CREATE POLICY "Usuarios autenticados veem proprio perfil"
    ON usuarios FOR SELECT
    USING (auth.uid() = id);
