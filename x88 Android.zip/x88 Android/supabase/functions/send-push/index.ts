import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { create, getNumericDate } from "https://deno.land/x/djwt@v2.8/mod.ts"

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

// Firebase Service Account credentials (from JSON file)
const FIREBASE_PROJECT_ID = Deno.env.get('FIREBASE_PROJECT_ID')
const FIREBASE_CLIENT_EMAIL = Deno.env.get('FIREBASE_CLIENT_EMAIL')
const FIREBASE_PRIVATE_KEY = Deno.env.get('FIREBASE_PRIVATE_KEY')?.replace(/\\n/g, '\n')

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface PushPayload {
  colaborador_id?: string
  usuario_id?: string
  title: string
  body: string
  data?: Record<string, string>
}

// Generate OAuth2 access token using Service Account
async function getAccessToken(): Promise<string> {
  const now = Math.floor(Date.now() / 1000)
  
  const payload = {
    iss: FIREBASE_CLIENT_EMAIL,
    sub: FIREBASE_CLIENT_EMAIL,
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
    scope: "https://www.googleapis.com/auth/firebase.messaging"
  }

  // Import the private key
  const pemHeader = "-----BEGIN PRIVATE KEY-----"
  const pemFooter = "-----END PRIVATE KEY-----"
  const pemContents = FIREBASE_PRIVATE_KEY!
    .replace(pemHeader, '')
    .replace(pemFooter, '')
    .replace(/\s/g, '')
  
  const binaryDer = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0))
  
  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    binaryDer,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  )

  // Create JWT
  const jwt = await create(
    { alg: "RS256", typ: "JWT" },
    payload,
    cryptoKey
  )

  // Exchange JWT for access token
  const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  })

  const tokenData = await tokenResponse.json()
  return tokenData.access_token
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('Checking Firebase credentials...')
    console.log('PROJECT_ID exists:', !!FIREBASE_PROJECT_ID)
    console.log('CLIENT_EMAIL exists:', !!FIREBASE_CLIENT_EMAIL)
    console.log('PRIVATE_KEY exists:', !!FIREBASE_PRIVATE_KEY)
    
    if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY) {
      const missing = []
      if (!FIREBASE_PROJECT_ID) missing.push('FIREBASE_PROJECT_ID')
      if (!FIREBASE_CLIENT_EMAIL) missing.push('FIREBASE_CLIENT_EMAIL')
      if (!FIREBASE_PRIVATE_KEY) missing.push('FIREBASE_PRIVATE_KEY')
      throw new Error(`Firebase credentials not configured. Missing: ${missing.join(', ')}`)
    }

    const payload: PushPayload = await req.json()
    const { colaborador_id, usuario_id, title, body, data } = payload

    if (!title || !body) {
      throw new Error('title e body são obrigatórios')
    }

    if (!colaborador_id && !usuario_id) {
      throw new Error('colaborador_id ou usuario_id é obrigatório')
    }

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!)

    let query = supabase
      .from('colaboradores')
      .select('fcm_token, usuario_id')

    if (colaborador_id) {
      query = query.eq('id', colaborador_id)
    } else if (usuario_id) {
      query = query.eq('usuario_id', usuario_id)
    }

    const { data: colaborador, error: dbError } = await query.maybeSingle()

    if (dbError) {
      throw new Error(`Erro ao buscar colaborador: ${dbError.message}`)
    }

    if (!colaborador?.fcm_token) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'Colaborador não tem token FCM registrado' 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Verificar se o usuário tem push notifications habilitado nas preferências
    const { data: usuario } = await supabase
      .from('usuarios')
      .select('preferencias')
      .eq('id', colaborador.usuario_id)
      .maybeSingle()

    // Se push estiver desabilitado, não enviar notificação
    if (usuario?.preferencias?.notifications?.push === false) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'Usuário desativou notificações push nas preferências' 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get OAuth2 access token
    const accessToken = await getAccessToken()

    // FCM V1 API payload
    const fcmPayload = {
      message: {
        token: colaborador.fcm_token,
        notification: {
          title,
          body,
        },
        data: data || {},
        android: {
          priority: "high",
          notification: {
            sound: "kernel",
            channel_id: "x88_notifications"
          }
        },
        apns: {
          payload: {
            aps: {
              sound: "default",
              badge: 1
            }
          }
        }
      }
    }

    // Send to FCM V1 API
    const fcmResponse = await fetch(
      `https://fcm.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/messages:send`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(fcmPayload),
      }
    )

    const fcmResult = await fcmResponse.json()

    if (!fcmResponse.ok) {
      console.error('FCM Error:', fcmResult)
      
      // If token is invalid, remove it from database
      if (fcmResult.error?.details?.[0]?.errorCode === 'UNREGISTERED') {
        await supabase
          .from('colaboradores')
          .update({ fcm_token: null })
          .eq(colaborador_id ? 'id' : 'usuario_id', colaborador_id || usuario_id)
      }
      
      return new Response(
        JSON.stringify({ success: false, error: fcmResult.error?.message }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ success: true, message_id: fcmResult.name }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error.message)
    return new Response(
      JSON.stringify({ error: error.message, success: false }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
