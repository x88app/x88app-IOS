-- Criação do bucket para anúncios (popups)
INSERT INTO storage.buckets (id, name, public) 
VALUES ('anuncios', 'anuncios', true)
ON CONFLICT (id) DO NOTHING;

-- Política de acesso público para leitura
CREATE POLICY "Anúncios são públicos"
ON storage.objects FOR SELECT
USING ( bucket_id = 'anuncios' );

-- Política de upload para usuários autenticados (Gestores)
CREATE POLICY "Gestores podem fazer upload de anúncios"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'anuncios' AND
  auth.role() = 'authenticated'
);

-- Política de atualização
CREATE POLICY "Gestores podem atualizar anúncios"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'anuncios' AND
  auth.role() = 'authenticated'
);

-- Política de deleção
CREATE POLICY "Gestores podem deletar anúncios"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'anuncios' AND
  auth.role() = 'authenticated'
);
