-- =====================================================
-- DADOS INICIAIS (SEED) - X88 ADIANTAMENTO SALARIAL
-- Versão: 1.0.0
-- Descrição: Dados fictícios para testes e desenvolvimento
-- =====================================================

-- =====================================================
-- 1. INSERIR USUÁRIOS
-- =====================================================

-- Gestor Admin
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo) VALUES
('11111111-1111-1111-1111-111111111111', 'Admin Gestor X88', 'gestor@x88.pt', '+351 910 000 000', '100000000', '$2a$10$abcdefghijklmnopqrstuvwxyz123456', 'gestor', true);

-- Colaboradores
INSERT INTO usuarios (id, nome, email, telefone, nif, senha_hash, tipo_usuario, ativo) VALUES
('22222222-2222-2222-2222-222222222221', 'João Silva', 'joao.silva@x88.pt', '+351 912 345 678', '123456789', '$2a$10$abcdefghijklmnopqrstuvwxyz123456', 'colaborador', true),
('22222222-2222-2222-2222-222222222222', 'Maria Santos', 'maria.santos@x88.pt', '+351 913 456 789', '234567890', '$2a$10$abcdefghijklmnopqrstuvwxyz123456', 'colaborador', true),
('22222222-2222-2222-2222-222222222223', 'Pedro Costa', 'pedro.costa@x88.pt', '+351 914 567 890', '345678901', '$2a$10$abcdefghijklmnopqrstuvwxyz123456', 'colaborador', true),
('22222222-2222-2222-2222-222222222224', 'Ana Ferreira', 'ana.ferreira@x88.pt', '+351 915 678 901', '456789012', '$2a$10$abcdefghijklmnopqrstuvwxyz123456', 'colaborador', true),
('22222222-2222-2222-2222-222222222225', 'Carlos Oliveira', 'carlos.oliveira@x88.pt', '+351 916 789 012', '567890123', '$2a$10$abcdefghijklmnopqrstuvwxyz123456', 'colaborador', true);

-- =====================================================
-- 2. INSERIR COLABORADORES
-- =====================================================

INSERT INTO colaboradores (id, usuario_id, iban, nome_titular_banco, swift_bic, telefone_mbway, carteira_lightning, metodo_pagamento_preferido, status, limite_total, limite_disponivel, taxa_juros, total_adiantamentos, data_admissao) VALUES
('33333333-3333-3333-3333-333333333331', '22222222-2222-2222-2222-222222222221', 'PT50 0002 0123 1234 5678 9015 4', 'João Silva', 'CGDIPTPL', '+351 912 345 678', 'joao@getalby.com', 'iban', 'ativo', 1500.00, 800.00, 10.00, 5, NOW() - INTERVAL '365 days'),
('33333333-3333-3333-3333-333333333332', '22222222-2222-2222-2222-222222222222', 'PT50 0033 0000 4567 8901 2345 6', 'Maria Santos', 'BESCPTPL', '+351 913 456 789', 'maria@getalby.com', 'mbway', 'ativo', 2000.00, 1200.00, 10.00, 3, NOW() - INTERVAL '180 days'),
('33333333-3333-3333-3333-333333333333', '22222222-2222-2222-2222-222222222223', 'PT50 0018 0003 6789 0123 4567 8', 'Pedro Costa', 'TOTAPTPL', '+351 914 567 890', 'pedro@getalby.com', 'satoshi', 'ativo', 1000.00, 300.00, 10.00, 8, NOW() - INTERVAL '90 days'),
('33333333-3333-3333-3333-333333333334', '22222222-2222-2222-2222-222222222224', 'PT50 0010 0000 8901 2345 6789 0', 'Ana Ferreira', 'BBPIPTPL', '+351 915 678 901', 'ana@getalby.com', 'iban', 'ativo', 1500.00, 1500.00, 10.00, 2, NOW() - INTERVAL '45 days'),
('33333333-3333-3333-3333-333333333335', '22222222-2222-2222-2222-222222222225', 'PT50 0007 0000 0012 3456 7890 1', 'Carlos Oliveira', 'BPIIPTPL', '+351 916 789 012', 'carlos@getalby.com', 'mbway', 'pendente', 1000.00, 1000.00, 10.00, 0, NOW());

-- =====================================================
-- 3. INSERIR CARTEIRA DO GESTOR
-- =====================================================

INSERT INTO carteira_gestor (id, gestor_id, saldo_eur, saldo_sats) VALUES
('44444444-4444-4444-4444-444444444441', '11111111-1111-1111-1111-111111111111', 5000.00, 1000000);

-- =====================================================
-- 4. INSERIR SOLICITAÇÕES
-- =====================================================

-- Solicitações PAGAS (histórico)
INSERT INTO solicitacoes (
    id, colaborador_id, valor_solicitado, valor_liquido, moeda, metodo_pagamento, 
    iban_pagamento, status, etapa_progresso, taxa_juros_aplicada, valor_juros, 
    data_solicitacao, data_aprovacao, data_pagamento
) VALUES
-- João Silva - PAGO
('55555555-5555-5555-5555-555555555551', '33333333-3333-3333-3333-333333333331', 200.00, 190.00, 'EUR', 'iban', 'PT50 0002 0123 1234 5678 9015 4', 'pago', 4, 10.00, 10.00, NOW() - INTERVAL '10 days', NOW() - INTERVAL '9 days', NOW() - INTERVAL '8 days'),
-- Maria Santos - PAGO
('55555555-5555-5555-5555-555555555552', '33333333-3333-3333-3333-333333333332', 150.00, 142.50, 'EUR', 'mbway', '+351 913 456 789', 'pago', 4, 10.00, 7.50, NOW() - INTERVAL '8 days', NOW() - INTERVAL '7 days', NOW() - INTERVAL '6 days'),
-- Pedro Costa - PAGO (SATS)
('55555555-5555-5555-5555-555555555553', '33333333-3333-3333-3333-333333333333', 75000, 72000, 'SATS', 'satoshi', NULL, 'pago', 4, 10.00, 3000, NOW() - INTERVAL '6 days', NOW() - INTERVAL '5 days', NOW() - INTERVAL '4 days');

-- Adicionar lightning_address nas solicitações com satoshi
UPDATE solicitacoes SET lightning_address = 'pedro@getalby.com' WHERE id = '55555555-5555-5555-5555-555555555553';

-- Solicitações APROVADAS (aguardando pagamento)
INSERT INTO solicitacoes (
    id, colaborador_id, valor_solicitado, valor_liquido, moeda, metodo_pagamento, 
    iban_pagamento, status, etapa_progresso, taxa_juros_aplicada, valor_juros, 
    data_solicitacao, data_aprovacao
) VALUES
-- João Silva - APROVADO
('55555555-5555-5555-5555-555555555554', '33333333-3333-3333-3333-333333333331', 100.00, 95.00, 'EUR', 'iban', 'PT50 0002 0123 1234 5678 9015 4', 'aprovado', 3, 10.00, 5.00, NOW() - INTERVAL '4 days', NOW() - INTERVAL '3 days'),
-- Maria Santos - APROVADO (SATS)
('55555555-5555-5555-5555-555555555555', '33333333-3333-3333-3333-333333333332', 50000, 48000, 'SATS', 'satoshi', NULL, 'aprovado', 3, 10.00, 2000, NOW() - INTERVAL '3 days', NOW() - INTERVAL '2 days');

UPDATE solicitacoes SET lightning_address = 'maria@getalby.com' WHERE id = '55555555-5555-5555-5555-555555555555';

-- Solicitações PENDENTES (aguardando aprovação)
INSERT INTO solicitacoes (
    id, colaborador_id, valor_solicitado, valor_liquido, moeda, metodo_pagamento, 
    detalhes_conta, status, etapa_progresso, taxa_juros_aplicada, valor_juros, 
    data_solicitacao
) VALUES
-- Pedro Costa - PENDENTE
('55555555-5555-5555-5555-555555555556', '33333333-3333-3333-3333-333333333333', 125.00, 118.75, 'EUR', 'mbway', '+351 914 567 890', 'pendente', 0, 10.00, 6.25, NOW() - INTERVAL '1 day'),
-- Ana Ferreira - PENDENTE
('55555555-5555-5555-5555-555555555557', '33333333-3333-3333-3333-333333333334', 80.00, 76.00, 'EUR', 'iban', 'PT50 0010 0000 8901 2345 6789 0', 'pendente', 0, 10.00, 4.00, NOW() - INTERVAL '6 hours'),
-- João Silva - PENDENTE (SATS)
('55555555-5555-5555-5555-555555555558', '33333333-3333-3333-3333-333333333331', 30000, 28500, 'SATS', 'satoshi', NULL, 'pendente', 0, 10.00, 1500, NOW() - INTERVAL '2 hours');

UPDATE solicitacoes SET lightning_address = 'joao@getalby.com' WHERE id = '55555555-5555-5555-5555-555555555558';
UPDATE solicitacoes SET mbway_pagamento = '+351 914 567 890' WHERE id = '55555555-5555-5555-5555-555555555556';
UPDATE solicitacoes SET iban_pagamento = 'PT50 0010 0000 8901 2345 6789 0' WHERE id = '55555555-5555-5555-5555-555555555557';

-- =====================================================
-- 5. INSERIR NOTIFICAÇÕES
-- =====================================================

INSERT INTO notificacoes (usuario_id, solicitacao_id, titulo, mensagem, tipo, lida) VALUES
('22222222-2222-2222-2222-222222222221', '55555555-5555-5555-5555-555555555551', 'Pagamento Efetuado', 'Sua solicitação de €200,00 foi paga. Valor de €190,00 creditado em sua conta bancária.', 'success', true),
('22222222-2222-2222-2222-222222222222', '55555555-5555-5555-5555-555555555552', 'Pagamento Efetuado', 'Sua solicitação de €150,00 foi paga. Valor de €142,50 creditado via MBWAY.', 'success', true),
('22222222-2222-2222-2222-222222222223', '55555555-5555-5555-5555-555555555553', 'Transação Confirmada', 'O gestor confirmou sua transação de 75.000 sats. O valor já está disponível!', 'success', true),
('22222222-2222-2222-2222-222222222221', '55555555-5555-5555-5555-555555555554', 'Solicitação Aprovada', 'Sua solicitação de €100,00 foi aprovada. O valor de €95,00 será creditado na sua conta em até 3 horas.', 'success', false),
('22222222-2222-2222-2222-222222222222', '55555555-5555-5555-5555-555555555555', 'Solicitação Aprovada', 'Sua solicitação de 50.000 sats foi aprovada. O valor de 48.000 sats será creditado na sua carteira Lightning em até 3 horas.', 'success', false);

-- =====================================================
-- 6. INSERIR TRANSAÇÕES DA CARTEIRA
-- =====================================================

INSERT INTO transacoes_carteira (
    carteira_id, tipo_transacao, moeda, valor, saldo_anterior, saldo_atual, solicitacao_id, descricao
) VALUES
-- Depósito inicial EUR
('44444444-4444-4444-4444-444444444441', 'deposito', 'EUR', 5000.00, 0.00, 5000.00, NULL, 'Depósito inicial na carteira'),
-- Depósito inicial SATS
('44444444-4444-4444-4444-444444444441', 'deposito', 'SATS', 1000000, 0, 1000000, NULL, 'Depósito inicial de satoshis'),
-- Pagamento João Silva
('44444444-4444-4444-4444-444444444441', 'pagamento', 'EUR', 200.00, 5000.00, 4800.00, '55555555-5555-5555-5555-555555555551', 'Pagamento adiantamento João Silva'),
-- Pagamento Maria Santos
('44444444-4444-4444-4444-444444444441', 'pagamento', 'EUR', 150.00, 4800.00, 4650.00, '55555555-5555-5555-5555-555555555552', 'Pagamento adiantamento Maria Santos'),
-- Pagamento Pedro Costa (SATS)
('44444444-4444-4444-4444-444444444441', 'pagamento', 'SATS', 75000, 1000000, 925000, '55555555-5555-5555-5555-555555555553', 'Pagamento adiantamento Pedro Costa');

-- =====================================================
-- 7. INSERIR BANNERS
-- =====================================================

INSERT INTO banners (id, titulo, imagem_url, ordem, ativo) VALUES
('66666666-6666-6666-6666-666666666661', 'Bem-vindo ao X88', '/banners/banner-1.jpg', 1, true),
('66666666-6666-6666-6666-666666666662', 'Adiantamento Rápido', '/banners/banner-2.jpg', 2, true),
('66666666-6666-6666-6666-666666666663', 'Pague em Bitcoin', '/banners/banner-3.jpg', 3, true);

-- =====================================================
-- 8. INSERIR CARDS DE ANÚNCIO
-- =====================================================

INSERT INTO cards_anuncio (id, titulo, descricao, imagem_url, ordem, ativo) VALUES
('77777777-7777-7777-7777-777777777771', 'Desconto em Parceiros', 'Aproveite descontos exclusivos em nossos parceiros', '/cards/desconto.jpg', 1, true),
('77777777-7777-7777-7777-777777777772', 'Zero Taxa na Primeira', 'Primeira solicitação sem taxa de serviço', '/cards/zero-taxa.jpg', 2, true),
('77777777-7777-7777-7777-777777777773', 'Pagamento em Bitcoin', 'Receba seus adiantamentos em satoshis', '/cards/bitcoin.jpg', 3, true);

-- =====================================================
-- 9. INSERIR CONFIGURAÇÕES DO SISTEMA
-- =====================================================

INSERT INTO configuracoes_sistema (chave, valor, tipo, descricao) VALUES
('taxa_juros_padrao', '10.00', 'numero', 'Taxa de juros padrão aplicada aos adiantamentos (%)'),
('limite_minimo_solicitacao_eur', '10.00', 'numero', 'Valor mínimo para solicitação em EUR'),
('limite_maximo_solicitacao_eur', '5000.00', 'numero', 'Valor máximo para solicitação em EUR'),
('limite_minimo_solicitacao_sats', '10000', 'numero', 'Valor mínimo para solicitação em SATS'),
('limite_maximo_solicitacao_sats', '10000000', 'numero', 'Valor máximo para solicitação em SATS'),
('horario_processamento', '{"inicio": "09:00", "fim": "18:00"}', 'json', 'Horário de processamento de solicitações'),
('email_notificacoes', 'true', 'booleano', 'Enviar notificações por email'),
('push_notificacoes', 'true', 'booleano', 'Enviar notificações push'),
('modo_manutencao', 'false', 'booleano', 'Modo de manutenção do sistema');

-- =====================================================
-- 10. INSERIR LOGS DE AUDITORIA
-- =====================================================

INSERT INTO auditoria (usuario_id, acao, tabela, registro_id, dados_novos, endereco_ip) VALUES
('11111111-1111-1111-1111-111111111111', 'APROVAR_SOLICITACAO', 'solicitacoes', '55555555-5555-5555-5555-555555555554', '{"status": "aprovado", "valor": 100.00}'::jsonb, '192.168.1.1'),
('11111111-1111-1111-1111-111111111111', 'APROVAR_SOLICITACAO', 'solicitacoes', '55555555-5555-5555-5555-555555555555', '{"status": "aprovado", "valor": 50000}'::jsonb, '192.168.1.1'),
('11111111-1111-1111-1111-111111111111', 'PAGAR_SOLICITACAO', 'solicitacoes', '55555555-5555-5555-5555-555555555551', '{"status": "pago", "valor": 200.00}'::jsonb, '192.168.1.1');

-- =====================================================
-- FIM DO SEED
-- =====================================================
