-- Adicionar campos para configuração de motivação diária
-- Execute este SQL no Supabase SQL Editor

-- 1. Adicionar colunas na tabela configuracoes_globais
ALTER TABLE configuracoes_globais 
ADD COLUMN IF NOT EXISTS motivacao_diaria_ativa BOOLEAN DEFAULT false;

ALTER TABLE configuracoes_globais 
ADD COLUMN IF NOT EXISTS motivacao_diaria_prompt TEXT DEFAULT 'Frases motivacionais para começar bem o dia';

-- 2. Atualizar registro existente com valores padrão
UPDATE configuracoes_globais 
SET 
  motivacao_diaria_ativa = false,
  motivacao_diaria_prompt = 'Frases motivacionais para começar bem o dia'
WHERE motivacao_diaria_ativa IS NULL;
