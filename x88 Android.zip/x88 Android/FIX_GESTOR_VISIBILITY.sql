-- ==============================================================================
-- FIX GESTOR VISIBILITY: Garantir que gestores vejam TUDO
-- ==============================================================================

-- 1. USUARIOS
-- Remover policies antigas de SELECT para evitar conflitos/duplicidade
DROP POLICY IF EXISTS "Usuarios autenticados veem proprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Gestores veem todos os usuarios" ON usuarios;
DROP POLICY IF EXISTS "Publico_Leitura_Auth" ON usuarios;
DROP POLICY IF EXISTS "Usuarios veem proprio perfil" ON usuarios;
DROP POLICY IF EXISTS "Gestores veem todos usuarios" ON usuarios;

-- Recriar Policies de Leitura (SELECT):
-- A. Todo usuário autenticado vê seu próprio perfil (necessário para login e validação)
CREATE POLICY "Usuarios veem proprio perfil"
    ON usuarios FOR SELECT
    USING (auth.uid() = id);

-- B. Gestores veem TODOS os usuários
CREATE POLICY "Gestores veem todos usuarios"
    ON usuarios FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );


-- 2. COLABORADORES
-- Remover policies antigas
DROP POLICY IF EXISTS "Colaboradores veem proprio perfil" ON colaboradores;
DROP POLICY IF EXISTS "Colab_Leitura_Mista" ON colaboradores;
DROP POLICY IF EXISTS "Colaboradores podem ver próprio perfil" ON colaboradores;
DROP POLICY IF EXISTS "Gestores veem todos colaboradores" ON colaboradores;

-- Recriar Policies de Leitura (SELECT):
-- A. Colaborador vê seu próprio registro
CREATE POLICY "Colaboradores veem proprio perfil"
    ON colaboradores FOR SELECT
    USING (usuario_id = auth.uid());

-- B. Gestores veem TODOS os colaboradores
CREATE POLICY "Gestores veem todos colaboradores"
    ON colaboradores FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );


-- 3. SOLICITACOES
-- Remover policies antigas
DROP POLICY IF EXISTS "Sol_Leitura_Mista" ON solicitacoes;
DROP POLICY IF EXISTS "Ver solicitacoes proprias ou gestor ve tudo" ON solicitacoes;
DROP POLICY IF EXISTS "Colaboradores veem proprias solicitacoes" ON solicitacoes;
DROP POLICY IF EXISTS "Gestores veem todas solicitacoes" ON solicitacoes;

-- Recriar Policies de Leitura (SELECT):
-- A. Colaborador vê suas próprias solicitações
CREATE POLICY "Colaboradores veem proprias solicitacoes"
    ON solicitacoes FOR SELECT
    USING (
        colaborador_id IN (
            SELECT id FROM colaboradores WHERE usuario_id = auth.uid()
        )
    );

-- B. Gestores veem TODAS as solicitações
CREATE POLICY "Gestores veem todas solicitacoes"
    ON solicitacoes FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM usuarios 
            WHERE id = auth.uid() 
            AND tipo_usuario IN ('gestor', 'admin')
        )
    );

-- 4. ATUALIZAR VIEWS PARA USAR SECURITY INVOKER
-- Isso garante que as policies acima sejam respeitadas quando consultar via View

DROP VIEW IF EXISTS vw_colaboradores_completos;
CREATE OR REPLACE VIEW vw_colaboradores_completos WITH (security_invoker = true) AS
SELECT 
    c.id,
    c.usuario_id,
    u.nome,
    u.email,
    u.telefone,
    u.nif,
    c.iban,
    c.nome_titular_banco,
    c.telefone_mbway,
    c.carteira_lightning,
    c.status,
    c.limite_total,
    c.limite_disponivel,
    c.taxa_juros,
    c.total_adiantamentos,
    c.data_admissao,
    c.data_registro,
    u.ativo AS usuario_ativo
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id;

DROP VIEW IF EXISTS vw_estatisticas_colaboradores;
CREATE OR REPLACE VIEW vw_estatisticas_colaboradores WITH (security_invoker = true) AS
SELECT 
    c.id AS colaborador_id,
    c.usuario_id,
    u.nome,
    c.status,
    c.limite_total,
    c.limite_disponivel,
    COUNT(s.id) AS total_solicitacoes,
    COUNT(CASE WHEN s.status = 'pago' THEN 1 END) AS total_pagas,
    COUNT(CASE WHEN s.status = 'pendente' THEN 1 END) AS total_pendentes,
    SUM(CASE WHEN s.status = 'pago' AND s.moeda = 'EUR' THEN s.valor_solicitado ELSE 0 END) AS total_pago_eur,
    SUM(CASE WHEN s.status = 'pago' AND s.moeda = 'SATS' THEN s.valor_solicitado ELSE 0 END) AS total_pago_sats,
    MAX(s.data_solicitacao) AS data_ultima_solicitacao
FROM colaboradores c
INNER JOIN usuarios u ON c.usuario_id = u.id
LEFT JOIN solicitacoes s ON c.id = s.colaborador_id
GROUP BY c.id, c.usuario_id, u.nome, c.status, c.limite_total, c.limite_disponivel;

DROP VIEW IF EXISTS vw_solicitacoes_completas;
CREATE OR REPLACE VIEW vw_solicitacoes_completas WITH (security_invoker = true) AS
SELECT 
    s.id,
    s.colaborador_id,
    c.usuario_id,
    u.nome AS colaborador_nome,
    u.email AS colaborador_email,
    s.valor_solicitado,
    s.valor_liquido,
    s.moeda,
    s.metodo_pagamento,
    s.detalhes_conta,
    s.iban_pagamento,
    s.mbway_pagamento,
    s.lightning_address,
    s.status,
    s.etapa_progresso,
    s.taxa_juros_aplicada,
    s.valor_juros,
    s.lida,
    s.data_solicitacao,
    s.data_aprovacao,
    s.data_pagamento,
    s.data_atualizacao
FROM solicitacoes s
INNER JOIN colaboradores c ON s.colaborador_id = c.id
INNER JOIN usuarios u ON c.usuario_id = u.id;

-- 5. VERIFICAÇÃO
SELECT 
    tablename,
    policyname,
    cmd,
    qual
FROM pg_policies
WHERE tablename IN ('usuarios', 'colaboradores', 'solicitacoes')
ORDER BY tablename, policyname;
