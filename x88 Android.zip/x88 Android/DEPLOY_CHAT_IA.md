# 🤖 Deploy do Chat com IA (X88 IA)

## Passo 1: Deploy da Edge Function no Supabase

Você precisa fazer o deploy da Edge Function para o Supabase. Existem duas formas:

### Opção A: Via Supabase CLI (Recomendado)

1. **Instale o Supabase CLI** (se ainda não tiver):
```bash
npm install -g supabase
```

2. **Faça login no Supabase**:
```bash
supabase login
```

3. **Vincule seu projeto** (na pasta do projeto):
```bash
supabase link --project-ref SEU_PROJECT_REF
```
> O `project-ref` está na URL do seu projeto: `https://supabase.com/dashboard/project/SEU_PROJECT_REF`

4. **Faça o deploy da função**:
```bash
supabase functions deploy chat-ai
```

### Opção B: Via Dashboard Supabase (Manual)

1. Acesse: **Dashboard Supabase → Edge Functions → New Function**

2. Nome da função: `chat-ai`

3. Cole o código do arquivo `supabase/functions/chat-ai/index.ts`

4. Clique em **Deploy**

---

## Passo 2: Verificar a Secret

Confirme que a secret `GEMINI_API_KEY` está configurada:

1. **Dashboard Supabase → Settings → Edge Functions → Secrets**
2. Verifique se `GEMINI_API_KEY` aparece na lista

---

## Passo 3: Testar

1. Execute o app: `npm run dev`
2. Faça login
3. Clique no botão de chat (💬) no canto inferior direito da tela inicial
4. Envie uma mensagem de teste

---

## Estrutura Criada

```
src/
├── pages/Chat/
│   └── Chat.tsx          # Tela do chat
├── hooks/
│   └── useChat.ts        # Hook para gerenciar mensagens
supabase/
└── functions/
    └── chat-ai/
        └── index.ts      # Edge Function (Gemini API)
```

---

## Funcionalidades

✅ Chat estilo WhatsApp/ChatGPT  
✅ Histórico salvo localmente (últimas 50 mensagens)  
✅ Indicador de "digitando..."  
✅ Botão para limpar conversa  
✅ Mensagem de boas-vindas personalizada  
✅ Suporte a PT-BR e PT-PT  
✅ System prompt com informações do X88  

---

## Limites

- **Gemini 1.5 Flash**: ~1.500 requisições/dia (gratuito)
- Histórico local: últimas 50 mensagens
- Contexto enviado: últimas 10 mensagens

---

## Personalização

Para alterar o comportamento da IA, edite o `SYSTEM_PROMPT` no arquivo:
`supabase/functions/chat-ai/index.ts`

Você pode adicionar:
- Informações sobre promoções
- Regras específicas da empresa
- Perguntas frequentes
- Personalidade diferente
